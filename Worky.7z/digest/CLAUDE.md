# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Daily Dev Digest is a Flask-based web application that automatically generates HTML summaries of GitHub repository changes by analyzing pull requests and commits from the last 24 hours.

## Development Commands

```bash
# Install uv (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install dependencies
uv sync

# Install with dev dependencies
uv sync --dev

# Run development server
uv run python main.py

# IMPORTANT: Always use `uv run` for all Python commands

# Run with Docker
docker-compose up -d

# Run tests (when implemented)
uv run pytest tests/

# Format code
uv run black src/

# Lint code
uv run pylint src/

# Type checking
uv run mypy src/

# Run ruff linter
uv run ruff check src/

# Update dependencies
uv lock --upgrade
```

## Architecture

The application follows a modular service-oriented architecture:

- **GitHub Integration Layer** (`src/github_client.py`): Handles all GitHub API interactions using PyGithub library. Fetches PRs, commits, and file changes.

- **Analysis Engine** (`src/analyzer.py`): Rule-based system that categorizes changes by type (dependency, feature, bugfix, etc.) and calculates significance scores based on change size, type, and impact.

- **Summarization Service** (`src/summarizer.py`): Dual-mode summarizer supporting both OpenAI API (when key provided) and fallback rule-based summarization. Generates human-readable descriptions of technical changes.

- **HTML Generation** (`src/digest_generator.py`): Renders digest data into responsive HTML using Jinja2 templates. Handles both inline styles and dynamic content generation.

- **Flask Application** (`app.py`): RESTful API server with SQLAlchemy ORM for digest persistence. Includes scheduled task runner using APScheduler for automated daily digest generation.

## Key Technical Decisions

1. **Package Management with UV**: Uses uv for 10-100x faster dependency installation, better dependency resolution with lock files, and integrated virtual environment management.

2. **Dual Summarization Strategy**: System works with or without OpenAI API key, falling back to rule-based summarization to ensure functionality without external dependencies.

3. **Significance Scoring Algorithm**: Combines multiple factors (lines changed, file count, change type) to prioritize important changes in digests.

4. **Database Design**: Simple SQLite database with two main models (Digest and Repository) for easy deployment while supporting migration to PostgreSQL.

5. **Frontend Architecture**: Server-rendered HTML with vanilla JavaScript for maximum compatibility and minimal dependencies.

## Critical Files to Understand

- `app.py`: Main application entry point, route definitions, and database models
- `src/analyzer.py`: Core business logic for change detection and categorization
- `src/github_client.py`: GitHub API integration and data extraction
- `.env.example`: Required environment variables and configuration

## Testing Approach

When implementing tests, focus on:
1. GitHub API mocking for integration tests
2. Change analysis accuracy validation
3. HTML generation correctness
4. Database operation integrity

## Common Modifications

- **Add new change detection rules**: Modify `ARCHITECTURE_PATTERNS` in `src/analyzer.py`
- **Customize digest styling**: Edit HTML template in `src/digest_generator.py`
- **Add new API endpoints**: Add routes in `app.py` following Flask patterns
- **Extend database schema**: Add models in `app.py` using SQLAlchemy declarative syntax