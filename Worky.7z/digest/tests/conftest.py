"""Pytest configuration and fixtures."""

import pytest
import tempfile
import os
from unittest.mock import Mock, AsyncMock
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from src.config.settings import Settings
from src.core.dependencies import Container
from src.infrastructure.database.models import Base
from src.infrastructure.database.repositories import SQLAlchemyDigestRepository, SQLAlchemyRepositoryRepository
from src.presentation.api.routes import create_app


@pytest.fixture
def test_settings():
    """Create test settings."""
    return Settings(
        database_url="sqlite:///:memory:",
        github_token="test_token",
        openai_api_key="test_key",
        debug=True,
        log_level="DEBUG"
    )


@pytest.fixture
def test_db_engine(test_settings):
    """Create test database engine."""
    engine = create_engine(test_settings.database_url)
    Base.metadata.create_all(engine)
    yield engine
    Base.metadata.drop_all(engine)


@pytest.fixture
def test_db_session(test_db_engine):
    """Create test database session."""
    SessionLocal = sessionmaker(bind=test_db_engine)
    session = SessionLocal()
    yield session
    session.close()


@pytest.fixture
def mock_github_client():
    """Mock GitHub client."""
    mock = AsyncMock()
    mock.validate_repository.return_value = True
    mock.get_pull_requests.return_value = []
    mock.get_commits.return_value = []
    mock.get_repository_info.return_value = {
        "name": "test-repo",
        "full_name": "owner/test-repo",
        "description": "Test repository"
    }
    return mock


@pytest.fixture
def mock_openai_client():
    """Mock OpenAI client."""
    mock = AsyncMock()
    mock.generate_summary.return_value = "Test summary"
    mock.analyze_changes.return_value = []
    return mock


@pytest.fixture
def mock_progress_tracker():
    """Mock progress tracker."""
    mock = AsyncMock()
    mock.create_session.return_value = None
    mock.start_step.return_value = None
    mock.complete_step.return_value = None
    mock.get_session_status.return_value = {
        "session_id": "test_session",
        "status": "completed",
        "overall_progress": 100.0
    }
    return mock


@pytest.fixture
def test_container(test_db_session, mock_github_client, mock_openai_client, mock_progress_tracker):
    """Create test dependency container."""
    container = Container()
    
    # Register test dependencies
    container.register("DigestRepository", SQLAlchemyDigestRepository(test_db_session))
    container.register("RepositoryRepository", SQLAlchemyRepositoryRepository(test_db_session))
    container.register("GitHubClient", mock_github_client)
    container.register("OpenAIClient", mock_openai_client)
    container.register("ProgressTracker", mock_progress_tracker)
    
    return container


@pytest.fixture
def test_app(test_settings, test_container):
    """Create test Flask application."""
    app = create_app(config_override={
        "database_url": test_settings.database_url,
        "testing": True
    })
    
    app.config['TESTING'] = True
    
    with app.app_context():
        yield app


@pytest.fixture
def test_client(test_app):
    """Create test client."""
    return test_app.test_client()


@pytest.fixture
def auth_headers():
    """Create authentication headers for testing."""
    return {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }