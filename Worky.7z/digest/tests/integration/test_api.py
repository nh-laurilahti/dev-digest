"""Integration tests for API endpoints."""

import pytest
import json
from datetime import date

from src.domain.entities import Digest, Repository


class TestDigestAPI:
    """Integration tests for digest endpoints."""
    
    def test_create_digest_endpoint(self, test_client, auth_headers):
        """Test POST /api/v1/digests endpoint."""
        data = {
            "repository": "owner/test-repo",
            "timespan": "today",
            "audience": "general"
        }
        
        response = test_client.post(
            '/api/v1/digests',
            data=json.dumps(data),
            headers=auth_headers
        )
        
        assert response.status_code == 201
        response_data = response.get_json()
        assert response_data['success'] is True
        assert 'session_id' in response_data
        assert 'digest' in response_data
    
    def test_create_digest_missing_fields(self, test_client, auth_headers):
        """Test digest creation with missing required fields."""
        data = {
            "repository": "owner/test-repo"
            # Missing timespan and audience
        }
        
        response = test_client.post(
            '/api/v1/digests',
            data=json.dumps(data),
            headers=auth_headers
        )
        
        assert response.status_code == 400
        response_data = response.get_json()
        assert response_data['error'] == 'Validation Error'
    
    def test_get_digest_by_id(self, test_client):
        """Test GET /api/v1/digests/<id> endpoint."""
        # This would need a digest to exist first
        response = test_client.get('/api/v1/digests/999')
        
        # Should return 404 for non-existent digest
        assert response.status_code == 404
    
    def test_list_digests(self, test_client):
        """Test GET /api/v1/digests endpoint."""
        response = test_client.get('/api/v1/digests')
        
        assert response.status_code == 200
        response_data = response.get_json()
        assert response_data['success'] is True
        assert 'digests' in response_data
        assert 'pagination' in response_data
    
    def test_list_digests_with_filters(self, test_client):
        """Test digest listing with filters."""
        response = test_client.get('/api/v1/digests?repository=owner/repo&page=1&per_page=5')
        
        assert response.status_code == 200
        response_data = response.get_json()
        assert response_data['pagination']['page'] == 1
        assert response_data['pagination']['per_page'] == 5


class TestRepositoryAPI:
    """Integration tests for repository endpoints."""
    
    def test_add_repository(self, test_client, auth_headers):
        """Test POST /api/v1/repositories endpoint."""
        data = {
            "path": "owner/test-repo",
            "name": "Test Repository",
            "active": True
        }
        
        response = test_client.post(
            '/api/v1/repositories',
            data=json.dumps(data),
            headers=auth_headers
        )
        
        assert response.status_code == 201
        response_data = response.get_json()
        assert response_data['success'] is True
        assert response_data['repository']['path'] == "owner/test-repo"
    
    def test_add_repository_missing_path(self, test_client, auth_headers):
        """Test repository creation with missing path."""
        data = {
            "name": "Test Repository"
            # Missing path
        }
        
        response = test_client.post(
            '/api/v1/repositories',
            data=json.dumps(data),
            headers=auth_headers
        )
        
        assert response.status_code == 400
    
    def test_list_repositories(self, test_client):
        """Test GET /api/v1/repositories endpoint."""
        response = test_client.get('/api/v1/repositories')
        
        assert response.status_code == 200
        response_data = response.get_json()
        assert response_data['success'] is True
        assert 'repositories' in response_data
    
    def test_list_active_repositories(self, test_client):
        """Test listing only active repositories."""
        response = test_client.get('/api/v1/repositories?active_only=true')
        
        assert response.status_code == 200
        response_data = response.get_json()
        assert response_data['success'] is True


class TestProgressAPI:
    """Integration tests for progress tracking endpoints."""
    
    def test_get_progress_not_found(self, test_client):
        """Test getting progress for non-existent session."""
        response = test_client.get('/api/v1/progress/non-existent-session')
        
        assert response.status_code == 404
    
    def test_list_all_sessions(self, test_client):
        """Test listing all progress sessions."""
        response = test_client.get('/api/v1/progress')
        
        assert response.status_code == 200
        response_data = response.get_json()
        assert response_data['success'] is True
        assert 'sessions' in response_data


class TestAPIInfo:
    """Tests for API information endpoints."""
    
    def test_health_check(self, test_client):
        """Test health check endpoint."""
        response = test_client.get('/health')
        
        assert response.status_code == 200
        data = response.get_json()
        assert data['status'] == 'healthy'
    
    def test_api_info(self, test_client):
        """Test API info endpoint."""
        response = test_client.get('/api/v1/info')
        
        assert response.status_code == 200
        data = response.get_json()
        assert 'name' in data
        assert 'version' in data
        assert 'endpoints' in data