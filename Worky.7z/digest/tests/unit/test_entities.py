"""Tests for domain entities."""

import pytest
from datetime import datetime, date
from uuid import uuid4

from src.domain.entities import (
    Digest, Repository, PullRequest, DigestEntry, 
    CommitInfo, ChangeType, AudienceType
)


class TestDigest:
    """Tests for Digest entity."""
    
    def test_digest_creation(self):
        """Test creating a digest."""
        digest = Digest(
            date=date.today(),
            repository="owner/repo",
            summary="Test summary",
            content="Test content",
            stats={"prs": 5},
            created_at=datetime.now()
        )
        
        assert digest.date == date.today()
        assert digest.repository == "owner/repo"
        assert digest.summary == "Test summary"
        assert digest.content == "Test content"
        assert digest.stats == {"prs": 5}
        assert digest.id is None  # Not set until saved
    
    def test_digest_with_id(self):
        """Test digest with ID."""
        digest = Digest(
            id=123,
            date=date.today(),
            repository="owner/repo",
            summary="Test summary",
            content="Test content"
        )
        
        assert digest.id == 123


class TestRepository:
    """Tests for Repository entity."""
    
    def test_repository_creation(self):
        """Test creating a repository."""
        repo = Repository(
            path="owner/repo",
            name="Test Repo",
            active=True,
            created_at=datetime.now()
        )
        
        assert repo.path == "owner/repo"
        assert repo.name == "Test Repo"
        assert repo.active is True
        assert repo.last_scan is None
        assert repo.id is None
    
    def test_repository_inactive(self):
        """Test creating inactive repository."""
        repo = Repository(
            path="owner/repo",
            name="Test Repo", 
            active=False
        )
        
        assert repo.active is False


class TestPullRequest:
    """Tests for PullRequest entity."""
    
    def test_pr_creation(self):
        """Test creating a pull request."""
        pr = PullRequest(
            id=123,
            number=45,
            title="Fix bug",
            description="Fixed critical bug",
            author="developer",
            created_at=datetime.now(),
            merged_at=datetime.now(),
            url="https://github.com/owner/repo/pull/45",
            files_changed=3,
            additions=50,
            deletions=10,
            labels=["bug", "hotfix"]
        )
        
        assert pr.id == 123
        assert pr.number == 45
        assert pr.title == "Fix bug"
        assert pr.author == "developer"
        assert pr.files_changed == 3
        assert pr.additions == 50
        assert pr.deletions == 10
        assert "bug" in pr.labels
        assert "hotfix" in pr.labels


class TestDigestEntry:
    """Tests for DigestEntry entity."""
    
    def test_entry_creation(self):
        """Test creating a digest entry."""
        entry = DigestEntry(
            title="New feature",
            summary="Added awesome feature",
            significance=0.8,
            category="feature"
        )
        
        assert entry.title == "New feature"
        assert entry.summary == "Added awesome feature"
        assert entry.significance == 0.8
        assert entry.category == "feature"
        assert entry.id is not None  # UUID generated
    
    def test_entry_with_metadata(self):
        """Test entry with metadata."""
        metadata = {"source": "github", "pr_number": 123}
        entry = DigestEntry(
            title="Bug fix",
            summary="Fixed issue",
            metadata=metadata
        )
        
        assert entry.metadata == metadata


class TestEnums:
    """Tests for enumeration types."""
    
    def test_change_type_enum(self):
        """Test ChangeType enum."""
        assert ChangeType.FEATURE.value == "feature"
        assert ChangeType.BUGFIX.value == "bugfix"
        assert ChangeType.REFACTOR.value == "refactor"
        assert ChangeType.DOCS.value == "docs"
        assert ChangeType.TEST.value == "test"
        assert ChangeType.CHORE.value == "chore"
    
    def test_audience_type_enum(self):
        """Test AudienceType enum."""
        assert AudienceType.FRONTEND.value == "frontend"
        assert AudienceType.BACKEND.value == "backend"
        assert AudienceType.DEVOPS.value == "devops"
        assert AudienceType.SECURITY.value == "security"
        assert AudienceType.DESIGN.value == "design"
        assert AudienceType.EXECUTIVE.value == "executive"
        assert AudienceType.GENERAL.value == "general"