"""Tests for application use cases."""

import pytest
from datetime import date
from unittest.mock import AsyncMock, Mock

from src.application.use_cases.create_digest import CreateDigestUseCase, CreateDigestRequest
from src.application.use_cases.get_digest import GetDigestUseCase, GetDigestByIdRequest
from src.domain.entities import Digest, AudienceType
from src.core.exceptions import ValidationError, NotFoundError


class TestCreateDigestUseCase:
    """Tests for CreateDigestUseCase."""
    
    @pytest.fixture
    def use_case(self):
        """Create use case with mocked dependencies."""
        digest_repo = AsyncMock()
        repository_repo = AsyncMock()
        github_client = AsyncMock()
        summary_generator = AsyncMock()
        progress_tracker = AsyncMock()
        
        return CreateDigestUseCase(
            digest_repository=digest_repo,
            repository_repository=repository_repo,
            github_client=github_client,
            summary_generator=summary_generator,
            progress_tracker=progress_tracker
        ), {
            'digest_repo': digest_repo,
            'repository_repo': repository_repo,
            'github_client': github_client,
            'summary_generator': summary_generator,
            'progress_tracker': progress_tracker
        }
    
    @pytest.mark.asyncio
    async def test_create_digest_success(self, use_case):
        """Test successful digest creation."""
        use_case_obj, mocks = use_case
        
        # Setup mocks
        mocks['digest_repo'].get_by_date.return_value = None
        mocks['github_client'].validate_repository.return_value = True
        mocks['github_client'].get_pull_requests.return_value = []
        mocks['summary_generator'].analyze_changes.return_value = []
        mocks['summary_generator'].generate_summary.return_value = "Test summary"
        
        created_digest = Digest(
            id=1,
            date=date.today(),
            repository="owner/repo",
            summary="Test summary",
            content="Test content"
        )
        mocks['digest_repo'].create.return_value = created_digest
        
        # Create request
        request = CreateDigestRequest(
            repository="owner/repo",
            timespan="today",
            audience="general"
        )
        
        # Execute
        response = await use_case_obj.execute(request)
        
        # Assertions
        assert response.success is True
        assert response.digest.id == 1
        assert response.digest.repository == "owner/repo"
        assert response.session_id is not None
    
    @pytest.mark.asyncio
    async def test_create_digest_invalid_repository(self, use_case):
        """Test digest creation with invalid repository."""
        use_case_obj, _ = use_case
        
        # Create request with invalid repository
        request = CreateDigestRequest(
            repository="",  # Invalid
            timespan="today",
            audience="general"
        )
        
        # Execute and expect validation error
        with pytest.raises(ValidationError) as exc_info:
            await use_case_obj.execute(request)
        
        assert "Repository path is required" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_create_digest_repository_not_accessible(self, use_case):
        """Test digest creation with inaccessible repository."""
        use_case_obj, mocks = use_case
        
        # Setup mocks
        mocks['digest_repo'].get_by_date.return_value = None
        mocks['github_client'].validate_repository.return_value = False
        
        request = CreateDigestRequest(
            repository="owner/repo",
            timespan="today",
            audience="general"
        )
        
        # Execute and expect validation error
        with pytest.raises(ValidationError) as exc_info:
            await use_case_obj.execute(request)
        
        assert "not found or inaccessible" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_create_digest_existing_digest(self, use_case):
        """Test digest creation when digest already exists."""
        use_case_obj, mocks = use_case
        
        existing_digest = Digest(
            id=1,
            date=date.today(),
            repository="owner/repo",
            summary="Existing summary",
            content="Existing content"
        )
        mocks['digest_repo'].get_by_date.return_value = existing_digest
        
        request = CreateDigestRequest(
            repository="owner/repo",
            timespan="today",
            audience="general"
        )
        
        response = await use_case_obj.execute(request)
        
        assert response.success is True
        assert response.digest.id == 1
        assert "already exists" in response.message


class TestGetDigestUseCase:
    """Tests for GetDigestUseCase."""
    
    @pytest.fixture
    def use_case(self):
        """Create use case with mocked dependencies."""
        digest_repo = AsyncMock()
        return GetDigestUseCase(digest_repository=digest_repo), digest_repo
    
    @pytest.mark.asyncio
    async def test_get_digest_by_id_success(self, use_case):
        """Test successful digest retrieval by ID."""
        use_case_obj, digest_repo = use_case
        
        digest = Digest(
            id=1,
            date=date.today(),
            repository="owner/repo",
            summary="Test summary",
            content="Test content"
        )
        digest_repo.get_by_id.return_value = digest
        
        request = GetDigestByIdRequest(digest_id=1)
        response = await use_case_obj.execute_by_id(request)
        
        assert response.success is True
        assert response.digest.id == 1
    
    @pytest.mark.asyncio
    async def test_get_digest_by_id_not_found(self, use_case):
        """Test digest retrieval when not found."""
        use_case_obj, digest_repo = use_case
        
        digest_repo.get_by_id.return_value = None
        
        request = GetDigestByIdRequest(digest_id=999)
        
        with pytest.raises(NotFoundError) as exc_info:
            await use_case_obj.execute_by_id(request)
        
        assert "not found" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_get_digest_invalid_id(self, use_case):
        """Test digest retrieval with invalid ID."""
        use_case_obj, _ = use_case
        
        request = GetDigestByIdRequest(digest_id=-1)
        
        with pytest.raises(ValueError) as exc_info:
            await use_case_obj.execute_by_id(request)
        
        assert "positive integer" in str(exc_info.value)