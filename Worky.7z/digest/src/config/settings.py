"""Application settings and configuration management."""

import os
from functools import lru_cache
from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings with environment variable support."""
    
    # Application
    app_name: str = "Daily Dev Digest"
    app_version: str = "1.0.0"
    debug: bool = False
    secret_key: str = "dev-secret-key-change-in-production"
    
    # Server
    host: str = "0.0.0.0"
    port: int = 5000
    
    # Database
    database_url: str = "sqlite:///digests.db"
    database_echo: bool = False
    
    # External APIs
    github_token: Optional[str] = None
    openai_api_key: Optional[str] = None
    
    # Features
    enable_ai_summaries: bool = True
    enable_caching: bool = True
    enable_scheduling: bool = True
    
    # Rate Limiting
    github_rate_limit: int = 5000  # requests per hour
    openai_rate_limit: int = 60   # requests per minute
    
    # Digest Generation
    default_timespan: str = "today"
    default_audience: str = "general"
    max_prs_per_request: int = 100
    digest_cache_ttl: int = 3600  # seconds
    
    # Progress Tracking
    progress_cleanup_interval: int = 300  # seconds
    progress_max_age: int = 3600  # seconds
    
    # Logging
    log_level: str = "INFO"
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    log_file: Optional[str] = None
    
    # Security
    cors_origins: list[str] = ["*"]
    allowed_hosts: list[str] = ["*"]
    
    # Scheduler
    enable_scheduler: bool = True
    
    # Email (Optional)
    smtp_host: Optional[str] = None
    smtp_port: int = 587
    smtp_user: Optional[str] = None
    smtp_password: Optional[str] = None
    
    # Slack (Optional)
    slack_webhook_url: Optional[str] = None
    
    # AI Model Configuration
    openai_model: str = "gpt-5-mini"
    available_models: list[str] = [
        "gpt-5-mini",
        "gpt-4-turbo",
        "gpt-4o",
        "gpt-3.5-turbo"
    ]
    
    # Prompt Customization
    custom_system_prompt: Optional[str] = None
    custom_summary_template: Optional[str] = None
    
    # Settings Management
    allow_settings_override: bool = True
    
    class Config:
        """Pydantic configuration."""
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    """Get cached application settings."""
    return Settings()