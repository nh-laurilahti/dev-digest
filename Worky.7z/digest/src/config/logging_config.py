"""Logging configuration for the application."""

import logging
import sys
from typing import Dict, Any

from .settings import get_settings


def setup_logging() -> None:
    """Configure application logging."""
    settings = get_settings()
    
    # Create formatter
    formatter = logging.Formatter(settings.log_format)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, settings.log_level.upper()))
    
    # Clear existing handlers
    root_logger.handlers.clear()
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # File handler (if configured)
    if settings.log_file:
        file_handler = logging.FileHandler(settings.log_file)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)
    
    # Configure specific loggers
    _configure_loggers()


def _configure_loggers() -> None:
    """Configure specific logger levels and settings."""
    logger_configs: Dict[str, Dict[str, Any]] = {
        "werkzeug": {"level": "WARNING"},
        "urllib3": {"level": "WARNING"},
        "github": {"level": "INFO"},
        "openai": {"level": "INFO"},
        "apscheduler": {"level": "INFO"},
    }
    
    for logger_name, config in logger_configs.items():
        logger = logging.getLogger(logger_name)
        if "level" in config:
            logger.setLevel(getattr(logging, config["level"]))


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance for the given name."""
    return logging.getLogger(name)