"""Simple status tracking for digest operations."""

from datetime import datetime
from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum

from ..config.logging_config import get_logger

logger = get_logger(__name__)


class OperationStatus(Enum):
    """Simple operation statuses."""
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class StatusInfo:
    """Simple status information."""
    session_id: str
    status: OperationStatus
    message: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    error: Optional[str] = None
    digest_id: Optional[int] = None


class SimpleStatusTracker:
    """Simple in-memory status tracker."""
    
    def __init__(self):
        self._statuses: Dict[str, StatusInfo] = {}
    
    def start_operation(self, session_id: str, message: str = "Starting operation") -> None:
        """Start tracking an operation."""
        self._statuses[session_id] = StatusInfo(
            session_id=session_id,
            status=OperationStatus.RUNNING,
            message=message,
            started_at=datetime.now()
        )
        logger.info(f"Started operation {session_id}: {message}")
    
    def complete_operation(
        self, 
        session_id: str, 
        message: str = "Operation completed",
        digest_id: Optional[int] = None
    ) -> None:
        """Mark an operation as completed."""
        if session_id in self._statuses:
            status_info = self._statuses[session_id]
            status_info.status = OperationStatus.COMPLETED
            status_info.message = message
            status_info.completed_at = datetime.now()
            status_info.digest_id = digest_id
            logger.info(f"Completed operation {session_id}: {message}")
    
    def fail_operation(self, session_id: str, error: str) -> None:
        """Mark an operation as failed."""
        if session_id in self._statuses:
            status_info = self._statuses[session_id]
            status_info.status = OperationStatus.FAILED
            status_info.message = f"Operation failed: {error}"
            status_info.completed_at = datetime.now()
            status_info.error = error
            logger.error(f"Failed operation {session_id}: {error}")
    
    def get_status(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get status for a session."""
        if session_id not in self._statuses:
            return None
        
        status_info = self._statuses[session_id]
        return {
            "session_id": session_id,
            "status": status_info.status.value,
            "message": status_info.message,
            "started_at": status_info.started_at.isoformat(),
            "completed_at": status_info.completed_at.isoformat() if status_info.completed_at else None,
            "error": status_info.error,
            "digest_id": status_info.digest_id,
            "is_complete": status_info.status in [OperationStatus.COMPLETED, OperationStatus.FAILED]
        }
    
    def cleanup_old_statuses(self) -> None:
        """Remove old completed statuses (keep last 10)."""
        completed_sessions = [
            (session_id, info) for session_id, info in self._statuses.items()
            if info.status in [OperationStatus.COMPLETED, OperationStatus.FAILED]
        ]
        
        if len(completed_sessions) > 10:
            # Sort by completion time and keep only the most recent 10
            completed_sessions.sort(key=lambda x: x[1].completed_at or x[1].started_at, reverse=True)
            sessions_to_remove = [session_id for session_id, _ in completed_sessions[10:]]
            
            for session_id in sessions_to_remove:
                del self._statuses[session_id]
                logger.debug(f"Cleaned up old status: {session_id}")