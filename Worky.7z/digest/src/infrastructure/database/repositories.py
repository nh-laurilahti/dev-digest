"""Concrete repository implementations using SQLAlchemy."""

from datetime import datetime, date
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc, and_

from ...domain.entities import Digest, Repository
from ...domain.repositories import DigestRepository, RepositoryRepository
from ...config.logging_config import get_logger
from ...utils.helpers import utc_now
from .models import DigestModel, RepositoryModel, UserSettingsModel

logger = get_logger(__name__)


class SQLAlchemyDigestRepository(DigestRepository):
    """SQLAlchemy implementation of DigestRepository."""
    
    def __init__(self, session: Session) -> None:
        self.session = session
    
    async def create(self, digest: Digest) -> Digest:
        """Create a new digest."""
        logger.info(f"Creating digest for repository: {digest.repository}, date: {digest.date}")
        
        db_digest = DigestModel(
            date=digest.date,
            repository=digest.repository,
            summary=digest.summary,
            content=digest.content,
            stats=digest.stats,
            created_at=digest.created_at
        )
        
        self.session.add(db_digest)
        self.session.commit()
        self.session.refresh(db_digest)
        
        # Convert back to domain entity
        result = Digest(
            id=db_digest.id,
            date=db_digest.date,
            repository=db_digest.repository,
            summary=db_digest.summary,
            content=db_digest.content,
            stats=db_digest.stats or {},
            created_at=db_digest.created_at
        )
        
        logger.info(f"Created digest with ID: {result.id}")
        return result
    
    async def get_by_id(self, digest_id: int) -> Optional[Digest]:
        """Get a digest by ID."""
        db_digest = self.session.query(DigestModel).filter(DigestModel.id == digest_id).first()
        
        if not db_digest:
            return None
        
        return Digest(
            id=db_digest.id,
            date=db_digest.date,
            repository=db_digest.repository,
            summary=db_digest.summary,
            content=db_digest.content,
            stats=db_digest.stats or {},
            created_at=db_digest.created_at
        )
    
    async def get_by_date(self, date: date, repository: str) -> Optional[Digest]:
        """Get a digest by date and repository."""
        db_digest = self.session.query(DigestModel).filter(
            and_(DigestModel.date == date, DigestModel.repository == repository)
        ).first()
        
        if not db_digest:
            return None
        
        return Digest(
            id=db_digest.id,
            date=db_digest.date,
            repository=db_digest.repository,
            summary=db_digest.summary,
            content=db_digest.content,
            stats=db_digest.stats or {},
            created_at=db_digest.created_at
        )
    
    async def get_recent(
        self, 
        limit: int = 10, 
        offset: int = 0,
        repository: Optional[str] = None
    ) -> List[Digest]:
        """Get recent digests with pagination."""
        query = self.session.query(DigestModel)
        
        if repository:
            query = query.filter(DigestModel.repository == repository)
        
        db_digests = (
            query.order_by(desc(DigestModel.date), desc(DigestModel.created_at))
            .offset(offset)
            .limit(limit)
            .all()
        )
        
        return [
            Digest(
                id=db_digest.id,
                date=db_digest.date,
                repository=db_digest.repository,
                summary=db_digest.summary,
                content=db_digest.content,
                stats=db_digest.stats or {},
                created_at=db_digest.created_at
            )
            for db_digest in db_digests
        ]
    
    async def update(self, digest: Digest) -> Digest:
        """Update an existing digest."""
        if not digest.id:
            raise ValueError("Digest ID is required for update")
        
        db_digest = self.session.query(DigestModel).filter(DigestModel.id == digest.id).first()
        if not db_digest:
            raise ValueError(f"Digest with ID {digest.id} not found")
        
        db_digest.date = digest.date
        db_digest.repository = digest.repository
        db_digest.summary = digest.summary
        db_digest.content = digest.content
        db_digest.stats = digest.stats
        
        self.session.commit()
        self.session.refresh(db_digest)
        
        result = Digest(
            id=db_digest.id,
            date=db_digest.date,
            repository=db_digest.repository,
            summary=db_digest.summary,
            content=db_digest.content,
            stats=db_digest.stats or {},
            created_at=db_digest.created_at
        )
        
        logger.info(f"Updated digest with ID: {result.id}")
        return result
    
    async def delete(self, digest_id: int) -> bool:
        """Delete a digest."""
        db_digest = self.session.query(DigestModel).filter(DigestModel.id == digest_id).first()
        if not db_digest:
            return False
        
        self.session.delete(db_digest)
        self.session.commit()
        
        logger.info(f"Deleted digest with ID: {digest_id}")
        return True


class SQLAlchemyRepositoryRepository(RepositoryRepository):
    """SQLAlchemy implementation of RepositoryRepository."""
    
    def __init__(self, session: Session) -> None:
        self.session = session
    
    async def create(self, repository: Repository) -> Repository:
        """Create a new repository."""
        logger.info(f"Creating repository: {repository.path}")
        
        db_repo = RepositoryModel(
            path=repository.path,
            name=repository.name,
            active=repository.active,
            last_scan=repository.last_scan,
            created_at=repository.created_at
        )
        
        self.session.add(db_repo)
        self.session.commit()
        self.session.refresh(db_repo)
        
        result = Repository(
            id=db_repo.id,
            path=db_repo.path,
            name=db_repo.name,
            active=db_repo.active,
            last_scan=db_repo.last_scan,
            created_at=db_repo.created_at
        )
        
        logger.info(f"Created repository with ID: {result.id}")
        return result
    
    async def get_by_id(self, repo_id: int) -> Optional[Repository]:
        """Get a repository by ID."""
        db_repo = self.session.query(RepositoryModel).filter(RepositoryModel.id == repo_id).first()
        
        if not db_repo:
            return None
        
        return Repository(
            id=db_repo.id,
            path=db_repo.path,
            name=db_repo.name,
            active=db_repo.active,
            last_scan=db_repo.last_scan,
            created_at=db_repo.created_at
        )
    
    async def get_by_path(self, path: str) -> Optional[Repository]:
        """Get a repository by path."""
        db_repo = self.session.query(RepositoryModel).filter(RepositoryModel.path == path).first()
        
        if not db_repo:
            return None
        
        return Repository(
            id=db_repo.id,
            path=db_repo.path,
            name=db_repo.name,
            active=db_repo.active,
            last_scan=db_repo.last_scan,
            created_at=db_repo.created_at
        )
    
    async def get_active(self) -> List[Repository]:
        """Get all active repositories."""
        db_repos = self.session.query(RepositoryModel).filter(RepositoryModel.active == True).all()
        
        return [
            Repository(
                id=db_repo.id,
                path=db_repo.path,
                name=db_repo.name,
                active=db_repo.active,
                last_scan=db_repo.last_scan,
                created_at=db_repo.created_at
            )
            for db_repo in db_repos
        ]
    
    async def get_all(self) -> List[Repository]:
        """Get all repositories."""
        db_repos = self.session.query(RepositoryModel).all()
        
        return [
            Repository(
                id=db_repo.id,
                path=db_repo.path,
                name=db_repo.name,
                active=db_repo.active,
                last_scan=db_repo.last_scan,
                created_at=db_repo.created_at
            )
            for db_repo in db_repos
        ]
    
    async def update(self, repository: Repository) -> Repository:
        """Update an existing repository."""
        if not repository.id:
            raise ValueError("Repository ID is required for update")
        
        db_repo = self.session.query(RepositoryModel).filter(RepositoryModel.id == repository.id).first()
        if not db_repo:
            raise ValueError(f"Repository with ID {repository.id} not found")
        
        db_repo.path = repository.path
        db_repo.name = repository.name
        db_repo.active = repository.active
        db_repo.last_scan = repository.last_scan
        
        self.session.commit()
        self.session.refresh(db_repo)
        
        result = Repository(
            id=db_repo.id,
            path=db_repo.path,
            name=db_repo.name,
            active=db_repo.active,
            last_scan=db_repo.last_scan,
            created_at=db_repo.created_at
        )
        
        logger.info(f"Updated repository with ID: {result.id}")
        return result
    
    async def delete(self, repo_id: int) -> bool:
        """Delete a repository."""
        db_repo = self.session.query(RepositoryModel).filter(RepositoryModel.id == repo_id).first()
        if not db_repo:
            return False
        
        self.session.delete(db_repo)
        self.session.commit()
        
        logger.info(f"Deleted repository with ID: {repo_id}")
        return True


class SQLAlchemySettingsRepository:
    """SQLAlchemy implementation for user settings management."""
    
    def __init__(self, session: Session) -> None:
        self.session = session
    
    def get_setting(self, key: str, default_value=None):
        """Get a setting by key."""
        setting = self.session.query(UserSettingsModel).filter(UserSettingsModel.key == key).first()
        
        if not setting:
            return default_value
        
        return setting.value
    
    def set_setting(self, key: str, value, description: str = "", setting_type: str = "string"):
        """Set a setting value."""
        setting = self.session.query(UserSettingsModel).filter(UserSettingsModel.key == key).first()
        
        if setting:
            setting.value = value
            setting.description = description
            setting.setting_type = setting_type
            setting.updated_at = utc_now()
        else:
            setting = UserSettingsModel(
                key=key,
                value=value,
                description=description,
                setting_type=setting_type
            )
            self.session.add(setting)
        
        self.session.commit()
        self.session.refresh(setting)
        logger.info(f"Updated setting: {key}")
        
        return setting.to_dict()
    
    def get_all_settings(self):
        """Get all settings."""
        settings = self.session.query(UserSettingsModel).all()
        return [setting.to_dict() for setting in settings]
    
    def get_all_settings_sync(self):
        """Synchronous version of get_all_settings."""
        settings = self.session.query(UserSettingsModel).all()
        return [setting.to_dict() for setting in settings]
    
    def delete_setting(self, key: str) -> bool:
        """Delete a setting."""
        setting = self.session.query(UserSettingsModel).filter(UserSettingsModel.key == key).first()
        
        if not setting:
            return False
        
        self.session.delete(setting)
        self.session.commit()
        logger.info(f"Deleted setting: {key}")
        
        return True