"""SQLAlchemy database models."""

from datetime import datetime, date
from typing import Dict, Any

from sqlalchemy import Column, Integer, String, Text, Date, DateTime, Boolean, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

from ...config.logging_config import get_logger
from ...utils.helpers import utc_now

logger = get_logger(__name__)

Base = declarative_base()


class DigestModel(Base):
    """Database model for digest reports."""
    
    __tablename__ = "digests"
    
    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False, index=True)
    repository = Column(String(200), nullable=False, index=True)
    summary = Column(Text)
    content = Column(Text, nullable=False)
    stats = Column(JSON)  # Store statistics as JSON
    created_at = Column(DateTime, default=utc_now, nullable=False)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary."""
        return {
            'id': self.id,
            'date': self.date.isoformat() if self.date else None,
            'repository': self.repository,
            'summary': self.summary,
            'content': self.content,
            'stats': self.stats,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }


class RepositoryModel(Base):
    """Database model for tracked repositories."""
    
    __tablename__ = "repositories"
    
    id = Column(Integer, primary_key=True)
    path = Column(String(200), nullable=False, unique=True, index=True)
    name = Column(String(200), nullable=False)
    active = Column(Boolean, default=True, nullable=False, index=True)
    last_scan = Column(DateTime)
    created_at = Column(DateTime, default=utc_now, nullable=False)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary."""
        return {
            'id': self.id,
            'path': self.path,
            'name': self.name,
            'active': self.active,
            'last_scan': self.last_scan.isoformat() if self.last_scan else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }


class UserSettingsModel(Base):
    """Database model for user settings and preferences."""
    
    __tablename__ = "user_settings"
    
    id = Column(Integer, primary_key=True)
    key = Column(String(100), nullable=False, unique=True, index=True)
    value = Column(JSON)
    description = Column(Text)
    setting_type = Column(String(50), default="string")
    created_at = Column(DateTime, default=utc_now, nullable=False)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now, nullable=False)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary."""
        return {
            'id': self.id,
            'key': self.key,
            'value': self.value,
            'description': self.description,
            'setting_type': self.setting_type,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
        }