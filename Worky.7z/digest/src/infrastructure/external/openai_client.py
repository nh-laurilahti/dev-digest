"""OpenAI API client implementation."""

import json
from typing import List, Dict, Any, Optional
from dataclasses import asdict
from datetime import datetime

import openai
from openai import AsyncOpenAI

from ...domain.entities import PullRequest, DigestEntry, AudienceType, ChangeAnalysis
from ...domain.services import SummaryGenerator
from ...core.exceptions import ExternalServiceError, ConfigurationError
from ...config.logging_config import get_logger

logger = get_logger(__name__)


class OpenAIClient(SummaryGenerator):
    """OpenAI API client for generating summaries."""
    
    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-5-mini"):
        if not api_key:
            raise ConfigurationError("OpenAI API key is required")
        
        self.client = AsyncOpenAI(api_key=api_key)
        self.model = model
    
    async def summarize_change(
        self, 
        pr: PullRequest, 
        analysis: "ChangeAnalysis",
        audience: AudienceType = AudienceType.GENERAL
    ) -> DigestEntry:
        """Generate a summary for a single change."""
        try:
            logger.info(f"Summarizing PR #{pr.number} for {audience.value}")
            
            # Prepare PR context for analysis
            pr_context = self._prepare_single_pr_context(pr)
            
            system_prompt = f"""You are a technical analyst reviewing a pull request for {audience.value} stakeholders. 
            {self._get_system_prompt(audience)}
            
            Analyze this PR and provide:
            1. A clear, concise title (improve the original if needed)
            2. A meaningful 2-3 sentence summary explaining what changed and why, focused on what matters to {audience.value}
            3. Significance score (0.0-1.0) based on impact to {audience.value} concerns
            4. Change category: feature, bugfix, refactor, documentation, testing, configuration, architecture
            
            Return valid JSON with: title, summary, significance, category"""
            
            user_prompt = f"""Analyze this pull request:

{pr_context}

Focus on the business impact and technical significance. Make the summary informative and specific."""

            try:
                print(f"DEBUG: Attempting OpenAI analysis for PR #{pr.number}")
                response = await self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    temperature=0.3,
                    max_tokens=500
                )
                
                content = response.choices[0].message.content.strip()
                
                # Parse JSON response
                if content.startswith("```json"):
                    content = content.split("```json")[1].split("```")[0].strip()
                elif content.startswith("```"):
                    content = content.split("```")[1].split("```")[0].strip()
                
                analysis_data = json.loads(content)
                
                # Create digest entry from AI analysis
                entry = DigestEntry(
                    title=analysis_data.get("title", pr.title),
                    summary=analysis_data.get("summary", pr.body[:200] + "..." if len(pr.body) > 200 else pr.body),
                    author=pr.author,
                    pr_url=pr.html_url,
                    labels=pr.labels,
                    significance=float(analysis_data.get("significance", 0.5)),
                    change_type=analysis_data.get("category", "other"),
                    is_ongoing=not bool(pr.merged_at)
                )
                
                return entry
                
            except (json.JSONDecodeError, openai.OpenAIError) as e:
                print(f"DEBUG: AI analysis failed for PR #{pr.number}: {e}")
                logger.warning(f"AI analysis failed for PR #{pr.number}, falling back to basic entry: {e}")
                # Fallback to enhanced basic entry
                return self._create_fallback_entry(pr, audience)
            except Exception as e:
                logger.error(f"Unexpected error in AI analysis for PR #{pr.number}: {e}")
                # Fallback to enhanced basic entry
                return self._create_fallback_entry(pr, audience)
            
        except Exception as e:
            logger.error(f"Error summarizing change: {e}")
            raise ExternalServiceError(
                f"Failed to summarize change: {e}",
                service="openai"
            )
    
    async def create_digest_summary(self, entries: List[DigestEntry], audience: AudienceType = AudienceType.GENERAL, repository: str = "", timespan: str = "today") -> str:
        """Create a brief summary of all digest entries."""
        try:
            logger.info(f"Creating digest summary for {len(entries)} entries")
            
            # Debug: Log entry details
            for i, entry in enumerate(entries[:3]):  # Log first 3 entries
                logger.info(f"Entry {i}: title='{entry.title}', change_type='{entry.change_type}', significance={entry.significance}")
            
            if not entries:
                return "No changes found for the specified time period."
            
            # Group entries by change type
            by_type = {}
            for entry in entries:
                change_type = getattr(entry, 'change_type', 'other') or "other"
                if change_type not in by_type:
                    by_type[change_type] = []
                by_type[change_type].append(entry)
            
            summary_parts = []
            total_changes = len(entries)
            
            # Green header with repository and timespan info
            repo_display = repository.split('/')[-1] if '/' in repository else repository
            timespan_display = {
                "today": "Last 24 Hours",
                "yesterday": "Yesterday", 
                "last_week": "Last Week",
                "last_month": "Last Month"
            }.get(timespan, timespan.title())
            
            summary_parts.append(f"# 📊 {repo_display} - {timespan_display}")
            summary_parts.append(f"")
            
            # Blue sub-header with stats  
            summary_parts.append(f"## 📈 Overview")
            summary_parts.append(f"**Total Changes:** {total_changes}")
            if audience != AudienceType.GENERAL:
                summary_parts.append(f"**Focus:** {audience.value.title()} perspective")
            summary_parts.append(f"")
            
            # Change type breakdown with green checkmarks
            summary_parts.append(f"## 🔄 Change Types")
            for change_type, type_entries in by_type.items():
                count = len(type_entries)
                # Use appropriate emoji based on change type
                emoji_map = {
                    "feature": "✨",
                    "bugfix": "🐛", 
                    "refactor": "♻️",
                    "documentation": "📚",
                    "testing": "🧪",
                    "configuration": "⚙️",
                    "architecture": "🏗️",
                    "other": "📝"
                }
                emoji = emoji_map.get(change_type, "📝")
                summary_parts.append(f"✅ **{count} {change_type.title()}** changes {emoji}")
            
            summary_parts.append(f"")
            
            # Highlight significant changes with orange dots for high impact
            significant = [e for e in entries if e.significance > 0.7]
            breaking_changes = [e for e in entries if "breaking" in (e.title or "").lower() or "break" in (e.summary or "").lower()]
            
            def _first_sentences(text: str, max_chars: int = 280, max_sentences: int = 2) -> str:
                if not text:
                    return ""
                # Split by sentence terminators and assemble up to max_sentences within max_chars
                sentences = []
                current = 0
                for part in text.replace('\n', ' ').split('. '):
                    if not part:
                        continue
                    sentence = part if part.endswith('.') else part + '.'
                    if len(sentences) < max_sentences and current + len(sentence) <= max_chars:
                        sentences.append(sentence)
                        current += len(sentence)
                    else:
                        break
                combined = ' '.join(sentences).strip()
                # Fallback to trimmed text if splitting failed
                return combined or (text[:max_chars].rstrip() + ('' if len(text) <= max_chars else '...'))

            if significant:
                summary_parts.append(f"## ⭐ High Impact Changes")
                for entry in significant[:5]:  # Top 5
                    impact_level = int(entry.significance * 100)
                    summary_parts.append(f"✅ **{entry.title}** ({impact_level}% impact)")
                    if entry.summary:
                        summary_parts.append(f"   └─ {_first_sentences(entry.summary)}")
                summary_parts.append(f"")
            
            if breaking_changes:
                summary_parts.append(f"## 🔴 Breaking Changes")
                for entry in breaking_changes:
                    summary_parts.append(f"🟠 **{entry.title}**")
                    if entry.summary:
                        summary_parts.append(f"   └─ {_first_sentences(entry.summary)}")
                summary_parts.append(f"")

            # Detailed sections for key change types
            feature_entries = sorted(by_type.get('feature', []), key=lambda e: e.significance, reverse=True)
            bugfix_entries = sorted(by_type.get('bugfix', []), key=lambda e: e.significance, reverse=True)

            if feature_entries:
                summary_parts.append(f"## ✨ Feature Changes ({len(feature_entries)})")
                for entry in feature_entries[:5]:
                    impact_level = int(entry.significance * 100)
                    summary_parts.append(f"✅ **{entry.title}** ({impact_level}% impact)")
                    if entry.summary:
                        summary_parts.append(f"   └─ {_first_sentences(entry.summary)}")
                summary_parts.append("")

            if bugfix_entries:
                summary_parts.append(f"## 🐛 Bug Fixes ({len(bugfix_entries)})")
                for entry in bugfix_entries[:5]:
                    impact_level = int(entry.significance * 100)
                    summary_parts.append(f"✅ **{entry.title}** ({impact_level}% impact)")
                    if entry.summary:
                        summary_parts.append(f"   └─ {_first_sentences(entry.summary)}")
                summary_parts.append("")
            
            # Summary statistics - only show sections that have content
            completed = [e for e in entries if not e.is_ongoing]
            ongoing = [e for e in entries if e.is_ongoing]
            
            if completed or ongoing:
                summary_parts.append(f"## 📋 Status Breakdown")
                if completed:
                    summary_parts.append(f"✅ **Completed:** {len(completed)} changes")
                if ongoing:
                    summary_parts.append(f"🚧 **Ongoing:** {len(ongoing)} changes")
            
            summary_parts.append(f"")
            summary_parts.append(f"---")
            summary_parts.append(f"*Report generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*")
            
            return "\n".join(summary_parts)
            
        except Exception as e:
            logger.error(f"Error creating digest summary: {e}")
            raise ExternalServiceError(
                f"Failed to create digest summary: {e}",
                service="openai"
            )
    
    async def create_executive_summary(
        self,
        entries: List[DigestEntry],
        repository: str,
        audience: AudienceType = AudienceType.GENERAL,
        timespan: str = "24 hours"
    ) -> str:
        """Create a detailed executive summary."""
        try:
            logger.info(f"Creating executive summary for {len(entries)} entries")
            
            if not entries:
                return f"No changes were made to {repository} in the last {timespan}."
            
            # Prepare context for AI
            context = f"Repository: {repository}\nTimespan: {timespan}\n\n"
            context += "Changes:\n"
            for entry in entries:
                context += f"- {entry.title} (by {entry.author})\n"
                context += f"  Summary: {entry.summary[:100]}...\n"
                context += f"  Type: {entry.change_type}, Significance: {entry.significance}\n\n"
            
            system_prompt = self._get_system_prompt(audience) + """
Create a structured executive summary using markdown formatting with:
- Green headers (# Main Title)
- Blue sub-headers (## Section Title) 
- Bold labels for key information
- Green checkmarks (✅) for completed items
- Orange dots (🟠) for breaking changes or risks
- Professional tone focusing on business impact
"""
            user_prompt = f"""
Create a structured executive summary for this development activity:

{context}

Target audience: {audience.value}

Please format the response with:
- # Main header with repository name and timespan
- ## Key Achievements section with ✅ checkmarks
- ## Business Impact section with metrics and value
- ## Technical Highlights section 
- ## Risks & Considerations section with 🟠 for concerns
- ## Next Steps section

Use markdown formatting throughout with bold labels and structured lists.
"""
            
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.5,
                max_tokens=1000
            )
            
            summary = response.choices[0].message.content.strip()
            logger.info(f"Generated executive summary of {len(summary)} characters")
            
            return summary
            
        except openai.OpenAIError as e:
            logger.error(f"OpenAI API error: {e}")
            raise ExternalServiceError(
                f"Failed to generate executive summary: {e}",
                service="openai"
            )
        except Exception as e:
            logger.error(f"Unexpected error generating executive summary: {e}")
            raise ExternalServiceError(
                f"Unexpected error generating executive summary: {e}",
                service="openai"
            )
    
    async def analyze_changes(self, pull_requests: List[PullRequest]) -> List[DigestEntry]:
        """Analyze pull requests and categorize changes."""
        try:
            logger.info(f"Analyzing {len(pull_requests)} PRs for change categorization")
            
            if not pull_requests:
                return []
            
            entries = []
            
            # Process PRs in batches to avoid token limits
            batch_size = 5
            for i in range(0, len(pull_requests), batch_size):
                batch = pull_requests[i:i + batch_size]
                batch_entries = await self._analyze_pr_batch(batch)
                entries.extend(batch_entries)
            
            logger.info(f"Analyzed changes into {len(entries)} digest entries")
            return entries
            
        except Exception as e:
            logger.error(f"Error analyzing changes: {e}")
            raise ExternalServiceError(
                f"Failed to analyze changes: {e}",
                service="openai"
            )
    
    async def _analyze_pr_batch(self, pull_requests: List[PullRequest]) -> List[DigestEntry]:
        """Analyze a batch of pull requests."""
        pr_context = self._prepare_pr_context(pull_requests)
        
        system_prompt = """
        You are a technical analyst reviewing pull requests. For each PR, provide:
        1. A concise title summarizing the change
        2. A brief technical summary
        3. Significance score (0.0-1.0) based on impact and complexity
        4. Change category (feature, bugfix, refactor, docs, test, chore)
        
        Return valid JSON array with objects containing: title, summary, significance, category.
        """
        
        user_prompt = f"""
        Analyze these pull requests and return a JSON array:
        
        {pr_context}
        
        Focus on technical impact and business value.
        """
        
        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.3,
                max_tokens=1500
            )
            
            content = response.choices[0].message.content.strip()
            
            # Parse JSON response
            if content.startswith("```json"):
                content = content.split("```json")[1].split("```")[0].strip()
            elif content.startswith("```"):
                content = content.split("```")[1].split("```")[0].strip()
            
            analysis_data = json.loads(content)
            
            entries = []
            for item in analysis_data:
                entry = DigestEntry(
                    title=item.get("title", ""),
                    summary=item.get("summary", ""),
                    significance=float(item.get("significance", 0.5)),
                    category=item.get("category", "chore"),
                    metadata={"source": "openai_analysis"}
                )
                entries.append(entry)
            
            return entries
            
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse OpenAI response as JSON: {e}")
            # Fallback to basic entries
            return [
                DigestEntry(
                    title=pr.title,
                    summary=pr.description[:200] + "..." if len(pr.description) > 200 else pr.description,
                    significance=0.5,
                    category="feature" if "feat" in pr.title.lower() else "bugfix" if "fix" in pr.title.lower() else "chore"
                )
                for pr in pull_requests
            ]
    
    def _prepare_pr_context(self, pull_requests: List[PullRequest]) -> str:
        """Prepare pull request context for AI analysis."""
        context_parts = []
        
        for pr in pull_requests:
            pr_info = f"""
PR #{pr.number}: {pr.title}
Author: {pr.author}
Files: {pr.files_changed}, +{pr.additions}/-{pr.deletions}
Description: {pr.description[:300]}...
Labels: {', '.join(pr.labels) if pr.labels else 'None'}
---"""
            context_parts.append(pr_info)
        
        return "\n".join(context_parts)
    
    def _prepare_single_pr_context(self, pr: PullRequest) -> str:
        """Prepare single PR context for AI analysis."""
        return f"""PR #{pr.number}: {pr.title}
Author: {pr.author}
Files changed: {len(pr.files_changed)}, +{pr.additions}/-{pr.deletions}
Labels: {', '.join(pr.labels) if pr.labels else 'None'}
Merged: {'Yes' if pr.merged_at else 'No'}

Description:
{pr.body[:500]}{'...' if len(pr.body) > 500 else ''}

File changes:
{self._format_file_changes(pr.files_changed[:10])}  
"""

    def _format_file_changes(self, files):
        """Format file changes for context."""
        if not files:
            return "No file details available"
        
        formatted = []
        for file in files:
            formatted.append(f"- {file.filename}: +{file.additions}/-{file.deletions}")
        
        return "\n".join(formatted)
    
    def _create_fallback_entry(self, pr: PullRequest, audience: AudienceType) -> DigestEntry:
        """Create a fallback entry when AI analysis fails."""
        # Enhanced heuristic analysis
        title = pr.title or ""
        body = (pr.body or "")[:300] + "..." if len(pr.body or "") > 300 else (pr.body or "")
        
        # Determine change type from PR content
        change_type = "other"
        significance = 0.3  # Conservative default
        
        title_lower = title.lower()
        body_lower = (pr.body or "").lower()
        combined = f"{title_lower} {body_lower}"
        
        # Debug logging - FORCE VISIBLE
        print(f"DEBUG: Fallback analysis for PR #{pr.number}")
        print(f"DEBUG: title='{title}'")
        print(f"DEBUG: combined='{combined[:100]}...'")
        logger.info(f"Fallback analysis for PR #{pr.number}: title='{title}', body_len={len(pr.body or '')}")
        
        # Pre-calculate scale metrics
        files_count = len(pr.files_changed)
        total_changes = pr.additions + pr.deletions

        # Enhanced pattern matching - more comprehensive patterns
        if any(word in combined for word in ["fix", "bug", "issue", "error", "crash", "broken", "resolve", "patch"]):
            change_type = "bugfix"
            significance = 0.6
        elif any(word in combined for word in ["feat", "add", "new", "implement", "introduce", "create", "enable", "support"]):
            change_type = "feature" 
            significance = 0.7
        elif any(word in combined for word in ["refactor", "cleanup", "improve", "optimize", "restructure", "enhance", "simplify"]):
            change_type = "refactor"
            significance = 0.4
        elif any(word in combined for word in ["doc", "readme", "comment", "guide", "documentation", "docs"]):
            change_type = "documentation"
            significance = 0.2
        elif any(word in combined for word in ["test", "spec", "coverage", "testing", "unit", "integration"]):
            change_type = "testing"
            significance = 0.3
        elif any(word in combined for word in ["config", "setup", "build", "deploy", "ci", "cd", "workflow"]):
            change_type = "configuration"
            significance = 0.4
        elif any(word in combined for word in ["architecture", "design", "structure", "framework", "system"]):
            change_type = "architecture" 
            significance = 0.8
        # Check for common PR prefixes and keywords
        elif any(pattern in title_lower for pattern in ["update", "upgrade", "bump", "migrate"]):
            change_type = "refactor"
            significance = 0.5
        elif any(pattern in title_lower for pattern in ["remove", "delete", "deprecate"]):
            change_type = "refactor" 
            significance = 0.4
        # Default to feature for substantial changes, otherwise other
        elif files_count > 5 or total_changes > 100:
            change_type = "feature"
            significance = 0.6
        
        # Adjust significance based on scale
        if files_count > 20 or total_changes > 1000:
            significance = min(significance + 0.2, 1.0)
        elif files_count < 3 and total_changes < 50:
            significance = max(significance - 0.1, 0.1)
        
        # Look for breaking change indicators
        if any(word in combined for word in ["breaking", "break", "major", "incompatible"]):
            significance = min(significance + 0.3, 1.0)
        
        print(f"DEBUG: Classified PR #{pr.number} as: type={change_type}, significance={significance}")
        logger.info(f"Classified PR #{pr.number} as: type={change_type}, significance={significance}")
        
        return DigestEntry(
            title=title,
            summary=body,
            author=pr.author,
            pr_url=pr.html_url,
            labels=pr.labels,
            significance=significance,
            change_type=change_type,
            is_ongoing=not bool(pr.merged_at)
        )
    
    def _get_system_prompt(self, audience: AudienceType) -> str:
        """Get system prompt based on audience."""
        base_prompt = "You are an expert technical writer creating development summaries."
        
        audience_prompts = {
            AudienceType.FRONTEND: f"{base_prompt} Focus on UI/UX changes, component updates, and user-facing improvements.",
            AudienceType.BACKEND: f"{base_prompt} Focus on API changes, database updates, performance improvements, and server-side logic.",
            AudienceType.DEVOPS: f"{base_prompt} Focus on infrastructure changes, deployment improvements, CI/CD updates, and operational concerns.",
            AudienceType.SECURITY: f"{base_prompt} Focus on security improvements, vulnerability fixes, authentication changes, and compliance updates.",
            AudienceType.DESIGN: f"{base_prompt} Focus on visual changes, design system updates, accessibility improvements, and user experience.",
            AudienceType.EXECUTIVE: f"{base_prompt} Focus on business impact, feature delivery, risk mitigation, and high-level technical decisions.",
            AudienceType.GENERAL: f"{base_prompt} Provide a balanced technical overview accessible to various team members."
        }
        
        return audience_prompts.get(audience, audience_prompts[AudienceType.GENERAL])
    
    def _get_user_prompt(self, pr_context: str, audience: AudienceType) -> str:
        """Get user prompt with PR context."""
        return f"""
Please create a comprehensive development summary based on these pull requests:

{pr_context}

Target audience: {audience.value}

Structure your response as:
1. Executive Summary (2-3 sentences)
2. Key Changes (bullet points)
3. Technical Details (relevant to {audience.value})
4. Impact Assessment

Keep it professional, clear, and focused on what matters most to {audience.value} stakeholders.
"""