"""GitHub API client implementation."""

import asyncio
import json
from datetime import datetime, date
from typing import List, Dict, Any, Optional
from dataclasses import asdict

import httpx
from github import Github
from github.GithubException import GithubException

from ...domain.entities import PullRequest, CommitInfo, ChangeType
from ...domain.services import GitHubClient
from ...core.exceptions import ExternalServiceError, ConfigurationError
from ...config.logging_config import get_logger

logger = get_logger(__name__)


class GitHubApiClient(GitHubClient):
    """GitHub API client using PyGithub with async support."""
    
    def __init__(self, token: Optional[str] = None):
        if not token:
            raise ConfigurationError("GitHub token is required")
        
        self.token = token
        self._client = Github(token)
        self._http_client = httpx.AsyncClient(
            headers={"Authorization": f"token {token}"},
            timeout=30.0
        )
    
    async def get_pull_requests(
        self, 
        repo_path: str, 
        start_date: datetime, 
        end_date: datetime
    ) -> List[PullRequest]:
        """Get pull requests for a repository within date range."""
        try:
            logger.info(f"Fetching PRs for {repo_path} from {start_date} to {end_date}")
            
            repo = self._client.get_repo(repo_path)
            # Limit to recent PRs to avoid timeouts on large repos
            pulls = repo.get_pulls(state="closed", sort="updated", direction="desc")
            pulls_list = list(pulls[:100])  # Limit to 100 most recent PRs
            
            result = []
            for pr in pulls_list:
                if pr.merged_at and start_date <= pr.merged_at.replace(tzinfo=start_date.tzinfo) <= end_date:
                    pr_data = PullRequest(
                        number=pr.number,
                        title=pr.title,
                        body=pr.body or "",
                        author=pr.user.login if pr.user else "unknown",
                        html_url=pr.html_url,
                        labels=[label.name for label in pr.labels],
                        draft=pr.draft,
                        created_at=pr.created_at,
                        updated_at=pr.updated_at,
                        merged_at=pr.merged_at,
                        files_changed=[],  # We'll populate this separately if needed
                        commits=[],  # We'll populate this separately if needed
                        additions=pr.additions,
                        deletions=pr.deletions,
                        is_ongoing=False  # Merged PRs are not ongoing
                    )
                    result.append(pr_data)
            
            logger.info(f"Found {len(result)} merged PRs for {repo_path}")
            return result
            
        except GithubException as e:
            logger.error(f"GitHub API error for {repo_path}: {e}")
            raise ExternalServiceError(
                f"Failed to fetch pull requests from GitHub: {e}",
                service="github"
            )
        except Exception as e:
            logger.error(f"Unexpected error fetching PRs for {repo_path}: {e}")
            raise ExternalServiceError(
                f"Unexpected error fetching pull requests: {e}",
                service="github"
            )
    
    async def get_commits(
        self, 
        repo_path: str, 
        start_date: date, 
        end_date: date
    ) -> List[CommitInfo]:
        """Get commits for a repository within date range."""
        try:
            logger.info(f"Fetching commits for {repo_path} from {start_date} to {end_date}")
            
            repo = self._client.get_repo(repo_path)
            commits = repo.get_commits(
                since=datetime.combine(start_date, datetime.min.time()),
                until=datetime.combine(end_date, datetime.max.time())
            )
            
            result = []
            for commit in commits:
                commit_data = CommitInfo(
                    sha=commit.sha,
                    message=commit.commit.message,
                    author=commit.commit.author.name if commit.commit.author else "unknown",
                    date=commit.commit.author.date if commit.commit.author else datetime.now(),
                    url=commit.html_url,
                    additions=commit.stats.additions if commit.stats else 0,
                    deletions=commit.stats.deletions if commit.stats else 0,
                    files_changed=len(commit.files) if commit.files else 0
                )
                result.append(commit_data)
            
            logger.info(f"Found {len(result)} commits for {repo_path}")
            return result
            
        except GithubException as e:
            logger.error(f"GitHub API error for {repo_path}: {e}")
            raise ExternalServiceError(
                f"Failed to fetch commits from GitHub: {e}",
                service="github"
            )
        except Exception as e:
            logger.error(f"Unexpected error fetching commits for {repo_path}: {e}")
            raise ExternalServiceError(
                f"Unexpected error fetching commits: {e}",
                service="github"
            )
    
    async def validate_repository(self, repo_path: str) -> bool:
        """Validate that repository exists and is accessible."""
        try:
            repo = self._client.get_repo(repo_path)
            # Try to access basic repo info to validate access
            _ = repo.name
            return True
        except GithubException:
            return False
        except Exception:
            return False
    
    async def get_repository_info(self, repo_path: str) -> Dict[str, Any]:
        """Get basic repository information."""
        try:
            repo = self._client.get_repo(repo_path)
            return {
                "name": repo.name,
                "full_name": repo.full_name,
                "description": repo.description,
                "language": repo.language,
                "stars": repo.stargazers_count,
                "forks": repo.forks_count,
                "open_issues": repo.open_issues_count,
                "created_at": repo.created_at,
                "updated_at": repo.updated_at,
                "url": repo.html_url
            }
        except GithubException as e:
            logger.error(f"Failed to get repository info for {repo_path}: {e}")
            raise ExternalServiceError(
                f"Failed to get repository information: {e}",
                service="github"
            )
    
    async def close(self):
        """Clean up resources."""
        if hasattr(self, '_http_client'):
            await self._http_client.aclose()