"""Dependency injection container for the application."""

from typing import Dict, Any, TypeVar, Type, Optional, Callable
from abc import ABC, abstractmethod
import threading

T = TypeVar("T")


class Container:
    """Simple dependency injection container."""
    
    def __init__(self) -> None:
        self._services: Dict[str, Any] = {}
        self._factories: Dict[str, Callable[[], Any]] = {}
        self._singletons: Dict[str, Any] = {}
        self._lock = threading.Lock()
    
    def register(
        self, 
        service_name: str, 
        implementation: Any,
        singleton: bool = True
    ) -> None:
        """Register a service implementation."""
        if singleton:
            self._singletons[service_name] = implementation
        else:
            self._factories[service_name] = implementation
    
    def register_instance(self, service_type: Type[T], instance: T) -> None:
        """Register a service instance."""
        key = self._get_key(service_type)
        self._singletons[key] = instance
    
    def register_factory(
        self, 
        service_name: str, 
        factory: Callable[[], Any]
    ) -> None:
        """Register a factory function for a service."""
        self._factories[service_name] = factory
    
    def get(self, service_name: str) -> Any:
        """Get a service instance."""
        # Check if we have a cached singleton
        if service_name in self._singletons:
            return self._singletons[service_name]
        
        # Check if we have a factory
        if service_name in self._factories:
            return self._factories[service_name]()
        
        # Check if we have a service class (singleton)
        if service_name in self._services:
            with self._lock:
                # Double-check pattern for thread safety
                if service_name not in self._singletons:
                    self._singletons[service_name] = self._services[service_name]()
                return self._singletons[service_name]
        
        raise ValueError(f"Service {service_name} not registered")
    
    def clear(self) -> None:
        """Clear all registered services."""
        self._services.clear()
        self._factories.clear()
        self._singletons.clear()
    
    def _get_key(self, service_type: Type[T]) -> str:
        """Get the key for a service type."""
        return f"{service_type.__module__}.{service_type.__name__}"


# Global container instance
_container: Optional[Container] = None
_container_lock = threading.Lock()


def get_container() -> Container:
    """Get the global dependency injection container."""
    global _container
    if _container is None:
        with _container_lock:
            if _container is None:
                _container = Container()
    return _container


def configure_dependencies() -> None:
    """Configure application dependencies."""
    container = get_container()
    
    # This will be populated as we create the services
    # For now, it's a placeholder for future dependency registration