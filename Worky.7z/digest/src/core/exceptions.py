"""Custom exceptions for the application."""

from typing import Optional, Dict, Any


class DigestError(Exception):
    """Base exception for digest-related errors."""
    
    def __init__(
        self, 
        message: str, 
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ) -> None:
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(self.message)


class ValidationError(DigestError):
    """Raised when input validation fails."""
    
    def __init__(
        self, 
        message: str, 
        field: Optional[str] = None,
        value: Optional[Any] = None
    ) -> None:
        details = {}
        if field:
            details["field"] = field
        if value is not None:
            details["value"] = value
        super().__init__(message, "VALIDATION_ERROR", details)
        self.field = field
        self.value = value


class NotFoundError(DigestError):
    """Raised when a requested resource is not found."""
    
    def __init__(self, message: str, resource_type: Optional[str] = None) -> None:
        details = {}
        if resource_type:
            details["resource_type"] = resource_type
        super().__init__(message, "NOT_FOUND", details)


class BusinessLogicError(DigestError):
    """Raised when business logic constraints are violated."""
    
    def __init__(self, message: str) -> None:
        super().__init__(message, "BUSINESS_LOGIC_ERROR")


class ConfigurationError(DigestError):
    """Raised when configuration is invalid or missing."""
    
    def __init__(self, message: str, config_key: Optional[str] = None) -> None:
        details = {}
        if config_key:
            details["config_key"] = config_key
        super().__init__(message, "CONFIGURATION_ERROR", details)


class ExternalServiceError(DigestError):
    """Base exception for external service errors."""
    
    def __init__(
        self, 
        message: str, 
        service: str,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None
    ) -> None:
        details = {"service": service}
        if status_code:
            details["status_code"] = status_code
        if response_data:
            details["response_data"] = response_data
        super().__init__(message, "EXTERNAL_SERVICE_ERROR", details)


class GitHubError(ExternalServiceError):
    """Raised when GitHub API operations fail."""
    
    def __init__(
        self, 
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None
    ) -> None:
        super().__init__(message, "GitHub", status_code, response_data)


class OpenAIError(ExternalServiceError):
    """Raised when OpenAI API operations fail."""
    
    def __init__(
        self, 
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None
    ) -> None:
        super().__init__(message, "OpenAI", status_code, response_data)


class ProgressTrackingError(DigestError):
    """Raised when progress tracking operations fail."""
    
    def __init__(self, message: str, session_id: Optional[str] = None) -> None:
        details = {}
        if session_id:
            details["session_id"] = session_id
        super().__init__(message, "PROGRESS_TRACKING_ERROR", details)