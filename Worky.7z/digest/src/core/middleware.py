"""Middleware components for request/response handling."""

from typing import Dict, Any, Optional
from flask import request, g
from functools import wraps
import time
import uuid

from ..config.logging_config import get_logger
from .exceptions import ValidationError

logger = get_logger(__name__)


def request_logging_middleware(f):
    """Middleware to log incoming requests."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        # Generate request ID
        request_id = str(uuid.uuid4())[:8]
        g.request_id = request_id
        
        # Log request start
        start_time = time.time()
        logger.info(
            "Request started",
            extra={
                "request_id": request_id,
                "method": request.method,
                "path": request.path,
                "user_agent": request.headers.get("User-Agent"),
                "remote_addr": request.remote_addr,
            }
        )
        
        try:
            result = f(*args, **kwargs)
            
            # Log successful request
            duration = time.time() - start_time
            logger.info(
                "Request completed",
                extra={
                    "request_id": request_id,
                    "duration_ms": round(duration * 1000, 2),
                    "status": "success",
                }
            )
            
            return result
            
        except Exception as e:
            # Log failed request
            duration = time.time() - start_time
            logger.error(
                "Request failed",
                extra={
                    "request_id": request_id,
                    "duration_ms": round(duration * 1000, 2),
                    "error": str(e),
                    "error_type": type(e).__name__,
                },
                exc_info=True
            )
            raise
    
    return wrapper


def validate_json_middleware(required_fields: Optional[list] = None):
    """Middleware to validate JSON request body."""
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if request.method in ["POST", "PUT", "PATCH"]:
                if not request.is_json:
                    raise ValidationError("Request must contain valid JSON")
                
                json_data = request.get_json()
                if json_data is None:
                    raise ValidationError("Request body must contain JSON data")
                
                # Validate required fields
                if required_fields:
                    for field in required_fields:
                        if field not in json_data:
                            raise ValidationError(f"Missing required field: {field}", field=field)
                
                g.json_data = json_data
            
            return f(*args, **kwargs)
        return wrapper
    return decorator


def error_handling_middleware(f):
    """Middleware for consistent error response handling."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except ValidationError as e:
            logger.warning(f"Validation error: {e.message}", extra={"error_code": e.error_code, "details": e.details})
            return {
                "error": {
                    "type": "validation_error",
                    "message": e.message,
                    "code": e.error_code,
                    "details": e.details,
                }
            }, 400
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}", exc_info=True)
            return {
                "error": {
                    "type": "internal_error", 
                    "message": "An unexpected error occurred",
                    "code": "INTERNAL_ERROR",
                }
            }, 500
    
    return wrapper