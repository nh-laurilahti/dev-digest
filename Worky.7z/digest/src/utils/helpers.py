"""Helper utilities."""

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional


def generate_session_id() -> str:
    """Generate a unique session ID."""
    return str(uuid.uuid4())


def format_time_duration(seconds: int) -> str:
    """Format duration in seconds to human-readable format."""
    if seconds < 60:
        return f"{seconds}s"
    
    minutes = seconds // 60
    remaining_seconds = seconds % 60
    
    if minutes < 60:
        return f"{minutes}m {remaining_seconds}s"
    
    hours = minutes // 60
    remaining_minutes = minutes % 60
    
    return f"{hours}h {remaining_minutes}m"


def safe_get(dictionary: Dict[str, Any], key: str, default: Any = None) -> Any:
    """Safely get a value from a dictionary."""
    try:
        return dictionary.get(key, default)
    except (AttributeError, TypeError):
        return default


def truncate_string(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """Truncate a string to a maximum length."""
    if not text or len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


def utc_now() -> datetime:
    """Get current UTC datetime."""
    return datetime.now(timezone.utc)


def to_dict(obj: Any, exclude_none: bool = True) -> Dict[str, Any]:
    """Convert an object to dictionary, handling various types."""
    if hasattr(obj, '__dict__'):
        result = obj.__dict__.copy()
        if exclude_none:
            result = {k: v for k, v in result.items() if v is not None}
        return result
    elif hasattr(obj, '_asdict'):  # namedtuple
        return obj._asdict()
    else:
        return {"value": obj}


def clean_html_tags(text: str) -> str:
    """Remove HTML tags from text."""
    import re
    clean = re.compile('<.*?>')
    return re.sub(clean, '', text)


def calculate_percentage(current: int, total: int) -> int:
    """Calculate percentage, handling edge cases."""
    if total == 0:
        return 100 if current == 0 else 0
    
    percentage = int((current / total) * 100)
    return min(100, max(0, percentage))