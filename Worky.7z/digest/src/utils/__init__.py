"""Utility functions for the application."""

from .timespan import get_timespan_dates, get_hours_from_timespan, parse_timespan_string
from .validation import (
    validate_repository_path,
    validate_timespan,
    validate_audience,
    validate_custom_days,
    validate_view_mode,
    validate_pagination_params,
)
from .helpers import (
    generate_session_id,
    format_time_duration,
    safe_get,
    truncate_string,
    utc_now,
    to_dict,
    clean_html_tags,
    calculate_percentage,
)

__all__ = [
    # Timespan utilities
    "get_timespan_dates",
    "get_hours_from_timespan", 
    "parse_timespan_string",
    # Validation utilities
    "validate_repository_path",
    "validate_timespan",
    "validate_audience",
    "validate_custom_days",
    "validate_view_mode",
    "validate_pagination_params",
    # Helper utilities
    "generate_session_id",
    "format_time_duration",
    "safe_get",
    "truncate_string",
    "utc_now",
    "to_dict",
    "clean_html_tags",
    "calculate_percentage",
]