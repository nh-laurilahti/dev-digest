"""Validation utilities."""

import re
from typing import Any, Dict, List, Optional
from ..core.exceptions import ValidationError


def validate_repository_path(repo_path: str) -> str:
    """Validate GitHub repository path format."""
    if not repo_path:
        raise ValidationError("Repository path is required", field="repository")
    
    # GitHub repo format: owner/repo
    if not re.match(r'^[a-zA-Z0-9._-]+/[a-zA-Z0-9._-]+$', repo_path):
        raise ValidationError(
            "Repository path must be in format 'owner/repo'", 
            field="repository",
            value=repo_path
        )
    
    return repo_path.strip()


def validate_timespan(timespan: str) -> str:
    """Validate timespan parameter."""
    valid_timespans = ["today", "yesterday", "last_week", "last_month", "custom"]
    
    if timespan not in valid_timespans:
        raise ValidationError(
            f"Timespan must be one of: {', '.join(valid_timespans)}",
            field="timespan",
            value=timespan
        )
    
    return timespan


def validate_audience(audience: str) -> str:
    """Validate audience parameter."""
    valid_audiences = ["frontend", "backend", "devops", "security", "design", "executive", "general"]
    
    if audience not in valid_audiences:
        raise ValidationError(
            f"Audience must be one of: {', '.join(valid_audiences)}",
            field="audience", 
            value=audience
        )
    
    return audience


def validate_custom_days(custom_days: Any) -> Optional[int]:
    """Validate custom_days parameter."""
    if custom_days is None:
        return None
    
    try:
        days = int(custom_days)
    except (ValueError, TypeError):
        raise ValidationError(
            "Custom days must be a valid integer",
            field="custom_days",
            value=custom_days
        )
    
    if days < 1:
        raise ValidationError(
            "Custom days must be at least 1",
            field="custom_days",
            value=days
        )
    
    if days > 365:
        raise ValidationError(
            "Custom days cannot exceed 365",
            field="custom_days", 
            value=days
        )
    
    return days


def validate_view_mode(view_mode: str) -> str:
    """Validate view_mode parameter."""
    valid_modes = ["summary", "detailed"]
    
    if view_mode not in valid_modes:
        raise ValidationError(
            f"View mode must be one of: {', '.join(valid_modes)}",
            field="view_mode",
            value=view_mode
        )
    
    return view_mode


def validate_pagination_params(page: Any, per_page: Any) -> tuple[int, int]:
    """Validate pagination parameters."""
    try:
        page_num = int(page) if page is not None else 1
    except (ValueError, TypeError):
        raise ValidationError("Page must be a valid integer", field="page", value=page)
    
    try:
        per_page_num = int(per_page) if per_page is not None else 10
    except (ValueError, TypeError):
        raise ValidationError("Per page must be a valid integer", field="per_page", value=per_page)
    
    if page_num < 1:
        raise ValidationError("Page must be at least 1", field="page", value=page_num)
    
    if per_page_num < 1 or per_page_num > 100:
        raise ValidationError("Per page must be between 1 and 100", field="per_page", value=per_page_num)
    
    return page_num, per_page_num