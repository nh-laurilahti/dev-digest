"""Manage repository use case."""

from typing import List, Optional
from dataclasses import dataclass

from ...domain.entities import Repository
from ...domain.repositories import RepositoryRepository
from ...domain.services import GitHubClient
from ...core.exceptions import ValidationError, NotFoundError, BusinessLogicError
from ...utils.validation import validate_repository_path
from ...utils.helpers import utc_now
from ...config.logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class AddRepositoryRequest:
    """Request for adding a repository."""
    path: str
    name: Optional[str] = None
    active: bool = True


@dataclass
class UpdateRepositoryRequest:
    """Request for updating a repository."""
    repository_id: int
    path: Optional[str] = None
    name: Optional[str] = None
    active: Optional[bool] = None


@dataclass
class RepositoryResponse:
    """Response for repository operations."""
    repository: Repository
    success: bool = True
    message: str = "Operation completed successfully"


@dataclass
class RepositoryListResponse:
    """Response for listing repositories."""
    repositories: List[Repository]
    success: bool = True
    message: str = "Repositories retrieved successfully"


class ManageRepositoryUseCase:
    """Use case for managing tracked repositories."""
    
    def __init__(
        self, 
        repository_repository: RepositoryRepository,
        github_client: GitHubClient
    ):
        self.repository_repository = repository_repository
        self.github_client = github_client
    
    async def add_repository(self, request: AddRepositoryRequest) -> RepositoryResponse:
        """Add a new repository to tracking."""
        try:
            # Validate repository path
            repository_path = validate_repository_path(request.path)
            
            logger.info(f"Adding repository: {repository_path}")
            
            # Check if repository already exists
            existing_repo = await self.repository_repository.get_by_path(repository_path)
            if existing_repo:
                logger.warning(f"Repository already exists: {repository_path}")
                raise BusinessLogicError(
                    f"Repository {repository_path} is already being tracked"
                )
            
            # Validate repository access
            is_valid = await self.github_client.validate_repository(repository_path)
            if not is_valid:
                raise ValidationError(
                    f"Repository {repository_path} not found or inaccessible",
                    field="path"
                )
            
            # Get repository info from GitHub
            try:
                repo_info = await self.github_client.get_repository_info(repository_path)
                default_name = repo_info.get("name", repository_path.split("/")[-1])
            except Exception:
                default_name = repository_path.split("/")[-1]
            
            # Create repository entity
            repository = Repository(
                path=repository_path,
                name=request.name or default_name,
                active=request.active,
                created_at=utc_now()
            )
            
            # Save repository
            saved_repository = await self.repository_repository.create(repository)
            
            logger.info(f"Successfully added repository: {saved_repository.id}")
            
            return RepositoryResponse(
                repository=saved_repository,
                message=f"Repository {repository_path} added successfully"
            )
            
        except Exception as e:
            logger.error(f"Error adding repository {request.path}: {e}")
            raise
    
    async def update_repository(self, request: UpdateRepositoryRequest) -> RepositoryResponse:
        """Update an existing repository."""
        try:
            logger.info(f"Updating repository: {request.repository_id}")
            
            # Get existing repository
            repository = await self.repository_repository.get_by_id(request.repository_id)
            if not repository:
                raise NotFoundError(f"Repository with ID {request.repository_id} not found")
            
            # Update fields if provided
            if request.path is not None:
                new_path = validate_repository_path(request.path)
                
                # Check if new path conflicts with existing repository
                if new_path != repository.path:
                    existing_repo = await self.repository_repository.get_by_path(new_path)
                    if existing_repo:
                        raise BusinessLogicError(
                            f"Repository {new_path} is already being tracked"
                        )
                    
                    # Validate new repository access
                    is_valid = await self.github_client.validate_repository(new_path)
                    if not is_valid:
                        raise ValidationError(
                            f"Repository {new_path} not found or inaccessible",
                            field="path"
                        )
                    
                    repository.path = new_path
            
            if request.name is not None:
                repository.name = request.name
            
            if request.active is not None:
                repository.active = request.active
            
            # Save updated repository
            updated_repository = await self.repository_repository.update(repository)
            
            logger.info(f"Successfully updated repository: {updated_repository.id}")
            
            return RepositoryResponse(
                repository=updated_repository,
                message="Repository updated successfully"
            )
            
        except Exception as e:
            logger.error(f"Error updating repository {request.repository_id}: {e}")
            raise
    
    async def delete_repository(self, repository_id: int) -> RepositoryResponse:
        """Delete a repository from tracking."""
        try:
            logger.info(f"Deleting repository: {repository_id}")
            
            # Get repository to return in response
            repository = await self.repository_repository.get_by_id(repository_id)
            if not repository:
                raise NotFoundError(f"Repository with ID {repository_id} not found")
            
            # Delete repository
            success = await self.repository_repository.delete(repository_id)
            if not success:
                raise BusinessLogicError(f"Failed to delete repository {repository_id}")
            
            logger.info(f"Successfully deleted repository: {repository_id}")
            
            return RepositoryResponse(
                repository=repository,
                message="Repository deleted successfully"
            )
            
        except Exception as e:
            logger.error(f"Error deleting repository {repository_id}: {e}")
            raise
    
    async def get_repository(self, repository_id: int) -> RepositoryResponse:
        """Get a repository by ID."""
        try:
            logger.info(f"Getting repository: {repository_id}")
            
            repository = await self.repository_repository.get_by_id(repository_id)
            if not repository:
                raise NotFoundError(f"Repository with ID {repository_id} not found")
            
            return RepositoryResponse(
                repository=repository,
                message="Repository retrieved successfully"
            )
            
        except Exception as e:
            logger.error(f"Error getting repository {repository_id}: {e}")
            raise
    
    async def list_repositories(self, active_only: bool = False) -> RepositoryListResponse:
        """List all repositories."""
        try:
            logger.info(f"Listing repositories (active_only: {active_only})")
            
            if active_only:
                repositories = await self.repository_repository.get_active()
            else:
                repositories = await self.repository_repository.get_all()
            
            logger.info(f"Retrieved {len(repositories)} repositories")
            
            return RepositoryListResponse(
                repositories=repositories,
                message=f"Retrieved {len(repositories)} repositories"
            )
            
        except Exception as e:
            logger.error(f"Error listing repositories: {e}")
            raise