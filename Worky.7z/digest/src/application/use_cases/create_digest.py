"""Create digest use case."""

from datetime import date
from typing import List, Optional
from dataclasses import dataclass

from ...domain.entities import Digest, DigestEntry, AudienceType
from ...domain.repositories import DigestRepository, RepositoryRepository
from ...domain.services import GitHubClient, SummaryGenerator
from ...core.exceptions import ValidationError, BusinessLogicError
from ...utils.timespan import get_timespan_dates
from ...utils.validation import validate_repository_path, validate_timespan, validate_audience
from ...utils.helpers import generate_session_id, utc_now
from ...infrastructure.simple_status import SimpleStatusTracker
from ...config.logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class CreateDigestRequest:
    """Request for creating a digest."""
    repository: str
    timespan: str
    audience: str
    custom_days: Optional[int] = None
    view_mode: str = "summary"


@dataclass
class CreateDigestResponse:
    """Response from creating a digest."""
    digest: Digest
    session_id: str
    success: bool = True
    message: str = "Digest created successfully"


class CreateDigestUseCase:
    """Use case for creating development digests."""
    
    def __init__(
        self,
        digest_repository: DigestRepository,
        repository_repository: RepositoryRepository,
        github_client: GitHubClient,
        summary_generator: SummaryGenerator,
        status_tracker: SimpleStatusTracker = None
    ):
        self.digest_repository = digest_repository
        self.repository_repository = repository_repository
        self.github_client = github_client
        self.summary_generator = summary_generator
        self.status_tracker = status_tracker or SimpleStatusTracker()
    
    async def execute(self, request: CreateDigestRequest) -> CreateDigestResponse:
        """Execute the create digest use case."""
        session_id = generate_session_id()
        
        try:
            # Start tracking the operation
            self.status_tracker.start_operation(session_id, f"Creating digest for {request.repository}")
            
            # Validate input
            repository = validate_repository_path(request.repository)
            timespan = validate_timespan(request.timespan)
            audience = validate_audience(request.audience)
            audience_type = AudienceType(audience)
            
            logger.info(f"Creating digest for {repository} ({timespan}, {audience})")
            
            # Check if digest already exists for this date
            logger.info("Checking for existing digest")
            from ...utils.timespan import parse_timespan_string
            timespan_type = parse_timespan_string(timespan)
            start_date, end_date, timespan_desc = get_timespan_dates(timespan_type, request.custom_days)
            existing_digest = await self.digest_repository.get_by_date(start_date, repository)
            
            if existing_digest:
                logger.info("Found existing digest")
                return CreateDigestResponse(
                    digest=existing_digest,
                    session_id=session_id,
                    message="Digest already exists for this date"
                )
            
            logger.info("No existing digest found")
            
            # Validate repository access
            logger.info("Validating repository access")
            is_valid = await self.github_client.validate_repository(repository)
            if not is_valid:
                raise ValidationError(
                    f"Repository {repository} not found or inaccessible",
                    field="repository"
                )
            
            logger.info("Repository access validated")
            
            # Fetch pull requests
            logger.info("Fetching pull requests")
            pull_requests = await self.github_client.get_pull_requests(repository, start_date, end_date)
            logger.info(f"Found {len(pull_requests)} pull requests")
            
            if not pull_requests:
                logger.info("No changes to analyze")
                # Create empty digest
                digest = await self._create_empty_digest(repository, start_date)
                return CreateDigestResponse(digest=digest, session_id=session_id)
            
            # Analyze changes - create digest entries from pull requests
            logger.info("Analyzing changes")
            entries = []
            for pr in pull_requests:
                # Create a basic ChangeAnalysis for each PR
                analysis = None  # We'll pass None and let the summarizer handle it
                entry = await self.summary_generator.summarize_change(pr, analysis, audience_type)
                entries.append(entry)
            
            logger.info(f"Analyzed {len(entries)} change entries")
            
            # Generate summary
            logger.info("Generating summary")  
            summary = await self.summary_generator.create_digest_summary(
                entries, 
                audience=audience_type, 
                repository=repository,
                timespan=timespan
            )
            logger.info("Summary generated")
            
            # Create digest content
            content = self._format_digest_content(entries, pull_requests, request.view_mode)
            
            # Calculate statistics
            stats = self._calculate_stats(pull_requests, entries)
            
            # Save digest
            logger.info("Saving digest")
            digest = Digest(
                date=start_date,
                repository=repository,
                summary=summary,
                content=content,
                stats=stats,
                created_at=utc_now()
            )
            
            saved_digest = await self.digest_repository.create(digest)
            logger.info("Digest saved successfully")
            
            # Update repository last scan
            await self._update_repository_scan_time(repository)
            
            # Mark operation as completed
            self.status_tracker.complete_operation(
                session_id, 
                f"Successfully created digest for {repository}",
                saved_digest.id
            )
            
            logger.info(f"Successfully created digest {saved_digest.id} for {repository}")
            
            return CreateDigestResponse(digest=saved_digest, session_id=session_id)
            
        except Exception as e:
            # Mark operation as failed
            self.status_tracker.fail_operation(session_id, str(e))
            logger.error(f"Error creating digest: {e}")
            raise
    
    async def _create_empty_digest(self, repository: str, date: date) -> Digest:
        """Create an empty digest when no pull requests are found."""
        logger.info("Creating empty digest")
        
        digest = Digest(
            date=date,
            repository=repository,
            summary="No pull requests found for this time period.",
            content="No development activity detected during the specified timeframe.",
            stats={"pull_requests": 0, "files_changed": 0, "additions": 0, "deletions": 0},
            created_at=utc_now()
        )
        
        saved_digest = await self.digest_repository.create(digest)
        logger.info("Empty digest created")
        
        return saved_digest
    
    def _format_digest_content(
        self, 
        entries: List[DigestEntry], 
        pull_requests: list, 
        view_mode: str
    ) -> str:
        """Format the digest content based on view mode."""
        if view_mode == "detailed":
            return self._format_detailed_content(entries, pull_requests)
        else:
            return self._format_summary_content(entries)
    
    def _format_summary_content(self, entries: List[DigestEntry]) -> str:
        """Format summary content - concise overview."""
        if not entries:
            return "No significant changes detected."
        
        # Sort entries by significance
        sorted_entries = sorted(entries, key=lambda x: x.significance, reverse=True)
        
        content_parts = ["## Key Changes Summary\n"]
        
        for entry in sorted_entries[:5]:  # Top 5 most significant
            # Use first sentence of summary for brevity
            summary_brief = entry.summary.split('.')[0] + '.' if entry.summary else "No description available."
            content_parts.append(f"**{entry.title}**")
            content_parts.append(f"└─ {summary_brief}")
            content_parts.append("")
        
        return "\n".join(content_parts)
    
    def _format_detailed_content(self, entries: List[DigestEntry], pull_requests: list) -> str:
        """Format detailed content with comprehensive PR information."""
        content_parts = ["## Detailed Development Report\n"]
        
        # Group by change type
        categories = {}
        for entry in entries:
            category = entry.change_type or 'Other'
            if category not in categories:
                categories[category] = []
            categories[category].append(entry)
        
        # Show each category with detailed information
        for category, category_entries in categories.items():
            if category_entries:  # Only show categories with entries
                content_parts.append(f"### {category.title()} Changes ({len(category_entries)})")
                content_parts.append("")
                
                for entry in sorted(category_entries, key=lambda x: x.significance, reverse=True):
                    content_parts.append(f"#### {entry.title}")
                    content_parts.append(f"{entry.summary}")
                    content_parts.append(f"**Author:** {entry.author} | **Impact:** {entry.significance:.1f}/1.0")
                    if entry.labels:
                        content_parts.append(f"**Labels:** {', '.join(entry.labels)}")
                    if entry.pr_url:
                        content_parts.append(f"**Link:** [View PR]({entry.pr_url})")
                    content_parts.append("")
        
        # Add aggregate PR statistics
        if pull_requests:
            total_additions = sum(pr.additions for pr in pull_requests)
            total_deletions = sum(pr.deletions for pr in pull_requests)
            authors = list(set(pr.author for pr in pull_requests))
            
            content_parts.append("## Development Metrics")
            content_parts.append(f"**Pull Requests:** {len(pull_requests)}")
            content_parts.append(f"**Lines Added:** {total_additions:,}")
            content_parts.append(f"**Lines Removed:** {total_deletions:,}")  
            content_parts.append(f"**Contributors:** {len(authors)}")
            content_parts.append(f"**Active Authors:** {', '.join(authors[:10])}" + ("..." if len(authors) > 10 else ""))
            content_parts.append("")
        
        return "\n".join(content_parts)
    
    def _calculate_stats(self, pull_requests: list, entries: List[DigestEntry]) -> dict:
        """Calculate statistics for the digest."""
        if not pull_requests:
            return {
                "pull_requests": 0,
                "files_changed": 0,
                "additions": 0,
                "deletions": 0,
                "average_significance": 0.0,
                "categories": {}
            }
        
        total_files = sum(len(pr.files_changed) for pr in pull_requests)
        total_additions = sum(pr.additions for pr in pull_requests)
        total_deletions = sum(pr.deletions for pr in pull_requests)
        
        # Category breakdown
        categories = {}
        total_significance = 0.0
        
        for entry in entries:
            category = getattr(entry, 'category', 'other')
            categories[category] = categories.get(category, 0) + 1
            total_significance += entry.significance
        
        avg_significance = total_significance / len(entries) if entries else 0.0
        
        return {
            "pull_requests": len(pull_requests),
            "files_changed": total_files,
            "additions": total_additions,
            "deletions": total_deletions,
            "entries": len(entries),
            "average_significance": round(avg_significance, 2),
            "categories": categories,
            "authors": list(set(pr.author for pr in pull_requests))
        }
    
    async def _update_repository_scan_time(self, repository_path: str) -> None:
        """Update the last scan time for a repository."""
        try:
            repo = await self.repository_repository.get_by_path(repository_path)
            if repo:
                repo.last_scan = utc_now()
                await self.repository_repository.update(repo)
        except Exception as e:
            # Non-critical error, just log it
            logger.warning(f"Could not update repository scan time: {e}")