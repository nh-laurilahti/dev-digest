"""Get digest use case."""

from datetime import date
from typing import Optional
from dataclasses import dataclass

from ...domain.entities import Digest
from ...domain.repositories import DigestRepository
from ...core.exceptions import NotFoundError
from ...utils.validation import validate_repository_path
from ...config.logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class GetDigestByIdRequest:
    """Request for getting a digest by ID."""
    digest_id: int


@dataclass
class GetDigestByDateRequest:
    """Request for getting a digest by date and repository."""
    repository: str
    date: date


@dataclass
class GetDigestResponse:
    """Response from getting a digest."""
    digest: Digest
    success: bool = True
    message: str = "Digest retrieved successfully"


class GetDigestUseCase:
    """Use case for retrieving digests."""
    
    def __init__(self, digest_repository: DigestRepository):
        self.digest_repository = digest_repository
    
    async def execute_by_id(self, request: GetDigestByIdRequest) -> GetDigestResponse:
        """Get a digest by ID."""
        try:
            logger.info(f"Retrieving digest by ID: {request.digest_id}")
            
            if request.digest_id <= 0:
                raise ValueError("Digest ID must be a positive integer")
            
            digest = await self.digest_repository.get_by_id(request.digest_id)
            
            if not digest:
                logger.warning(f"Digest not found with ID: {request.digest_id}")
                raise NotFoundError(f"Digest with ID {request.digest_id} not found")
            
            logger.info(f"Successfully retrieved digest {digest.id}")
            return GetDigestResponse(digest=digest)
            
        except Exception as e:
            logger.error(f"Error retrieving digest by ID {request.digest_id}: {e}")
            raise
    
    async def execute_by_date(self, request: GetDigestByDateRequest) -> GetDigestResponse:
        """Get a digest by date and repository."""
        try:
            repository = validate_repository_path(request.repository)
            
            logger.info(f"Retrieving digest for {repository} on {request.date}")
            
            digest = await self.digest_repository.get_by_date(request.date, repository)
            
            if not digest:
                logger.warning(f"Digest not found for {repository} on {request.date}")
                raise NotFoundError(
                    f"Digest not found for repository {repository} on {request.date}"
                )
            
            logger.info(f"Successfully retrieved digest {digest.id} for {repository}")
            return GetDigestResponse(digest=digest)
            
        except Exception as e:
            logger.error(f"Error retrieving digest for {request.repository} on {request.date}: {e}")
            raise