"""List digests use case."""

from typing import List, Optional
from dataclasses import dataclass

from ...domain.entities import Digest
from ...domain.repositories import DigestRepository
from ...utils.validation import validate_pagination_params, validate_repository_path
from ...config.logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class ListDigestsRequest:
    """Request for listing digests."""
    repository: Optional[str] = None
    page: int = 1
    per_page: int = 10


@dataclass
class ListDigestsResponse:
    """Response from listing digests."""
    digests: List[Digest]
    total_count: int
    page: int
    per_page: int
    has_next: bool
    has_prev: bool
    success: bool = True
    message: str = "Digests retrieved successfully"


class ListDigestsUseCase:
    """Use case for listing digests with pagination."""
    
    def __init__(self, digest_repository: DigestRepository):
        self.digest_repository = digest_repository
    
    async def execute(self, request: ListDigestsRequest) -> ListDigestsResponse:
        """List digests with optional filtering and pagination."""
        try:
            # Validate pagination parameters
            page, per_page = validate_pagination_params(request.page, request.per_page)
            
            # Validate repository if provided
            repository = None
            if request.repository:
                repository = validate_repository_path(request.repository)
            
            logger.info(f"Listing digests - Page: {page}, Per page: {per_page}, Repository: {repository}")
            
            # Calculate offset
            offset = (page - 1) * per_page
            
            # Get digests
            digests = await self.digest_repository.get_recent(
                limit=per_page,
                offset=offset,
                repository=repository
            )
            
            # Note: For simplicity, we're not implementing total count here
            # In a real application, you'd want to add a count method to the repository
            total_count = len(digests)  # This is just the current page count
            
            # Calculate pagination flags
            has_prev = page > 1
            has_next = len(digests) == per_page  # Simplified logic
            
            logger.info(f"Retrieved {len(digests)} digests")
            
            return ListDigestsResponse(
                digests=digests,
                total_count=total_count,
                page=page,
                per_page=per_page,
                has_next=has_next,
                has_prev=has_prev
            )
            
        except Exception as e:
            logger.error(f"Error listing digests: {e}")
            raise