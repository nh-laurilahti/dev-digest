"""Repository application service."""

from typing import List, Optional

from ..use_cases.manage_repository import (
    ManageRepositoryUseCase,
    AddRepositoryRequest,
    UpdateRepositoryRequest,
    RepositoryResponse,
    RepositoryListResponse
)
from ...domain.repositories import RepositoryRepository
from ...domain.services import GitHubClient
from ...config.logging_config import get_logger

logger = get_logger(__name__)


class RepositoryService:
    """High-level service for repository operations."""
    
    def __init__(
        self,
        repository_repository: RepositoryRepository,
        github_client: GitHubClient
    ):
        self.manage_repository_use_case = ManageRepositoryUseCase(
            repository_repository=repository_repository,
            github_client=github_client
        )
    
    async def add_repository(
        self,
        path: str,
        name: Optional[str] = None,
        active: bool = True
    ) -> RepositoryResponse:
        """Add a new repository to tracking."""
        request = AddRepositoryRequest(
            path=path,
            name=name,
            active=active
        )
        return await self.manage_repository_use_case.add_repository(request)
    
    async def update_repository(
        self,
        repository_id: int,
        path: Optional[str] = None,
        name: Optional[str] = None,
        active: Optional[bool] = None
    ) -> RepositoryResponse:
        """Update an existing repository."""
        request = UpdateRepositoryRequest(
            repository_id=repository_id,
            path=path,
            name=name,
            active=active
        )
        return await self.manage_repository_use_case.update_repository(request)
    
    async def delete_repository(self, repository_id: int) -> RepositoryResponse:
        """Delete a repository from tracking."""
        return await self.manage_repository_use_case.delete_repository(repository_id)
    
    async def get_repository(self, repository_id: int) -> RepositoryResponse:
        """Get a repository by ID."""
        return await self.manage_repository_use_case.get_repository(repository_id)
    
    async def list_repositories(self, active_only: bool = False) -> RepositoryListResponse:
        """List all repositories."""
        return await self.manage_repository_use_case.list_repositories(active_only)
    
    async def toggle_repository_status(self, repository_id: int) -> RepositoryResponse:
        """Toggle a repository's active status."""
        # Get current repository
        current_repo_response = await self.get_repository(repository_id)
        current_repo = current_repo_response.repository
        
        # Toggle the active status
        request = UpdateRepositoryRequest(
            repository_id=repository_id,
            active=not current_repo.active
        )
        return await self.manage_repository_use_case.update_repository(request)