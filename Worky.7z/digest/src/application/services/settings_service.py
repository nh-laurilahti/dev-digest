"""Settings service for managing user preferences and configuration."""

from typing import Dict, Any, Optional, List
from datetime import datetime

from ...infrastructure.database.repositories import SQLAlchemySettingsRepository
from ...config.logging_config import get_logger
from ...config.settings import get_settings

logger = get_logger(__name__)


class SettingsService:
    """Service for managing application settings and user preferences."""
    
    def __init__(self, settings_repository: SQLAlchemySettingsRepository):
        self.settings_repository = settings_repository
        self.app_settings = get_settings()
        
        # Default settings with their metadata
        self.default_settings = {
            "openai_model": {
                "value": "gpt-5-mini",
                "description": "AI model to use for generating summaries",
                "type": "select",
                "options": [
                    "gpt-5-mini",
                    "gpt-4-turbo", 
                    "gpt-4o",
                    "gpt-3.5-turbo"
                ]
            },
            "custom_system_prompt": {
                "value": "",
                "description": "Custom system prompt for AI summarization (overrides default prompts)",
                "type": "textarea",
                "placeholder": "You are a technical analyst creating development summaries..."
            },
            "custom_summary_template": {
                "value": "",
                "description": "Custom template for digest summaries (supports markdown)",
                "type": "textarea",
                "placeholder": "# {repository} - {timespan}\n\n## Summary\n{summary}\n\n..."
            },
            "digest_tone": {
                "value": "professional",
                "description": "Tone of voice for digest summaries",
                "type": "select",
                "options": ["professional", "casual", "technical", "executive"]
            },
            "include_file_changes": {
                "value": True,
                "description": "Include file change details in digests",
                "type": "boolean"
            },
            "max_summary_length": {
                "value": 500,
                "description": "Maximum length for individual PR summaries (characters)",
                "type": "number",
                "min": 100,
                "max": 1000
            },
            "significance_threshold": {
                "value": 0.3,
                "description": "Minimum significance score to include changes (0.0-1.0)",
                "type": "number",
                "min": 0.0,
                "max": 1.0,
                "step": 0.1
            },
            "preferred_audience": {
                "value": "general",
                "description": "Default audience for digest generation",
                "type": "select",
                "options": ["general", "frontend", "backend", "devops", "security", "design", "executive"]
            },
            "enable_ai_summaries": {
                "value": True,
                "description": "Use AI for generating summaries (falls back to rule-based if disabled)",
                "type": "boolean"
            },
            "auto_categorize": {
                "value": True,
                "description": "Automatically categorize changes by type",
                "type": "boolean"
            },
            "digest_email_format": {
                "value": "html",
                "description": "Email format for digest notifications",
                "type": "select",
                "options": ["html", "markdown", "plain"]
            }
        }
    
    async def get_setting(self, key: str, use_default: bool = True) -> Any:
        """Get a setting value with fallback to defaults."""
        try:
            # Get from database first
            value = await self.settings_repository.get_setting(key)
            
            if value is not None:
                return value
            
            # Fall back to default if requested
            if use_default and key in self.default_settings:
                return self.default_settings[key]["value"]
            
            # Final fallback to app settings
            return getattr(self.app_settings, key, None)
            
        except Exception as e:
            logger.error(f"Error getting setting {key}: {e}")
            if use_default and key in self.default_settings:
                return self.default_settings[key]["value"]
            return None
    
    async def set_setting(self, key: str, value: Any) -> Dict[str, Any]:
        """Set a setting value."""
        try:
            # Get metadata for the setting
            setting_meta = self.default_settings.get(key, {})
            description = setting_meta.get("description", "")
            setting_type = setting_meta.get("type", "string")
            
            # Validate the setting value
            if not self._validate_setting(key, value):
                raise ValueError(f"Invalid value for setting {key}: {value}")
            
            # Store in database
            result = await self.settings_repository.set_setting(
                key=key,
                value=value,
                description=description,
                setting_type=setting_type
            )
            
            logger.info(f"Setting updated: {key} = {value}")
            return result
            
        except Exception as e:
            logger.error(f"Error setting {key}: {e}")
            raise
    
    async def get_all_settings(self) -> Dict[str, Dict[str, Any]]:
        """Get all settings with their metadata and current values."""
        try:
            # Get current values from database
            db_settings = await self.settings_repository.get_all_settings()
            db_values = {setting["key"]: setting["value"] for setting in db_settings}
            
            # Combine with defaults and metadata
            result = {}
            for key, metadata in self.default_settings.items():
                current_value = db_values.get(key, metadata["value"])
                
                result[key] = {
                    "value": current_value,
                    "default": metadata["value"],
                    "description": metadata["description"],
                    "type": metadata["type"],
                    "modified": key in db_values
                }
                
                # Add additional metadata if present
                if "options" in metadata:
                    result[key]["options"] = metadata["options"]
                if "placeholder" in metadata:
                    result[key]["placeholder"] = metadata["placeholder"]
                if "min" in metadata:
                    result[key]["min"] = metadata["min"]
                if "max" in metadata:
                    result[key]["max"] = metadata["max"]
                if "step" in metadata:
                    result[key]["step"] = metadata["step"]
            
            return result
            
        except Exception as e:
            logger.error(f"Error getting all settings: {e}")
            raise
    
    def get_all_settings_sync(self) -> Dict[str, Dict[str, Any]]:
        """Synchronous version of get_all_settings."""
        try:
            # Get current values from database
            db_settings = self.settings_repository.get_all_settings()
            db_values = {setting["key"]: setting["value"] for setting in db_settings}
            
            # Combine with defaults and metadata
            result = {}
            for key, metadata in self.default_settings.items():
                current_value = db_values.get(key, metadata["value"])
                
                result[key] = {
                    "value": current_value,
                    "default": metadata["value"],
                    "description": metadata["description"],
                    "type": metadata["type"],
                    "modified": key in db_values
                }
                
                # Add additional metadata if present
                if "options" in metadata:
                    result[key]["options"] = metadata["options"]
                if "placeholder" in metadata:
                    result[key]["placeholder"] = metadata["placeholder"]
                if "min" in metadata:
                    result[key]["min"] = metadata["min"]
                if "max" in metadata:
                    result[key]["max"] = metadata["max"]
                if "step" in metadata:
                    result[key]["step"] = metadata["step"]
            
            return result
            
        except Exception as e:
            logger.error(f"Error getting all settings: {e}")
            raise
    
    def set_setting_sync(self, key: str, value: Any) -> Dict[str, Any]:
        """Synchronous version of set_setting."""
        try:
            # Get metadata for the setting
            setting_meta = self.default_settings.get(key, {})
            description = setting_meta.get("description", "")
            setting_type = setting_meta.get("type", "string")
            
            # Validate the setting value
            if not self._validate_setting(key, value):
                raise ValueError(f"Invalid value for setting {key}: {value}")
            
            # Store in database
            result = self.settings_repository.set_setting(
                key=key,
                value=value,
                description=description,
                setting_type=setting_type
            )
            
            logger.info(f"Setting updated: {key} = {value}")
            return result
            
        except Exception as e:
            logger.error(f"Error setting {key}: {e}")
            raise
    
    async def reset_setting(self, key: str) -> bool:
        """Reset a setting to its default value."""
        try:
            if key not in self.default_settings:
                raise ValueError(f"Unknown setting: {key}")
            
            # Delete from database to fall back to default
            return await self.settings_repository.delete_setting(key)
            
        except Exception as e:
            logger.error(f"Error resetting setting {key}: {e}")
            raise
    
    async def reset_all_settings(self) -> bool:
        """Reset all settings to their default values."""
        try:
            success = True
            for key in self.default_settings.keys():
                try:
                    await self.settings_repository.delete_setting(key)
                except Exception as e:
                    logger.error(f"Error resetting {key}: {e}")
                    success = False
            
            logger.info("All settings reset to defaults")
            return success
            
        except Exception as e:
            logger.error(f"Error resetting all settings: {e}")
            raise
    
    async def export_settings(self) -> Dict[str, Any]:
        """Export all current settings for backup."""
        try:
            settings = await self.settings_repository.get_all_settings()
            return {
                "exported_at": datetime.now().isoformat(),
                "settings": {s["key"]: s["value"] for s in settings}
            }
        except Exception as e:
            logger.error(f"Error exporting settings: {e}")
            raise
    
    async def import_settings(self, settings_data: Dict[str, Any]) -> int:
        """Import settings from backup data."""
        try:
            if "settings" not in settings_data:
                raise ValueError("Invalid settings data format")
            
            imported_count = 0
            for key, value in settings_data["settings"].items():
                if key in self.default_settings:
                    await self.set_setting(key, value)
                    imported_count += 1
                else:
                    logger.warning(f"Skipping unknown setting: {key}")
            
            logger.info(f"Imported {imported_count} settings")
            return imported_count
            
        except Exception as e:
            logger.error(f"Error importing settings: {e}")
            raise
    
    def _validate_setting(self, key: str, value: Any) -> bool:
        """Validate a setting value against its constraints."""
        if key not in self.default_settings:
            return True  # Allow unknown settings for flexibility
        
        metadata = self.default_settings[key]
        setting_type = metadata.get("type", "string")
        
        try:
            if setting_type == "boolean":
                return isinstance(value, bool)
            
            elif setting_type == "number":
                if not isinstance(value, (int, float)):
                    return False
                
                min_val = metadata.get("min")
                max_val = metadata.get("max")
                
                if min_val is not None and value < min_val:
                    return False
                if max_val is not None and value > max_val:
                    return False
                
                return True
            
            elif setting_type == "select":
                options = metadata.get("options", [])
                return value in options
            
            elif setting_type in ["string", "textarea"]:
                return isinstance(value, str)
            
            return True
            
        except Exception as e:
            logger.error(f"Validation error for {key}: {e}")
            return False
    
    async def get_ai_model_config(self) -> Dict[str, Any]:
        """Get current AI model configuration."""
        model = await self.get_setting("openai_model")
        custom_prompt = await self.get_setting("custom_system_prompt")
        
        return {
            "model": model,
            "custom_system_prompt": custom_prompt,
            "available_models": self.default_settings["openai_model"]["options"]
        }
    
    async def get_digest_preferences(self) -> Dict[str, Any]:
        """Get current digest generation preferences."""
        return {
            "tone": await self.get_setting("digest_tone"),
            "audience": await self.get_setting("preferred_audience"),
            "include_file_changes": await self.get_setting("include_file_changes"),
            "max_summary_length": await self.get_setting("max_summary_length"),
            "significance_threshold": await self.get_setting("significance_threshold"),
            "enable_ai_summaries": await self.get_setting("enable_ai_summaries"),
            "auto_categorize": await self.get_setting("auto_categorize"),
            "custom_template": await self.get_setting("custom_summary_template")
        }