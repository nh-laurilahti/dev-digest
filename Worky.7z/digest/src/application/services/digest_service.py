"""Digest application service."""

from datetime import date
from typing import List, Optional, Dict, Any

from ..use_cases.create_digest import (
    CreateDigestUseCase, 
    CreateDigestRequest, 
    CreateDigestResponse
)
from ..use_cases.get_digest import (
    GetDigestUseCase,
    GetDigestByIdRequest,
    GetDigestByDateRequest, 
    GetDigestResponse
)
from ..use_cases.list_digests import (
    ListDigestsUseCase,
    ListDigestsRequest,
    ListDigestsResponse
)
from ...domain.repositories import DigestRepository
from ...domain.services import GitHubClient, SummaryGenerator
from ...config.logging_config import get_logger
from ...infrastructure.simple_status import SimpleStatusTracker

logger = get_logger(__name__)


class DigestService:
    """High-level service for digest operations."""
    
    def __init__(
        self,
        digest_repository: DigestRepository,
        github_client: GitHubClient,
        summary_generator: SummaryGenerator,
        repository_repository=None,
        status_tracker: SimpleStatusTracker = None
    ):
        self.create_digest_use_case = CreateDigestUseCase(
            digest_repository=digest_repository,
            repository_repository=repository_repository,
            github_client=github_client,
            summary_generator=summary_generator,
            status_tracker=status_tracker
        )
        self.get_digest_use_case = GetDigestUseCase(digest_repository)
        self.list_digests_use_case = ListDigestsUseCase(digest_repository)
    
    async def create_digest(
        self,
        repository: str,
        timespan: str,
        audience: str,
        custom_days: Optional[int] = None,
        view_mode: str = "summary"
    ) -> CreateDigestResponse:
        """Create a new digest."""
        request = CreateDigestRequest(
            repository=repository,
            timespan=timespan,
            audience=audience,
            custom_days=custom_days,
            view_mode=view_mode
        )
        return await self.create_digest_use_case.execute(request)
    
    async def get_digest_by_id(self, digest_id: int) -> GetDigestResponse:
        """Get a digest by ID."""
        request = GetDigestByIdRequest(digest_id=digest_id)
        return await self.get_digest_use_case.execute_by_id(request)
    
    async def get_digest_by_date(
        self, 
        repository: str, 
        date: date
    ) -> GetDigestResponse:
        """Get a digest by date and repository."""
        request = GetDigestByDateRequest(repository=repository, date=date)
        return await self.get_digest_use_case.execute_by_date(request)
    
    async def list_digests(
        self,
        repository: Optional[str] = None,
        page: int = 1,
        per_page: int = 10
    ) -> ListDigestsResponse:
        """List digests with pagination."""
        request = ListDigestsRequest(
            repository=repository,
            page=page,
            per_page=per_page
        )
        return await self.list_digests_use_case.execute(request)
    
    async def get_digest_stats(self, digest_id: int) -> Dict[str, Any]:
        """Get detailed statistics for a digest."""
        try:
            response = await self.get_digest_by_id(digest_id)
            digest = response.digest
            
            # Return the stored stats plus some calculated metrics
            stats = digest.stats or {}
            
            # Add some computed stats
            computed_stats = {
                "content_length": len(digest.content),
                "summary_length": len(digest.summary),
                "has_content": bool(digest.content and digest.content.strip()),
                "created_days_ago": (date.today() - digest.date).days if digest.date else 0
            }
            
            return {**stats, **computed_stats}
            
        except Exception as e:
            logger.error(f"Error getting digest stats: {e}")
            raise