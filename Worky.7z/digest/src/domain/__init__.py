"""Domain layer for Daily Dev Digest application."""

from .entities import (
    ChangeType,
    AudienceType,
    TimespanType,
    PullRequest,
    PullRequestFile,
    PullRequestCommit,
    ChangeAnalysis,
    DigestEntry,
    Repository,
    Digest,
)

from .repositories import (
    DigestRepository,
    RepositoryRepository,
    GitHubRepository,
)

from .services import (
    ChangeAnalyzer,
    SummaryGenerator,
    DigestGenerator,
    AudienceFilter,
)

__all__ = [
    # Entities
    "ChangeType",
    "AudienceType", 
    "TimespanType",
    "PullRequest",
    "PullRequestFile",
    "PullRequestCommit",
    "ChangeAnalysis",
    "DigestEntry",
    "Repository",
    "Digest",
    # Repository Interfaces
    "DigestRepository",
    "RepositoryRepository", 
    "GitHubRepository",
    # Service Interfaces
    "ChangeAnalyzer",
    "SummaryGenerator",
    "DigestGenerator",
    "AudienceFilter",
]