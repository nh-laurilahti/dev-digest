"""Domain services for business logic."""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from datetime import datetime, date

from .entities import (
    PullRequest,
    ChangeAnalysis,
    DigestEntry,
    AudienceType,
    TimespanType,
)


class GitHubClient(ABC):
    """Interface for GitHub API interactions."""
    
    @abstractmethod
    async def get_pull_requests(
        self, 
        repo_path: str, 
        start_date: datetime, 
        end_date: datetime
    ) -> List[PullRequest]:
        """Get pull requests for a repository within date range."""
        pass
    
    @abstractmethod
    async def validate_repository(self, repo_path: str) -> bool:
        """Validate that repository exists and is accessible."""
        pass
    
    @abstractmethod
    async def get_repository_info(self, repo_path: str) -> Dict[str, Any]:
        """Get basic repository information."""
        pass


class ChangeAnalyzer(ABC):
    """Interface for analyzing changes in pull requests."""
    
    @abstractmethod
    async def analyze_pull_request(self, pr: PullRequest) -> ChangeAnalysis:
        """Analyze a single pull request for change type and significance."""
        pass
    
    @abstractmethod
    async def analyze_pull_requests(self, prs: List[PullRequest]) -> List[ChangeAnalysis]:
        """Analyze multiple pull requests."""
        pass


class SummaryGenerator(ABC):
    """Interface for generating summaries of changes."""
    
    @abstractmethod
    async def summarize_change(
        self, 
        pr: PullRequest, 
        analysis: ChangeAnalysis,
        audience: AudienceType = AudienceType.GENERAL
    ) -> DigestEntry:
        """Generate a summary for a single change."""
        pass
    
    @abstractmethod
    async def create_digest_summary(self, entries: List[DigestEntry], audience: AudienceType = AudienceType.GENERAL, repository: str = "", timespan: str = "today") -> str:
        """Create a brief summary of all digest entries."""
        pass
    
    @abstractmethod
    async def create_executive_summary(
        self,
        entries: List[DigestEntry],
        repository: str,
        audience: AudienceType = AudienceType.GENERAL,
        timespan: str = "24 hours"
    ) -> str:
        """Create a detailed executive summary."""
        pass


class DigestGenerator(ABC):
    """Interface for generating HTML digest reports."""
    
    @abstractmethod
    async def generate_html(self, digest_data: Dict[str, Any]) -> str:
        """Generate HTML content for a digest."""
        pass
    
    @abstractmethod
    async def save_digest(self, html_content: str, filename: Optional[str] = None) -> str:
        """Save digest HTML to file and return the file path."""
        pass


class AudienceFilter(ABC):
    """Interface for filtering content by audience."""
    
    @abstractmethod
    async def filter_pull_requests(
        self, 
        prs: List[PullRequest], 
        audience: AudienceType
    ) -> List[PullRequest]:
        """Filter pull requests by audience relevance."""
        pass
    
    @abstractmethod
    async def get_audience_profile(self, audience: AudienceType) -> Dict[str, Any]:
        """Get profile information for an audience type."""
        pass


