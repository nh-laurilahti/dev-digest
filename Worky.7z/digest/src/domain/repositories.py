"""Repository interfaces for domain entities."""

from abc import ABC, abstractmethod
from datetime import datetime, date
from typing import List, Optional, Dict, Any
from uuid import UUID

from .entities import (
    Digest,
    Repository, 
    DigestEntry,
    PullRequest,
)


class DigestRepository(ABC):
    """Interface for digest data access."""
    
    @abstractmethod
    async def create(self, digest: Digest) -> Digest:
        """Create a new digest."""
        pass
    
    @abstractmethod
    async def get_by_id(self, digest_id: int) -> Optional[Digest]:
        """Get a digest by ID."""
        pass
    
    @abstractmethod
    async def get_by_date(self, date: date, repository: str) -> Optional[Digest]:
        """Get a digest by date and repository."""
        pass
    
    @abstractmethod
    async def get_recent(
        self, 
        limit: int = 10, 
        offset: int = 0,
        repository: Optional[str] = None
    ) -> List[Digest]:
        """Get recent digests with pagination."""
        pass
    
    @abstractmethod
    async def update(self, digest: Digest) -> Digest:
        """Update an existing digest."""
        pass
    
    @abstractmethod
    async def delete(self, digest_id: int) -> bool:
        """Delete a digest."""
        pass


class RepositoryRepository(ABC):
    """Interface for repository data access."""
    
    @abstractmethod
    async def create(self, repository: Repository) -> Repository:
        """Create a new repository."""
        pass
    
    @abstractmethod
    async def get_by_id(self, repo_id: int) -> Optional[Repository]:
        """Get a repository by ID."""
        pass
    
    @abstractmethod
    async def get_by_path(self, path: str) -> Optional[Repository]:
        """Get a repository by path."""
        pass
    
    @abstractmethod
    async def get_active(self) -> List[Repository]:
        """Get all active repositories."""
        pass
    
    @abstractmethod
    async def get_all(self) -> List[Repository]:
        """Get all repositories."""
        pass
    
    @abstractmethod
    async def update(self, repository: Repository) -> Repository:
        """Update an existing repository."""
        pass
    
    @abstractmethod
    async def delete(self, repo_id: int) -> bool:
        """Delete a repository."""
        pass



class GitHubRepository(ABC):
    """Interface for GitHub data access."""
    
    @abstractmethod
    async def get_pull_requests(
        self,
        repo_path: str,
        start_time: datetime,
        end_time: datetime,
        state: str = "closed"
    ) -> List[PullRequest]:
        """Get pull requests for a repository within a time range."""
        pass
    
    @abstractmethod
    async def get_ongoing_pull_requests(self, repo_path: str) -> List[PullRequest]:
        """Get ongoing/draft pull requests for a repository."""
        pass
    
    @abstractmethod
    async def get_repository_info(self, repo_path: str) -> Dict[str, Any]:
        """Get basic repository information."""
        pass