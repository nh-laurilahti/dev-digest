"""Domain entities for the Daily Dev Digest application."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional
from uuid import UUID, uuid4


class ChangeType(Enum):
    """Types of changes that can occur in a repository."""
    DEPENDENCY = "dependency"
    REFACTOR = "refactor"
    FEATURE = "feature"
    BUGFIX = "bugfix"
    DOCUMENTATION = "documentation"
    TESTING = "testing"
    CONFIGURATION = "configuration"
    ARCHITECTURE = "architecture"


class AudienceType(Enum):
    """Target audiences for digest summaries."""
    FRONTEND = "frontend"
    BACKEND = "backend" 
    DEVOPS = "devops"
    SECURITY = "security"
    DESIGN = "design"
    EXECUTIVE = "executive"
    GENERAL = "general"


class TimespanType(Enum):
    """Time ranges for digest generation."""
    TODAY = "today"
    YESTERDAY = "yesterday"
    LAST_WEEK = "last_week"
    LAST_MONTH = "last_month"
    CUSTOM = "custom"


@dataclass
class PullRequestFile:
    """Represents a file changed in a pull request."""
    filename: str
    additions: int
    deletions: int
    changes: int
    patch: Optional[str] = None


@dataclass  
class PullRequestCommit:
    """Represents a commit in a pull request."""
    sha: str
    message: str
    author: str
    date: datetime


@dataclass
class CommitInfo:
    """Represents commit information from GitHub API."""
    sha: str
    message: str
    author: str
    date: datetime
    url: str
    additions: int = 0
    deletions: int = 0
    files_changed: int = 0


@dataclass
class PullRequest:
    """Represents a pull request from GitHub."""
    number: int
    title: str
    body: str
    author: str
    html_url: str
    labels: List[str]
    draft: bool
    created_at: datetime
    updated_at: datetime
    merged_at: Optional[datetime]
    files_changed: List[PullRequestFile]
    commits: List[PullRequestCommit]
    additions: int
    deletions: int
    is_ongoing: bool = False


@dataclass
class ChangeAnalysis:
    """Analysis result of a pull request or set of changes."""
    change_type: ChangeType
    significance: float  # 0.0 to 1.0
    summary: str
    details: List[str]
    affected_components: List[str]
    risk_level: str = "low"  # low, medium, high


@dataclass
class DigestEntry:
    """A single entry in a digest report."""
    id: UUID = field(default_factory=uuid4)
    title: str = ""
    summary: str = ""
    author: str = ""
    pr_url: str = ""
    labels: List[str] = field(default_factory=list)
    significance: float = 0.0
    change_type: str = ""
    is_ongoing: bool = False
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Repository:
    """Represents a GitHub repository being tracked."""
    id: Optional[int] = None
    path: str = ""
    name: str = ""
    active: bool = True
    last_scan: Optional[datetime] = None
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Digest:
    """Represents a complete digest report."""
    id: Optional[int] = None
    date: datetime = field(default_factory=lambda: datetime.now().date())
    repository: str = ""
    summary: str = ""
    content: str = ""
    stats: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)


