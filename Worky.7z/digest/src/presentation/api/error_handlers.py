"""Error handlers for API routes."""

from flask import Flask, jsonify, request
from werkzeug.exceptions import HTTPException

from ...core.exceptions import (
    DigestError, 
    ValidationError, 
    NotFoundError, 
    BusinessLogicError,
    ExternalServiceError,
    ConfigurationError
)
from ...config.logging_config import get_logger

logger = get_logger(__name__)


def setup_error_handlers(app: Flask) -> None:
    """Set up error handlers for the Flask application."""
    
    @app.errorhandler(ValidationError)
    def handle_validation_error(error: ValidationError):
        """Handle validation errors."""
        logger.warning(f"Validation error: {error}")
        return jsonify({
            "error": "Validation Error",
            "message": str(error),
            "field": error.field,
            "value": error.value,
            "error_code": error.error_code
        }), 400
    
    @app.errorhandler(NotFoundError)
    def handle_not_found_error(error: NotFoundError):
        """Handle not found errors."""
        logger.info(f"Not found: {error}")
        return jsonify({
            "error": "Not Found",
            "message": str(error),
            "error_code": error.error_code
        }), 404
    
    @app.errorhandler(BusinessLogicError)
    def handle_business_logic_error(error: BusinessLogicError):
        """Handle business logic errors."""
        logger.warning(f"Business logic error: {error}")
        return jsonify({
            "error": "Business Logic Error",
            "message": str(error),
            "error_code": error.error_code
        }), 422
    
    @app.errorhandler(ExternalServiceError)
    def handle_external_service_error(error: ExternalServiceError):
        """Handle external service errors."""
        logger.error(f"External service error: {error}")
        return jsonify({
            "error": "External Service Error", 
            "message": "An external service is currently unavailable",
            "service": error.service,
            "error_code": error.error_code
        }), 503
    
    @app.errorhandler(ConfigurationError)
    def handle_configuration_error(error: ConfigurationError):
        """Handle configuration errors."""
        logger.error(f"Configuration error: {error}")
        return jsonify({
            "error": "Configuration Error",
            "message": "Service configuration issue",
            "error_code": error.error_code
        }), 500
    
    @app.errorhandler(DigestError)
    def handle_digest_error(error: DigestError):
        """Handle general digest errors."""
        logger.error(f"Digest error: {error}")
        return jsonify({
            "error": "Internal Error",
            "message": "An internal error occurred",
            "error_code": error.error_code
        }), 500
    
    @app.errorhandler(HTTPException)
    def handle_http_exception(error: HTTPException):
        """Handle HTTP exceptions."""
        logger.info(f"HTTP error {error.code}: {error.description}")
        return jsonify({
            "error": error.name,
            "message": error.description
        }), error.code
    
    @app.errorhandler(Exception)
    def handle_generic_exception(error: Exception):
        """Handle unexpected exceptions."""
        logger.error(f"Unexpected error: {error}", exc_info=True)
        return jsonify({
            "error": "Internal Server Error",
            "message": "An unexpected error occurred"
        }), 500
    
    @app.errorhandler(400)
    def handle_bad_request(error):
        """Handle bad request errors."""
        return jsonify({
            "error": "Bad Request",
            "message": "Invalid request format or parameters"
        }), 400
    
    @app.errorhandler(405)
    def handle_method_not_allowed(error):
        """Handle method not allowed errors."""
        return jsonify({
            "error": "Method Not Allowed",
            "message": f"Method {request.method} not allowed for this endpoint"
        }), 405
    
    @app.errorhandler(429)
    def handle_rate_limit(error):
        """Handle rate limiting errors."""
        return jsonify({
            "error": "Rate Limit Exceeded",
            "message": "Too many requests. Please try again later."
        }), 429