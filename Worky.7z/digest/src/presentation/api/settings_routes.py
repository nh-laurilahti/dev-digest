"""API routes for settings management."""

from flask import Blueprint, request, jsonify, current_app
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from typing import Dict, Any

from ...infrastructure.database.repositories import SQLAlchemySettingsRepository
from ...application.services.settings_service import SettingsService
from ...infrastructure.database.models import Base
from ...config.logging_config import get_logger
from ...config.settings import get_settings

logger = get_logger(__name__)

settings_bp = Blueprint('settings', __name__, url_prefix='/api/settings')


def get_settings_service() -> SettingsService:
    """Get settings service instance."""
    app_settings = get_settings()
    engine = create_engine(app_settings.database_url)
    Base.metadata.create_all(engine)
    SessionLocal = sessionmaker(bind=engine)
    
    session = SessionLocal()
    settings_repo = SQLAlchemySettingsRepository(session)
    return SettingsService(settings_repo)


@settings_bp.route('', methods=['GET'])
def get_all_settings():
    """Get all settings with their metadata."""
    try:
        service = get_settings_service()
        settings = service.get_all_settings_sync()
        
        return jsonify({
            "success": True,
            "data": settings
        })
        
    except Exception as e:
        logger.error(f"Error getting settings: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@settings_bp.route('/<string:key>', methods=['GET'])
def get_setting(key: str):
    """Get a specific setting value."""
    try:
        service = get_settings_service()
        value = service.settings_repository.get_setting(key)
        
        if value is None:
            # Try to get default value
            if key in service.default_settings:
                value = service.default_settings[key]["value"]
            else:
                return jsonify({
                    "success": False,
                    "error": "Setting not found"
                }), 404
        
        return jsonify({
            "success": True,
            "data": {
                "key": key,
                "value": value
            }
        })
        
    except Exception as e:
        logger.error(f"Error getting setting {key}: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@settings_bp.route('/<string:key>', methods=['PUT', 'POST'])
def set_setting(key: str):
    """Set a setting value."""
    try:
        data = request.get_json()
        if not data or 'value' not in data:
            return jsonify({
                "success": False,
                "error": "Missing 'value' in request data"
            }), 400
        
        service = get_settings_service()
        result = service.set_setting_sync(key, data['value'])
        
        return jsonify({
            "success": True,
            "data": result
        })
        
    except ValueError as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 400
    except Exception as e:
        logger.error(f"Error setting {key}: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@settings_bp.route('/batch', methods=['PUT', 'POST'])
def set_multiple_settings():
    """Set multiple settings at once."""
    try:
        data = request.get_json()
        if not data or 'settings' not in data:
            return jsonify({
                "success": False,
                "error": "Missing 'settings' in request data"
            }), 400
        
        service = get_settings_service()
        results = {}
        errors = {}
        
        for key, value in data['settings'].items():
            try:
                results[key] = service.set_setting_sync(key, value)
            except Exception as e:
                errors[key] = str(e)
                logger.error(f"Error setting {key}: {e}")
        
        return jsonify({
            "success": len(errors) == 0,
            "data": results,
            "errors": errors if errors else None
        })
        
    except Exception as e:
        logger.error(f"Error setting multiple settings: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@settings_bp.route('/<string:key>', methods=['DELETE'])
def reset_setting(key: str):
    """Reset a setting to its default value."""
    try:
        service = get_settings_service()
        
        if key not in service.default_settings:
            return jsonify({
                "success": False,
                "error": f"Unknown setting: {key}"
            }), 400
        
        success = service.settings_repository.delete_setting(key)
        
        return jsonify({
            "success": success,
            "message": f"Setting '{key}' reset to default"
        })
        
    except Exception as e:
        logger.error(f"Error resetting setting {key}: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@settings_bp.route('/reset', methods=['POST'])
def reset_all_settings():
    """Reset all settings to their default values."""
    try:
        service = get_settings_service()
        success = True
        
        for key in service.default_settings.keys():
            try:
                service.settings_repository.delete_setting(key)
            except Exception as e:
                logger.error(f"Error resetting {key}: {e}")
                success = False
        
        return jsonify({
            "success": success,
            "message": "All settings reset to defaults"
        })
        
    except Exception as e:
        logger.error(f"Error resetting all settings: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500