"""Simple status API routes."""

from flask import Blueprint, jsonify, g

from ...config.logging_config import get_logger

logger = get_logger(__name__)


def create_status_blueprint() -> Blueprint:
    """Create simple status routes blueprint."""
    bp = Blueprint('status', __name__)
    
    @bp.route('/<session_id>', methods=['GET'])
    def get_status(session_id: str):
        """Get status for a session."""
        try:
            status_tracker = g.container.get("StatusTracker")
            status = status_tracker.get_status(session_id)
            
            if not status:
                return jsonify({
                    "error": "Not Found",
                    "message": f"Status for session {session_id} not found"
                }), 404
            
            return jsonify({
                "success": True,
                "status": status
            })
            
        except Exception as e:
            logger.error(f"Error getting status for session {session_id}: {e}")
            return jsonify({
                "error": "Internal Server Error",
                "message": "Failed to retrieve status"
            }), 500
    
    return bp