"""Async route wrapper for Flask."""

import asyncio
from functools import wraps
from flask import Flask, jsonify


def async_route(f):
    """Decorator to make Flask routes async-compatible."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            # Try to get existing event loop
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If we're in an async context, create a new event loop
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(asyncio.run, f(*args, **kwargs))
                    return future.result()
            else:
                # Run in existing loop
                return loop.run_until_complete(f(*args, **kwargs))
        except RuntimeError:
            # No event loop, create one
            return asyncio.run(f(*args, **kwargs))
    return decorated_function


def create_async_app() -> Flask:
    """Create Flask app with async support."""
    app = Flask(__name__)
    
    # Enable async support
    app.config['ASYNC_MODE'] = True
    
    return app