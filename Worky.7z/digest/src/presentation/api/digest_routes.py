"""Digest API routes."""

from datetime import date, datetime
from flask import Blueprint, request, jsonify, g
from typing import Optional

from .middleware import validate_json, rate_limit
from .async_routes import async_route
from ...application.services.digest_service import DigestService
from ...config.logging_config import get_logger

logger = get_logger(__name__)


def create_digest_blueprint() -> Blueprint:
    """Create digest routes blueprint."""
    bp = Blueprint('digest', __name__)
    
    @bp.route('', methods=['POST'])
    @validate_json()
    @rate_limit(max_requests=10, window_minutes=1)
    def create_digest():
        """Create a new digest."""
        try:
            data = request.get_json()
            
            # Validate required fields
            if not data.get('repository'):
                return jsonify({
                    "error": "Validation Error",
                    "message": "Repository is required"
                }), 400
            
            if not data.get('timespan'):
                return jsonify({
                    "error": "Validation Error", 
                    "message": "Timespan is required"
                }), 400
            
            if not data.get('audience'):
                return jsonify({
                    "error": "Validation Error",
                    "message": "Audience is required"
                }), 400
            
            # Get digest service from container
            digest_service: DigestService = g.container.get("DigestService")
            
            # Create digest - using asyncio.run for now
            import asyncio
            response = asyncio.run(digest_service.create_digest(
                repository=data['repository'],
                timespan=data['timespan'],
                audience=data['audience'],
                custom_days=data.get('custom_days'),
                view_mode=data.get('view_mode', 'summary')
            ))
            
            return jsonify({
                "success": response.success,
                "message": response.message,
                "session_id": response.session_id,
                "digest": {
                    "id": response.digest.id,
                    "date": response.digest.date.isoformat(),
                    "repository": response.digest.repository,
                    "summary": response.digest.summary,
                    "content": response.digest.content,
                    "stats": response.digest.stats,
                    "created_at": response.digest.created_at.isoformat()
                }
            }), 201
            
        except Exception as e:
            logger.error(f"Error creating digest: {e}")
            raise
    
    @bp.route('/<int:digest_id>', methods=['GET'])
    def get_digest(digest_id: int):
        """Get a digest by ID."""
        try:
            digest_service: DigestService = g.container.get("DigestService")
            
            import asyncio
            response = asyncio.run(digest_service.get_digest_by_id(digest_id))
            
            return jsonify({
                "success": response.success,
                "message": response.message,
                "digest": {
                    "id": response.digest.id,
                    "date": response.digest.date.isoformat(),
                    "repository": response.digest.repository,
                    "summary": response.digest.summary,
                    "content": response.digest.content,
                    "stats": response.digest.stats,
                    "created_at": response.digest.created_at.isoformat()
                }
            })
            
        except Exception as e:
            logger.error(f"Error getting digest {digest_id}: {e}")
            raise
    
    @bp.route('', methods=['GET'])
    def list_digests():
        """List digests with optional filtering."""
        try:
            # Parse query parameters
            repository = request.args.get('repository')
            page = int(request.args.get('page', 1))
            per_page = int(request.args.get('per_page', 10))
            
            digest_service: DigestService = g.container.get("DigestService")
            
            import asyncio
            response = asyncio.run(digest_service.list_digests(
                repository=repository,
                page=page,
                per_page=per_page
            ))
            
            return jsonify({
                "success": response.success,
                "message": response.message,
                "pagination": {
                    "page": response.page,
                    "per_page": response.per_page,
                    "total_count": response.total_count,
                    "has_next": response.has_next,
                    "has_prev": response.has_prev
                },
                "digests": [
                    {
                        "id": digest.id,
                        "date": digest.date.isoformat(),
                        "repository": digest.repository,
                        "summary": digest.summary,
                        "stats": digest.stats,
                        "created_at": digest.created_at.isoformat()
                    }
                    for digest in response.digests
                ]
            })
            
        except ValueError as e:
            return jsonify({
                "error": "Validation Error",
                "message": f"Invalid parameter: {e}"
            }), 400
        except Exception as e:
            logger.error(f"Error listing digests: {e}")
            raise
    
    @bp.route('/by-date', methods=['GET'])
    def get_digest_by_date():
        """Get a digest by repository and date."""
        try:
            repository = request.args.get('repository')
            date_str = request.args.get('date')
            
            if not repository:
                return jsonify({
                    "error": "Validation Error",
                    "message": "Repository parameter is required"
                }), 400
            
            if not date_str:
                return jsonify({
                    "error": "Validation Error", 
                    "message": "Date parameter is required"
                }), 400
            
            try:
                digest_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            except ValueError:
                return jsonify({
                    "error": "Validation Error",
                    "message": "Date must be in YYYY-MM-DD format"
                }), 400
            
            digest_service: DigestService = g.container.get("DigestService")
            
            import asyncio
            response = asyncio.run(digest_service.get_digest_by_date(repository, digest_date))
            
            return jsonify({
                "success": response.success,
                "message": response.message,
                "digest": {
                    "id": response.digest.id,
                    "date": response.digest.date.isoformat(),
                    "repository": response.digest.repository,
                    "summary": response.digest.summary,
                    "content": response.digest.content,
                    "stats": response.digest.stats,
                    "created_at": response.digest.created_at.isoformat()
                }
            })
            
        except Exception as e:
            logger.error(f"Error getting digest by date: {e}")
            raise
    
    @bp.route('/<int:digest_id>/stats', methods=['GET'])
    def get_digest_stats(digest_id: int):
        """Get detailed statistics for a digest."""
        try:
            digest_service: DigestService = g.container.get("DigestService")
            
            import asyncio
            stats = asyncio.run(digest_service.get_digest_stats(digest_id))
            
            return jsonify({
                "success": True,
                "message": "Statistics retrieved successfully",
                "stats": stats
            })
            
        except Exception as e:
            logger.error(f"Error getting digest stats {digest_id}: {e}")
            raise

    @bp.route('/<int:digest_id>/view', methods=['GET'])
    def view_digest(digest_id: int):
        """View digest as HTML page."""
        try:
            digest_service: DigestService = g.container.get("DigestService")
            
            import asyncio
            response = asyncio.run(digest_service.get_digest_by_id(digest_id))
            
            if not response.success:
                return f"<html><body><h1>Error</h1><p>{response.message}</p><a href='/archive'>← Back to Archive</a></body></html>", 404
            
            digest = response.digest
            date_str = digest.date.strftime("%B %d, %Y")
            
            # Generate HTML view
            html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Dev Digest - {digest.repository} - {date_str}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .header-content {{
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .back-link {{
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 20px;
            background: rgba(255,255,255,0.2);
            transition: background 0.3s;
        }}
        .back-link:hover {{
            background: rgba(255,255,255,0.3);
        }}
        .container {{
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }}
        .digest-card {{
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 30px;
            margin-bottom: 30px;
        }}
        .digest-title {{
            font-size: 1.8rem;
            color: #333;
            margin-bottom: 10px;
            font-weight: 600;
        }}
        .digest-meta {{
            color: #666;
            margin-bottom: 30px;
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }}
        .digest-content {{
            color: #444;
            white-space: pre-wrap;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>📊 {digest.repository} - {date_str}</h1>
            <a href="/archive" class="back-link">← Back to Archive</a>
        </div>
    </div>
    
    <div class="container">
        <div class="digest-card">
            <div class="digest-title">Daily Development Digest</div>
            <div class="digest-meta">
                <span>📦 Repository: {digest.repository}</span>
                <span>📅 Date: {date_str}</span>
                <span>⏰ Generated: {digest.created_at.strftime("%I:%M %p")}</span>
            </div>
            <div class="digest-content">
{digest.content or digest.summary or 'No content available.'}
            </div>
        </div>
    </div>
</body>
</html>
"""
            return html_content
            
        except Exception as e:
            logger.error(f"Error viewing digest {digest_id}: {e}")
            return f"<html><body><h1>Error</h1><p>Failed to load digest: {str(e)}</p><a href='/archive'>← Back to Archive</a></body></html>", 500
    
    return bp