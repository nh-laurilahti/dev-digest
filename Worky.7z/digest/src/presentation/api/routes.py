"""Main API routes and application factory."""

from flask import Flask
from sqlalchemy.orm import sessionmaker

from .digest_routes import create_digest_blueprint
from .repository_routes import create_repository_blueprint
from .status_routes import create_status_blueprint
from .settings_routes import settings_bp
from .middleware import setup_middleware
from .error_handlers import setup_error_handlers
from ...core.dependencies import Container
from ...config.settings import get_settings
from ...config.logging_config import setup_logging
from ...infrastructure.database.models import Base
from ...infrastructure.database.repositories import SQLAlchemyDigestRepository, SQLAlchemyRepositoryRepository
from ...infrastructure.external.github_client import GitHubApiClient
from ...infrastructure.external.openai_client import OpenAIClient
from ...application.services.digest_service import DigestService
from ...application.services.repository_service import RepositoryService
from ...infrastructure.simple_status import SimpleStatusTracker

from sqlalchemy import create_engine


def create_app(config_override=None) -> Flask:
    """Create and configure the Flask application."""
    app = Flask(__name__)
    
    # Load configuration
    settings = get_settings()
    if config_override:
        for key, value in config_override.items():
            setattr(settings, key, value)
    
    app.config['SETTINGS'] = settings
    
    # Setup logging
    setup_logging()
    
    # Create dependency injection container
    container = setup_dependencies(settings)
    
    # Setup middleware
    setup_middleware(app, container)
    
    # Setup error handlers
    setup_error_handlers(app)
    
    # Register blueprints
    register_blueprints(app)
    
    # Health check endpoint
    @app.route('/health')
    def health_check():
        return {
            "status": "healthy",
            "service": "Daily Dev Digest API",
            "version": "1.0.0"
        }
    
    # Dashboard routes
    @app.route('/')
    def dashboard():
        """Serve the dashboard HTML."""
        import os
        from flask import send_file
        
        dashboard_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '..', 'templates', 'dashboard.html')
        dashboard_path = os.path.abspath(dashboard_path)
        
        if os.path.exists(dashboard_path):
            return send_file(dashboard_path)
        else:
            return "Dashboard not found", 404
    
    @app.route('/archive')
    def archive_page():
        """Serve the archive HTML."""
        import os
        from flask import send_file
        
        archive_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '..', 'templates', 'archive.html')
        archive_path = os.path.abspath(archive_path)
        
        if os.path.exists(archive_path):
            return send_file(archive_path)
        else:
            return "Archive not found", 404
    
    @app.route('/settings')
    def settings_page():
        """Serve the settings HTML."""
        import os
        from flask import send_file
        
        settings_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '..', 'templates', 'settings.html')
        settings_path = os.path.abspath(settings_path)
        
        if os.path.exists(settings_path):
            return send_file(settings_path)
        else:
            return "Settings page not found", 404
    
    # API info endpoint
    @app.route('/api/v1/info')
    def api_info():
        return {
            "name": "Daily Dev Digest API",
            "version": "1.0.0",
            "description": "API for generating and managing development digests",
            "endpoints": {
                "digests": "/api/v1/digests",
                "repositories": "/api/v1/repositories",
                "status": "/api/v1/status"
            }
        }
    
    # Redirect legacy endpoints to v1 API
    @app.route('/api/generate', methods=['POST'])
    def redirect_generate():
        """Redirect to v1 generate endpoint."""
        from flask import redirect, request
        return redirect('/api/v1/digests', code=307)
    
    @app.route('/api/repositories/suggest')
    def redirect_repo_suggest():
        """Redirect to v1 repository suggestions endpoint."""
        from flask import redirect
        return redirect('/api/v1/repositories/suggest', code=302)
    
    @app.route('/api/digests')
    def redirect_digests():
        """Redirect to v1 digests endpoint."""
        from flask import redirect
        return redirect('/api/v1/digests', code=302)
    
    
    return app


def setup_dependencies(settings) -> Container:
    """Set up dependency injection container."""
    container = Container()
    
    # Database setup
    engine = create_engine(settings.database_url)
    Base.metadata.create_all(engine)
    SessionLocal = sessionmaker(bind=engine)
    
    # Register repositories
    def get_digest_repository():
        session = SessionLocal()
        return SQLAlchemyDigestRepository(session)
    
    def get_repository_repository():
        session = SessionLocal()
        return SQLAlchemyRepositoryRepository(session)
    
    container.register_factory("DigestRepository", get_digest_repository)
    container.register_factory("RepositoryRepository", get_repository_repository)
    
    # Register external services
    container.register("GitHubClient", GitHubApiClient(settings.github_token), singleton=True)
    container.register("OpenAIClient", OpenAIClient(settings.openai_api_key), singleton=True)
    container.register("StatusTracker", SimpleStatusTracker(), singleton=True) 
    
    # Register application services
    def get_digest_service():
        return DigestService(
            digest_repository=container.get("DigestRepository"),
            github_client=container.get("GitHubClient"),
            summary_generator=container.get("OpenAIClient"),
            repository_repository=container.get("RepositoryRepository"),
            status_tracker=container.get("StatusTracker")
        )
    
    def get_repository_service():
        return RepositoryService(
            repository_repository=container.get("RepositoryRepository"),
            github_client=container.get("GitHubClient")
        )
    
    container.register_factory("DigestService", get_digest_service)
    container.register_factory("RepositoryService", get_repository_service)
    
    return container


def register_blueprints(app: Flask) -> None:
    """Register API blueprints."""
    # Register digest routes
    digest_bp = create_digest_blueprint()
    app.register_blueprint(digest_bp, url_prefix='/api/v1/digests')
    
    # Register repository routes
    repository_bp = create_repository_blueprint()
    app.register_blueprint(repository_bp, url_prefix='/api/v1/repositories')
    
    # Register status routes
    status_bp = create_status_blueprint()
    app.register_blueprint(status_bp, url_prefix='/api/v1/status')
    
    # Register settings routes
    app.register_blueprint(settings_bp)
    


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)