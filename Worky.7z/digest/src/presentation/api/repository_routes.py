"""Repository API routes."""

from flask import Blueprint, request, jsonify, g

from .middleware import validate_json, rate_limit
from ...application.services.repository_service import RepositoryService
from ...config.logging_config import get_logger
import asyncio

logger = get_logger(__name__)


def create_repository_blueprint() -> Blueprint:
    """Create repository routes blueprint."""
    bp = Blueprint('repository', __name__)
    
    @bp.route('', methods=['POST'])
    @validate_json()
    @rate_limit(max_requests=20, window_minutes=1)
    def add_repository():
        """Add a new repository to tracking."""
        try:
            data = request.get_json()
            
            # Validate required fields
            if not data.get('path'):
                return jsonify({
                    "error": "Validation Error",
                    "message": "Repository path is required"
                }), 400
            
            repository_service: RepositoryService = g.container.get("RepositoryService")
            
            response = asyncio.run(repository_service.add_repository(
                path=data['path'],
                name=data.get('name'),
                active=data.get('active', True)
            ))
            
            return jsonify({
                "success": response.success,
                "message": response.message,
                "repository": {
                    "id": response.repository.id,
                    "path": response.repository.path,
                    "name": response.repository.name,
                    "active": response.repository.active,
                    "last_scan": response.repository.last_scan.isoformat() if response.repository.last_scan else None,
                    "created_at": response.repository.created_at.isoformat()
                }
            }), 201
            
        except Exception as e:
            logger.error(f"Error adding repository: {e}")
            raise
    
    @bp.route('', methods=['GET'])
    def list_repositories():
        """List all repositories."""
        try:
            active_only = request.args.get('active_only', 'false').lower() == 'true'
            
            repository_service: RepositoryService = g.container.get("RepositoryService")
            
            response = asyncio.run(repository_service.list_repositories(active_only=active_only))
            
            return jsonify({
                "success": response.success,
                "message": response.message,
                "repositories": [
                    {
                        "id": repo.id,
                        "path": repo.path,
                        "name": repo.name,
                        "active": repo.active,
                        "last_scan": repo.last_scan.isoformat() if repo.last_scan else None,
                        "created_at": repo.created_at.isoformat()
                    }
                    for repo in response.repositories
                ]
            })
            
        except Exception as e:
            logger.error(f"Error listing repositories: {e}")
            raise
    
    @bp.route('/<int:repository_id>', methods=['GET'])
    def get_repository(repository_id: int):
        """Get a repository by ID."""
        try:
            repository_service: RepositoryService = g.container.get("RepositoryService")
            
            response = asyncio.run(repository_service.get_repository(repository_id))
            
            return jsonify({
                "success": response.success,
                "message": response.message,
                "repository": {
                    "id": response.repository.id,
                    "path": response.repository.path,
                    "name": response.repository.name,
                    "active": response.repository.active,
                    "last_scan": response.repository.last_scan.isoformat() if response.repository.last_scan else None,
                    "created_at": response.repository.created_at.isoformat()
                }
            })
            
        except Exception as e:
            logger.error(f"Error getting repository {repository_id}: {e}")
            raise
    
    @bp.route('/<int:repository_id>', methods=['PUT'])
    @validate_json()
    def update_repository(repository_id: int):
        """Update a repository."""
        try:
            data = request.get_json()
            
            repository_service: RepositoryService = g.container.get("RepositoryService")
            
            response = asyncio.run(repository_service.update_repository(
                repository_id=repository_id,
                path=data.get('path'),
                name=data.get('name'),
                active=data.get('active')
            ))
            
            return jsonify({
                "success": response.success,
                "message": response.message,
                "repository": {
                    "id": response.repository.id,
                    "path": response.repository.path,
                    "name": response.repository.name,
                    "active": response.repository.active,
                    "last_scan": response.repository.last_scan.isoformat() if response.repository.last_scan else None,
                    "created_at": response.repository.created_at.isoformat()
                }
            })
            
        except Exception as e:
            logger.error(f"Error updating repository {repository_id}: {e}")
            raise
    
    @bp.route('/<int:repository_id>', methods=['DELETE'])
    def delete_repository(repository_id: int):
        """Delete a repository."""
        try:
            repository_service: RepositoryService = g.container.get("RepositoryService")
            
            response = asyncio.run(repository_service.delete_repository(repository_id))
            
            return jsonify({
                "success": response.success,
                "message": response.message,
                "repository": {
                    "id": response.repository.id,
                    "path": response.repository.path,
                    "name": response.repository.name,
                    "active": response.repository.active,
                    "last_scan": response.repository.last_scan.isoformat() if response.repository.last_scan else None,
                    "created_at": response.repository.created_at.isoformat()
                }
            })
            
        except Exception as e:
            logger.error(f"Error deleting repository {repository_id}: {e}")
            raise
    
    @bp.route('/<int:repository_id>/toggle', methods=['POST'])
    def toggle_repository_status(repository_id: int):
        """Toggle a repository's active status."""
        try:
            repository_service: RepositoryService = g.container.get("RepositoryService")
            
            response = asyncio.run(repository_service.toggle_repository_status(repository_id))
            
            return jsonify({
                "success": response.success,
                "message": response.message,
                "repository": {
                    "id": response.repository.id,
                    "path": response.repository.path,
                    "name": response.repository.name,
                    "active": response.repository.active,
                    "last_scan": response.repository.last_scan.isoformat() if response.repository.last_scan else None,
                    "created_at": response.repository.created_at.isoformat()
                }
            })
            
        except Exception as e:
            logger.error(f"Error toggling repository {repository_id} status: {e}")
            raise
    
    @bp.route('/suggest', methods=['GET'])
    def suggest_repositories():
        """Get repository suggestions including recently checked repos."""
        try:
            repository_service: RepositoryService = g.container.get("RepositoryService")

            response = asyncio.run(repository_service.list_repositories(active_only=True))

            # Order by most recently scanned first; fall back to created_at
            repos = sorted(
                response.repositories,
                key=lambda r: (r.last_scan or r.created_at or 0),
                reverse=True
            )

            recent = [
                {
                    "name": repo.path,
                    "description": f"{repo.name} - Last scanned: {repo.last_scan.strftime('%Y-%m-%d') if repo.last_scan else 'Never'}"
                }
                for repo in repos[:10]
            ]

            # General suggestions: keep alphabetical of active for quick discovery
            suggestions = [
                {
                    "name": repo.path,
                    "description": repo.name
                }
                for repo in sorted(response.repositories, key=lambda r: r.path)[:10]
            ]

            # If no repos configured, return popular defaults for both
            if not suggestions and not recent:
                defaults = [
                    {"name": "facebook/react", "description": "A JavaScript library for building user interfaces"},
                    {"name": "microsoft/vscode", "description": "Visual Studio Code"},
                    {"name": "nodejs/node", "description": "Node.js JavaScript runtime"},
                    {"name": "vercel/next.js", "description": "The React Framework"},
                    {"name": "angular/angular", "description": "The modern web developer's platform"},
                ]
                recent = defaults
                suggestions = defaults

            return jsonify({
                "recent": recent,
                "suggestions": suggestions
            })

        except Exception as e:
            logger.error(f"Error getting repository suggestions: {e}")
            return jsonify({"recent": [], "suggestions": []})
    
    return bp