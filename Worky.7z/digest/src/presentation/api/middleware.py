"""Middleware for API requests."""

import time
from datetime import datetime
from flask import Flask, request, g, jsonify
from functools import wraps

from ...core.dependencies import Container
from ...config.logging_config import get_logger

logger = get_logger(__name__)


def setup_middleware(app: Flask, container: Container) -> None:
    """Set up middleware for the Flask application."""
    
    @app.before_request
    def before_request():
        """Execute before each request."""
        # Start request timing
        g.start_time = time.time()
        g.request_id = request.headers.get('X-Request-ID', f"req_{int(time.time() * 1000)}")
        
        # Log request start
        logger.info(
            f"Request started: {request.method} {request.path}",
            extra={
                "request_id": g.request_id,
                "method": request.method,
                "path": request.path,
                "remote_addr": request.remote_addr,
                "user_agent": request.headers.get('User-Agent', '')
            }
        )
        
        # Make container available to request context
        g.container = container
    
    @app.after_request
    def after_request(response):
        """Execute after each request."""
        # Calculate request duration
        duration = time.time() - g.start_time
        
        # Add request ID to response headers
        response.headers['X-Request-ID'] = g.request_id
        
        # Log request completion
        logger.info(
            f"Request completed: {request.method} {request.path} - {response.status_code}",
            extra={
                "request_id": g.request_id,
                "method": request.method,
                "path": request.path,
                "status_code": response.status_code,
                "duration_ms": round(duration * 1000, 2)
            }
        )
        
        return response
    
    @app.teardown_appcontext
    def teardown_db(exception):
        """Clean up after request."""
        # Clean up any request-specific resources
        if hasattr(g, 'container'):
            # Container cleanup if needed
            pass


def require_content_type(content_type: str):
    """Decorator to require specific content type."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if request.content_type != content_type:
                return jsonify({
                    "error": "Unsupported Media Type",
                    "message": f"Content-Type must be {content_type}"
                }), 415
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def validate_json():
    """Decorator to validate JSON request body."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if request.is_json:
                try:
                    request.get_json(force=True)
                except Exception:
                    return jsonify({
                        "error": "Invalid JSON",
                        "message": "Request body contains invalid JSON"
                    }), 400
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def rate_limit(max_requests: int = 100, window_minutes: int = 1):
    """Simple in-memory rate limiting decorator."""
    request_counts = {}
    
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            client_id = request.remote_addr
            current_time = datetime.now()
            
            # Clean old entries
            cutoff_time = current_time.timestamp() - (window_minutes * 60)
            request_counts[client_id] = [
                req_time for req_time in request_counts.get(client_id, [])
                if req_time > cutoff_time
            ]
            
            # Check rate limit
            if len(request_counts.get(client_id, [])) >= max_requests:
                return jsonify({
                    "error": "Rate Limit Exceeded",
                    "message": f"Maximum {max_requests} requests per {window_minutes} minute(s)"
                }), 429
            
            # Add current request
            request_counts.setdefault(client_id, []).append(current_time.timestamp())
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator