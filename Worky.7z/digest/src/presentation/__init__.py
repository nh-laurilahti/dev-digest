"""Presentation layer with API routes and handlers."""

from .api.routes import create_app
from .api.middleware import setup_middleware
from .api.error_handlers import setup_error_handlers

__all__ = [
    "create_app",
    "setup_middleware", 
    "setup_error_handlers"
]