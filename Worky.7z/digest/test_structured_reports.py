#!/usr/bin/env python3
"""Test script to verify structured report formatting."""

import asyncio
import sys
import os
from datetime import datetime, timezone

# Add src to path
src_path = os.path.join(os.path.dirname(__file__), 'src')
sys.path.insert(0, src_path)
sys.path.insert(0, os.path.dirname(__file__))

from src.domain.entities import DigestEntry, AudienceType
from src.infrastructure.external.openai_client import OpenAIClient

async def test_structured_reports():
    """Test the structured report formatting without OpenAI API calls."""
    
    # Mock digest entries
    entries = [
        DigestEntry(
            title="Add user authentication system",
            summary="Implemented JWT-based authentication with role-based access control",
            author="john.doe",
            pr_url="https://github.com/test/repo/pull/123",
            labels=["feature", "security"],
            significance=0.8,
            change_type="feature",
            is_ongoing=False
        ),
        DigestEntry(
            title="Fix critical memory leak in data processor",
            summary="Resolved memory leak causing performance degradation in production",
            author="jane.smith", 
            pr_url="https://github.com/test/repo/pull/124",
            labels=["bugfix", "critical"],
            significance=0.9,
            change_type="bugfix",
            is_ongoing=False
        ),
        DigestEntry(
            title="Refactor database connection handling",
            summary="Improved connection pooling and error handling for better reliability",
            author="bob.wilson",
            pr_url="https://github.com/test/repo/pull/125", 
            labels=["refactor"],
            significance=0.6,
            change_type="refactor",
            is_ongoing=True
        ),
        DigestEntry(
            title="BREAKING: Update API response format",
            summary="Breaking change: Updated API responses to include versioning info",
            author="alice.johnson",
            pr_url="https://github.com/test/repo/pull/126",
            labels=["breaking", "api"],
            significance=0.95,
            change_type="architecture",
            is_ongoing=False
        )
    ]
    
    # Test summary generation (this will work without API calls)
    try:
        # Create client instance (won't make API calls for create_digest_summary)
        client = OpenAIClient("fake-key-for-testing")  
        
        # Test the structured summary formatting
        summary = await client.create_digest_summary(entries)
        
        # Write to file to avoid Unicode issues in Windows terminal
        with open("test_report.md", "w", encoding="utf-8") as f:
            f.write("=" * 80 + "\n")
            f.write("STRUCTURED DIGEST SUMMARY TEST\n")
            f.write("=" * 80 + "\n")
            f.write(summary)
            f.write("\n" + "=" * 80 + "\n")
        
        print("Report written to test_report.md")
        
        # Verify key formatting elements are present
        # Main header is dynamic (repo and timespan); ensure header marker exists
        assert summary.strip().startswith("# 📊 ")
        assert "## 📈 Overview" in summary
        assert "## 🔄 Change Types" in summary
        assert "✅" in summary  # Green checkmarks
        assert "🟠" in summary  # Orange dots for breaking changes
        assert "**Total Changes:** 4" in summary
        
        print("All formatting tests passed!")
        return True
        
    except Exception as e:
        print(f"Test failed: {e}")
        return False

if __name__ == "__main__":
    success = asyncio.run(test_structured_reports())
    sys.exit(0 if success else 1)