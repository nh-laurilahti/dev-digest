"""Main application entry point."""

import asyncio
from src.presentation.api.routes import create_app
from src.config.settings import get_settings
from src.config.logging_config import get_logger

logger = get_logger(__name__)


def main():
    """Main application entry point."""
    try:
        settings = get_settings()
        logger.info("Starting Daily Dev Digest API server")
        logger.info(f"Database URL: {settings.database_url}")
        
        # Create Flask app
        app = create_app()
        
        # Run the application
        app.run(
            debug=settings.debug,
            host=settings.host,
            port=settings.port
        )
        
    except Exception as e:
        logger.error(f"Failed to start application: {e}")
        raise


if __name__ == '__main__':
    main()