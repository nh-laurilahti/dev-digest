#!/usr/bin/env python3
"""
Temporary runner for the old app with fixes applied.
This runs the backup app with the Flask context fixes.
"""

import sys
import os

# Add paths to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
backup_dir = os.path.join(current_dir, 'backup_pre_refactor')
sys.path.insert(0, backup_dir)
sys.path.insert(0, current_dir)  # For templates

# Change to backup directory so relative imports work
os.chdir(backup_dir)

# Import and run the app
if __name__ == '__main__':
    from app import app, init_services, scheduler, db
    
    # Update template folder to use the new one
    app.template_folder = os.path.join(current_dir, 'templates')
    
    # Create database tables
    with app.app_context():
        db.create_all()
        init_services()
    
    # Start scheduler if enabled
    if os.getenv('ENABLE_SCHEDULER', 'true').lower() == 'true':
        scheduler.start()
        print("Scheduler started")
    
    # Run app
    port = int(os.getenv('PORT', 5000))
    print(f"Starting app on http://localhost:{port}")
    print("Dashboard available at http://localhost:{port}/")
    print("\n✅ Flask context issues fixed - background generation will now work!")
    print("✅ Enhanced progress tracking with backend logs enabled")
    app.run(debug=os.getenv('DEBUG', 'false').lower() == 'true', port=port, host='0.0.0.0')