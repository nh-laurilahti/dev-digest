import os
import logging
from datetime import datetime, timedelta, timezone
from flask import Flask, render_template, jsonify, request, send_file, redirect, url_for, Response
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from apscheduler.schedulers.background import BackgroundScheduler
from dotenv import load_dotenv
import json
import time
import threading
from pathlib import Path

from src.github_client import GitHubClient
from src.analyzer import ChangeAnalyzer
from src.summarizer import Summarizer, DigestEntry
from src.digest_generator import DigestGenerator
from src.audience_profiles import AudienceType, filter_prs_by_relevance
from src.timespan_utils import TimespanType, parse_timespan_string, get_timespan_dates

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Configure database
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///digests.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')

db = SQLAlchemy(app)

# Global progress tracking
progress_store = {}
progress_lock = threading.Lock()

# Models
class Digest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, unique=True)
    repository = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    summary = db.Column(db.Text)
    stats = db.Column(db.Text)  # JSON string
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    
    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date.isoformat(),
            'repository': self.repository,
            'summary': self.summary,
            'stats': json.loads(self.stats) if self.stats else {},
            'created_at': self.created_at.isoformat()
        }


class Repository(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    path = db.Column(db.String(200), nullable=False, unique=True)
    name = db.Column(db.String(100))
    active = db.Column(db.Boolean, default=True)
    last_scan = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))


# Initialize services
github_client = None
analyzer = ChangeAnalyzer()
summarizer = None
generator = DigestGenerator()

def init_services():
    global github_client, summarizer
    github_token = os.getenv('GITHUB_TOKEN')
    openai_key = os.getenv('OPENAI_API_KEY')
    
    if not github_token:
        logger.error("GITHUB_TOKEN environment variable is required")
        logger.info("Please set GITHUB_TOKEN in your .env file or environment variables")
        raise ValueError("GitHub token is required for the application to function")
    
    try:
        github_client = GitHubClient(github_token)
        logger.info("GitHub client initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize GitHub client: {e}")
        raise
    
    try:
        # Initialize summarizer with or without OpenAI
        summarizer = Summarizer(openai_key, use_ai=bool(openai_key))
        if openai_key:
            logger.info("Summarizer initialized with AI support")
        else:
            logger.info("Summarizer initialized with rule-based fallback (no OpenAI key)")
    except Exception as e:
        logger.error(f"Failed to initialize summarizer: {e}")
        # Don't raise here, as we can still work with rule-based summarization
        summarizer = Summarizer(use_ai=False)
        logger.info("Using rule-based summarization only")
    
    logger.info("All services initialized successfully")


def generate_digest_for_repo(repo_path: str, timespan: TimespanType = TimespanType.TODAY, 
                             audience: AudienceType = AudienceType.GENERAL, 
                             custom_days: int = None, view_mode: str = "summary",
                             session_id: str = None):
    import time
    start_time = time.time()
    
    try:
        _, _, timespan_desc = get_timespan_dates(timespan, custom_days)
        logger.info(f"🚀 Starting digest generation for repository: {repo_path}")
        logger.info(f"📅 Timespan: {timespan_desc} | 👥 Audience: {audience.value} | 📋 View: {view_mode}")
        
        # Progress tracking
        if session_id:
            substeps = [
                "📥 Fetch recent pull requests",
                "📝 Fetch ongoing pull requests", 
                "🎯 Filter PRs by audience relevance",
                "🔍 Analyze and summarize changes",
                "📊 Generate HTML digest and save"
            ]
            update_progress(session_id, f"🚀 Starting digest generation for {repo_path}", 0, 5, substeps=substeps)
        
        # Step 1: Fetch recent PRs
        logger.info("📥 Step 1/5: Fetching recent pull requests...")
        if session_id:
            update_progress(session_id, "📥 Step 1/5: Fetching recent pull requests...", 1, 5)
        step_start = time.time()
        recent_prs = github_client.get_recent_pull_requests(repo_path, timespan=timespan, custom_days=custom_days)
        logger.info(f"⏱️  Step 1 completed in {time.time() - step_start:.1f}s")
        
        # Step 2: Fetch ongoing PRs
        logger.info("📝 Step 2/5: Fetching ongoing/draft pull requests...")
        if session_id:
            update_progress(session_id, f"📝 Step 2/5: Fetching ongoing PRs... Found {len(recent_prs)} recent PRs", 2, 5)
        step_start = time.time()
        ongoing_prs = github_client.get_ongoing_pull_requests(repo_path)
        logger.info(f"⏱️  Step 2 completed in {time.time() - step_start:.1f}s")
        
        # Step 3: Filter PRs by audience relevance
        logger.info(f"🎯 Step 3/5: Filtering {len(recent_prs)} PRs by audience relevance ({audience.value})...")
        if session_id:
            update_progress(session_id, f"🎯 Step 3/5: Filtering {len(recent_prs)} PRs by audience ({audience.value})... Found {len(ongoing_prs)} ongoing PRs", 3, 5)
        step_start = time.time()
        
        # Filter recent PRs by audience relevance
        relevant_recent_prs = filter_prs_by_relevance(recent_prs, audience)
        relevant_ongoing_prs = filter_prs_by_relevance(ongoing_prs, audience)
        
        logger.info(f"Found {len(relevant_recent_prs)} relevant completed and {len(relevant_ongoing_prs)} relevant ongoing PRs")
        logger.info(f"⏱️  Step 3 completed in {time.time() - step_start:.1f}s")
        
        # Step 4: Analyze and summarize completed changes
        logger.info(f"🔍 Step 4/5: Analyzing and summarizing {len(relevant_recent_prs)} completed changes...")
        if session_id:
            update_progress(session_id, f"🔍 Step 4/5: Analyzing and summarizing {len(relevant_recent_prs)} completed and {len(relevant_ongoing_prs)} ongoing PRs...", 4, 5)
        step_start = time.time()
        completed_entries = []
        
        # Create progress callback for streaming updates
        def streaming_progress_callback(message):
            if session_id:
                # Keep the main progress at step 4, but update the message with streaming info
                update_progress(session_id, message, 4, 5)
        
        for i, pr in enumerate(relevant_recent_prs, 1):
            logger.info(f"Processing completed PR {i}/{len(relevant_recent_prs)}: #{pr.get('number', '?')} - {pr.get('title', 'Unknown')[:60]}{'...' if len(pr.get('title', '')) > 60 else ''}")
            analysis = analyzer.analyze_pull_request(pr)
            entry = summarizer.summarize_changes(pr, analysis, audience, streaming_progress_callback)
            completed_entries.append(entry)
        
        # Analyze ongoing changes
        ongoing_entries = []
        for i, pr in enumerate(relevant_ongoing_prs, 1):
            logger.info(f"Processing ongoing PR {i}/{len(relevant_ongoing_prs)}: #{pr.get('number', '?')} - {pr.get('title', 'Unknown')[:60]}{'...' if len(pr.get('title', '')) > 60 else ''}")
            analysis = analyzer.analyze_pull_request(pr)
            entry = summarizer.summarize_changes(pr, analysis, audience, streaming_progress_callback)
            ongoing_entries.append(entry)
        
        logger.info(f"⏱️  Step 4 completed in {time.time() - step_start:.1f}s")
        
        # Step 5: Generate and save digest
        logger.info("📊 Step 5/5: Generating HTML digest and saving...")
        if session_id:
            update_progress(session_id, "📊 Step 5/5: Generating HTML digest and saving...", 5, 5)
        step_start = time.time()
        
        # Sort by significance
        logger.info("Sorting entries by significance...")
        completed_entries.sort(key=lambda x: x.significance, reverse=True)
        ongoing_entries.sort(key=lambda x: x.significance, reverse=True)
        
        # Create executive summary or traditional summary based on view mode
        logger.info(f"Creating {view_mode} digest...")
        all_entries = completed_entries + ongoing_entries
        
        if view_mode == "summary":
            # Generate executive summary
            executive_summary = summarizer.create_executive_summary(
                all_entries, repo_path, audience, timespan_desc, streaming_progress_callback
            )
        else:
            executive_summary = summarizer.create_digest_summary(all_entries)
        
        # Create digest data
        digest_data = {
            'date': datetime.now().strftime('%B %d, %Y'),
            'repository': repo_path,
            'timespan': timespan_desc,
            'audience': audience.value,
            'view_mode': view_mode,
            'completed_changes': [entry.__dict__ for entry in completed_entries],
            'ongoing_changes': [entry.__dict__ for entry in ongoing_entries],
            'summary': executive_summary,
            'executive_summary': executive_summary if view_mode == "summary" else None
        }
        
        # Generate HTML
        logger.info("Generating HTML digest...")
        html_content = generator.generate_html(digest_data)
        
        # Save to database
        logger.info("Saving digest to database...")
        digest = Digest(
            date=datetime.now().date(),
            repository=repo_path,
            content=html_content,
            summary=digest_data['summary'],
            stats=json.dumps({
                'total_completed': len(completed_entries),
                'total_ongoing': len(ongoing_entries),
                'high_impact': len([e for e in completed_entries if e.significance > 0.7])
            })
        )
        
        # Check if digest for today already exists
        existing = Digest.query.filter_by(
            date=digest.date,
            repository=repo_path
        ).first()
        
        if existing:
            logger.info("Updating existing digest in database...")
            existing.content = html_content
            existing.summary = digest.summary
            existing.stats = digest.stats
            existing.created_at = datetime.now(timezone.utc)
        else:
            logger.info("Creating new digest in database...")
            db.session.add(digest)
        
        db.session.commit()
        
        # Save to file
        logger.info("Saving digest to HTML file...")
        file_path = generator.save_digest(html_content)
        
        total_time = time.time() - start_time
        logger.info(f"⏱️  Step 5 completed in {time.time() - step_start:.1f}s")
        
        # Mark progress as complete
        if session_id:
            high_impact_count = len([e for e in completed_entries if e.significance > 0.7])
            update_progress(session_id, f"🎉 Complete! Generated digest with {len(completed_entries)} completed, {len(ongoing_entries)} ongoing, {high_impact_count} high-impact changes", 5, 5)
        
        # Final summary
        high_impact_count = len([e for e in completed_entries if e.significance > 0.7])
        logger.info(f"🎉 Digest generation completed successfully!")
        logger.info(f"📈 Repository: {repo_path}")
        logger.info(f"📊 Statistics: {len(completed_entries)} completed, {len(ongoing_entries)} ongoing, {high_impact_count} high-impact")
        logger.info(f"💾 Saved to: {file_path}")
        logger.info(f"⏰ Total time: {total_time:.1f}s")
        
        return digest_data
        
    except Exception as e:
        logger.error(f"Failed to generate digest: {e}")
        raise


# Progress utility functions
def update_progress(session_id: str, message: str, step: int, total_steps: int, substeps=None, estimated_total_time=None):
    """Update progress for a given session"""
    with progress_lock:
        current_time = datetime.now(timezone.utc)
        
        # Calculate time estimates if we have a start time
        time_elapsed = 0
        time_remaining = None
        if session_id in progress_store and 'start_time' in progress_store[session_id]:
            start_time = datetime.fromisoformat(progress_store[session_id]['start_time'])
            time_elapsed = (current_time - start_time).total_seconds()
            if step > 0:
                estimated_total = (time_elapsed / step) * total_steps
                time_remaining = max(0, estimated_total - time_elapsed)
        
        # Initialize or update progress
        if session_id not in progress_store:
            progress_store[session_id] = {
                'start_time': current_time.isoformat(),
                'logs': [],  # Initialize logs array
                'substep_status': {}  # Track status of each substep
            }
        
        # Add the message to logs if it's new
        if 'logs' not in progress_store[session_id]:
            progress_store[session_id]['logs'] = []
        
        # Keep last 50 log entries
        progress_store[session_id]['logs'].append({
            'time': current_time.isoformat(),
            'message': message,
            'level': 'info'
        })
        if len(progress_store[session_id]['logs']) > 50:
            progress_store[session_id]['logs'] = progress_store[session_id]['logs'][-50:]
        
        # Update substep status
        if substeps:
            if 'substep_status' not in progress_store[session_id]:
                progress_store[session_id]['substep_status'] = {}
            
            for i, substep in enumerate(substeps):
                if i < step:
                    progress_store[session_id]['substep_status'][substep] = 'completed'
                elif i == step:
                    progress_store[session_id]['substep_status'][substep] = 'active'
                else:
                    progress_store[session_id]['substep_status'][substep] = 'pending'
        
        progress_store[session_id].update({
            'message': message,
            'step': step,
            'total_steps': total_steps,
            'percentage': int((step / total_steps) * 100),
            'timestamp': current_time.isoformat(),
            'time_elapsed': int(time_elapsed),
            'time_remaining': int(time_remaining) if time_remaining else None,
            'substeps': substeps or [],
            'estimated_total_time': estimated_total_time,
            'current_activity': message  # Add current activity for display
        })

def clear_progress(session_id: str):
    """Clear progress for a given session"""
    with progress_lock:
        if session_id in progress_store:
            del progress_store[session_id]

def get_progress(session_id: str):
    """Get progress for a given session"""
    with progress_lock:
        return progress_store.get(session_id, {})

# Routes
@app.route('/')
def index():
    # Use the new dashboard as the main page
    return render_template('dashboard.html')

@app.route('/welcome')
def welcome():
    return render_template('welcome.html')

@app.route('/legacy')
def legacy_digest():
    # Get the most recent digest for backward compatibility
    latest_digest = Digest.query.order_by(Digest.date.desc()).first()
    
    if latest_digest:
        return latest_digest.content
    
    return render_template('welcome.html')


@app.route('/api/digests')
def get_digests():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    digests = Digest.query.order_by(Digest.date.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'digests': [d.to_dict() for d in digests.items],
        'total': digests.total,
        'page': page,
        'per_page': per_page,
        'total_pages': digests.pages
    })


@app.route('/api/digest/<date>')
def get_digest_by_date(date):
    try:
        digest_date = datetime.strptime(date, '%Y-%m-%d').date()
        digest = Digest.query.filter_by(date=digest_date).first()
        
        if digest:
            return digest.content
        else:
            return jsonify({'error': 'Digest not found'}), 404
    except ValueError:
        return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400


@app.route('/api/generate', methods=['POST'])
def generate_digest():
    data = request.json
    repo_path = data.get('repository')
    
    if not repo_path:
        return jsonify({'error': 'Repository path is required'}), 400
    
    # Generate session ID for progress tracking
    import uuid
    session_id = str(uuid.uuid4())
    
    # Parse optional parameters
    timespan_str = data.get('timespan', 'today')
    audience_str = data.get('audience', 'general') 
    custom_days = data.get('custom_days', None)
    view_mode = data.get('view_mode', 'summary')
    
    try:
        # Parse timespan and audience
        timespan = parse_timespan_string(timespan_str)
        audience = AudienceType(audience_str.lower()) if audience_str.lower() in [a.value for a in AudienceType] else AudienceType.GENERAL
        
        # Start digest generation in background thread
        def generate_in_background():
            with app.app_context():  # Add Flask application context
                try:
                    digest_data = generate_digest_for_repo(
                        repo_path, 
                        timespan=timespan,
                        audience=audience,
                        custom_days=custom_days,
                        view_mode=view_mode,
                        session_id=session_id
                    )
                    # Store the completed digest data in progress store
                    with progress_lock:
                        progress_store[session_id]['digest_data'] = digest_data
                        progress_store[session_id]['status'] = 'completed'
                except Exception as e:
                    logger.error(f"Background digest generation failed: {e}")
                    with progress_lock:
                        progress_store[session_id]['error'] = str(e)
                        progress_store[session_id]['status'] = 'failed'
        
        # Start the background thread
        thread = threading.Thread(target=generate_in_background)
        thread.daemon = True
        thread.start()
        
        # Return immediately with session ID
        return jsonify({
            'success': True,
            'session_id': session_id,
            'message': 'Digest generation started'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/repositories/suggest')
def suggest_repositories():
    """Suggest popular repositories for quick selection"""
    suggestions = [
        {"name": "microsoft/vscode", "description": "Visual Studio Code"},
        {"name": "facebook/react", "description": "React JavaScript Library"},
        {"name": "tensorflow/tensorflow", "description": "Machine Learning Framework"},
        {"name": "kubernetes/kubernetes", "description": "Container Orchestration"},
        {"name": "nodejs/node", "description": "Node.js Runtime"},
        {"name": "python/cpython", "description": "Python Programming Language"},
        {"name": "golang/go", "description": "Go Programming Language"},
        {"name": "rust-lang/rust", "description": "Rust Programming Language"}
    ]
    return jsonify(suggestions)


@app.route('/api/audiences')
def get_audiences():
    """Get available audience types"""
    audiences = []
    for audience_type in AudienceType:
        from src.audience_profiles import get_audience_profile
        profile = get_audience_profile(audience_type)
        audiences.append({
            'value': audience_type.value,
            'name': profile.name,
            'description': profile.description
        })
    return jsonify(audiences)


@app.route('/api/timespans')
def get_timespans():
    """Get available timespan options"""
    timespans = [
        {'value': 'today', 'name': 'Today', 'description': 'Last 24 hours'},
        {'value': 'yesterday', 'name': 'Yesterday', 'description': '24-48 hours ago'},
        {'value': 'last_week', 'name': 'Last Week', 'description': 'Last 7 days'},
        {'value': 'last_month', 'name': 'Last Month', 'description': 'Last 30 days'},
        {'value': 'custom', 'name': 'Custom', 'description': 'Custom number of days'}
    ]
    return jsonify(timespans)


@app.route('/api/repositories')
def get_repositories():
    repos = Repository.query.filter_by(active=True).all()
    return jsonify([{
        'id': r.id,
        'path': r.path,
        'name': r.name,
        'last_scan': r.last_scan.isoformat() if r.last_scan else None
    } for r in repos])


@app.route('/api/repositories', methods=['POST'])
def add_repository():
    data = request.json
    repo_path = data.get('path')
    
    if not repo_path:
        return jsonify({'error': 'Repository path is required'}), 400
    
    existing = Repository.query.filter_by(path=repo_path).first()
    if existing:
        return jsonify({'error': 'Repository already exists'}), 409
    
    repo = Repository(
        path=repo_path,
        name=data.get('name', repo_path.split('/')[-1])
    )
    db.session.add(repo)
    db.session.commit()
    
    return jsonify({'success': True, 'id': repo.id})


@app.route('/archive')
def archive():
    return render_template('archive.html')


@app.route('/settings')
def settings():
    return render_template('settings.html')


@app.route('/api/progress/<session_id>')
def progress_stream(session_id):
    """Server-Sent Events endpoint for real-time progress updates"""
    def generate():
        max_wait_time = 300  # 5 minutes timeout
        start_time = time.time()
        
        while True:
            progress = get_progress(session_id)
            if progress:
                yield f"data: {json.dumps(progress)}\n\n"
                
                # Check if generation is complete or failed
                status = progress.get('status')
                if status == 'completed':
                    # Send final completion message with digest data
                    final_data = {
                        'percentage': 100,
                        'message': progress.get('message', 'Generation completed'),
                        'status': 'completed',
                        'digest_data': progress.get('digest_data')
                    }
                    yield f"data: {json.dumps(final_data)}\n\n"
                    break
                elif status == 'failed':
                    error_data = {
                        'status': 'failed',
                        'error': progress.get('error', 'Generation failed')
                    }
                    yield f"data: {json.dumps(error_data)}\n\n"
                    break
                elif progress.get('percentage', 0) >= 100:
                    # Legacy completion check
                    time.sleep(1)  # Give client time to process final message
                    break
            else:
                # Send keepalive if no progress data
                yield f"data: {json.dumps({'status': 'waiting'})}\n\n"
            
            # Timeout check
            if time.time() - start_time > max_wait_time:
                yield f"data: {json.dumps({'status': 'timeout', 'error': 'Generation timed out'})}\n\n"
                break
                
            time.sleep(1)  # Update every second
    
    return Response(generate(), mimetype='text/event-stream', headers={
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Access-Control-Allow-Origin': '*'
    })


# Scheduled tasks
def scheduled_digest_generation():
    with app.app_context():  # Add Flask application context
        logger.info("Running scheduled digest generation")
        repos = Repository.query.filter_by(active=True).all()
        
        for repo in repos:
            try:
                generate_digest_for_repo(repo.path)
                repo.last_scan = datetime.now(timezone.utc)
                db.session.commit()
            except Exception as e:
                logger.error(f"Failed to generate digest for {repo.path}: {e}")


# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500


# Initialize scheduler
scheduler = BackgroundScheduler()
scheduler.add_job(
    scheduled_digest_generation,
    'cron',
    hour=9,  # Run at 9 AM daily
    minute=0,
    id='daily_digest'
)


if __name__ == '__main__':
    # Create database tables
    with app.app_context():
        db.create_all()
        init_services()
    
    # Start scheduler
    if os.getenv('ENABLE_SCHEDULER', 'true').lower() == 'true':
        scheduler.start()
        logger.info("Scheduler started")
    
    # Run app
    port = int(os.getenv('PORT', 5000))
    app.run(debug=os.getenv('DEBUG', 'false').lower() == 'true', port=port, host='0.0.0.0')