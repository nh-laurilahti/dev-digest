import re
import json
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class ChangeType(Enum):
    DEPENDENCY = "dependency"
    REFACTOR = "refactor"
    FEATURE = "feature"
    BUGFIX = "bugfix"
    DOCUMENTATION = "documentation"
    TESTING = "testing"
    CONFIGURATION = "configuration"
    ARCHITECTURE = "architecture"


@dataclass
class ChangeAnalysis:
    type: ChangeType
    significance: float  # 0.0 to 1.0
    summary: str
    details: List[str]
    affected_components: List[str]


class ChangeAnalyzer:
    DEPENDENCY_FILES = {
        'package.json', 'package-lock.json', 'yarn.lock',
        'requirements.txt', 'Pipfile', 'Pipfile.lock', 'setup.py',
        'Cargo.toml', 'Cargo.lock', 'go.mod', 'go.sum',
        'pom.xml', 'build.gradle', 'composer.json'
    }
    
    ARCHITECTURE_PATTERNS = {
        'folder_restructure': r'(src/|lib/|app/|modules/)',
        'new_service': r'(service|controller|handler|provider)',
        'api_change': r'(api/|routes/|endpoints/)',
        'database_migration': r'(migration|schema|model)'
    }
    
    def analyze_pull_request(self, pr_data: Dict[str, Any]) -> ChangeAnalysis:
        change_types = []
        affected_components = set()
        details = []
        
        # Analyze files changed
        for file in pr_data.get('files_changed', []):
            filename = file['filename']
            
            # Check for dependency changes
            if self._is_dependency_file(filename):
                change_types.append(ChangeType.DEPENDENCY)
                details.append(f"Dependency update in {filename}")
                affected_components.add("dependencies")
            
            # Check for architectural changes
            if self._is_architectural_change(file):
                change_types.append(ChangeType.ARCHITECTURE)
                details.append(f"Architectural change in {filename}")
                affected_components.add(self._extract_component(filename))
            
            # Check for test files
            if self._is_test_file(filename):
                change_types.append(ChangeType.TESTING)
                details.append(f"Test update in {filename}")
                affected_components.add("tests")
            
            # Check for documentation
            if self._is_documentation(filename):
                change_types.append(ChangeType.DOCUMENTATION)
                details.append(f"Documentation update in {filename}")
                affected_components.add("docs")
        
        # Analyze PR title and labels
        primary_type = self._determine_primary_type(pr_data, change_types)
        significance = self._calculate_significance(pr_data, primary_type)
        summary = self._generate_summary(pr_data, primary_type, details)
        
        return ChangeAnalysis(
            type=primary_type,
            significance=significance,
            summary=summary,
            details=details[:5],  # Limit details to top 5
            affected_components=list(affected_components)[:10]
        )
    
    def _is_dependency_file(self, filename: str) -> bool:
        return any(dep_file in filename for dep_file in self.DEPENDENCY_FILES)
    
    def _is_architectural_change(self, file: Dict[str, Any]) -> bool:
        filename = file['filename']
        changes = file.get('changes', 0)
        
        # Large changes to core directories
        if changes > 100:
            for pattern in self.ARCHITECTURE_PATTERNS.values():
                if re.search(pattern, filename):
                    return True
        
        # New directories or major file moves
        if file.get('additions', 0) > 50 or file.get('deletions', 0) > 50:
            return True
        
        return False
    
    def _is_test_file(self, filename: str) -> bool:
        test_patterns = [r'test', r'spec\.', r'__tests__', r'tests/']
        return any(re.search(pattern, filename, re.IGNORECASE) for pattern in test_patterns)
    
    def _is_documentation(self, filename: str) -> bool:
        doc_extensions = ['.md', '.rst', '.txt', '.adoc']
        doc_dirs = ['docs/', 'documentation/']
        
        return (any(filename.endswith(ext) for ext in doc_extensions) or
                any(doc_dir in filename for doc_dir in doc_dirs))
    
    def _extract_component(self, filename: str) -> str:
        parts = filename.split('/')
        if len(parts) > 1:
            return parts[0]
        return filename.split('.')[0]
    
    def _determine_primary_type(self, pr_data: Dict[str, Any], detected_types: List[ChangeType]) -> ChangeType:
        labels = pr_data.get('labels', [])
        title = pr_data.get('title', '').lower()
        
        # Check labels first
        label_mapping = {
            'bug': ChangeType.BUGFIX,
            'feature': ChangeType.FEATURE,
            'refactor': ChangeType.REFACTOR,
            'dependency': ChangeType.DEPENDENCY,
            'documentation': ChangeType.DOCUMENTATION,
            'test': ChangeType.TESTING
        }
        
        for label in labels:
            label_lower = label.lower()
            for key, change_type in label_mapping.items():
                if key in label_lower:
                    return change_type
        
        # Check title patterns
        if re.search(r'\bfix\b|\bbug\b', title):
            return ChangeType.BUGFIX
        elif re.search(r'\bfeat\b|\badd\b|\bnew\b', title):
            return ChangeType.FEATURE
        elif re.search(r'\brefactor\b|\bclean\b', title):
            return ChangeType.REFACTOR
        elif re.search(r'\bdep\b|\bupdate\b|\bupgrade\b', title):
            return ChangeType.DEPENDENCY
        
        # Use detected types
        if detected_types:
            return detected_types[0]
        
        return ChangeType.FEATURE
    
    def _calculate_significance(self, pr_data: Dict[str, Any], change_type: ChangeType) -> float:
        significance = 0.5  # Base significance
        
        # Factor in size of changes
        additions = pr_data.get('additions', 0)
        deletions = pr_data.get('deletions', 0)
        total_changes = additions + deletions
        
        if total_changes > 1000:
            significance += 0.3
        elif total_changes > 500:
            significance += 0.2
        elif total_changes > 100:
            significance += 0.1
        
        # Factor in change type
        type_weights = {
            ChangeType.ARCHITECTURE: 0.3,
            ChangeType.FEATURE: 0.2,
            ChangeType.BUGFIX: 0.15,
            ChangeType.DEPENDENCY: 0.15,
            ChangeType.REFACTOR: 0.1,
            ChangeType.TESTING: 0.05,
            ChangeType.DOCUMENTATION: 0.05,
            ChangeType.CONFIGURATION: 0.1
        }
        
        significance += type_weights.get(change_type, 0.1)
        
        # Factor in number of files
        files_changed = len(pr_data.get('files_changed', []))
        if files_changed > 20:
            significance += 0.1
        elif files_changed > 10:
            significance += 0.05
        
        return min(significance, 1.0)
    
    def _generate_summary(self, pr_data: Dict[str, Any], change_type: ChangeType, details: List[str]) -> str:
        title = pr_data.get('title', 'Untitled PR')
        author = pr_data.get('author', 'Unknown')
        additions = pr_data.get('additions', 0)
        deletions = pr_data.get('deletions', 0)
        
        type_descriptions = {
            ChangeType.DEPENDENCY: "Updated dependencies",
            ChangeType.REFACTOR: "Refactored code",
            ChangeType.FEATURE: "Implemented new feature",
            ChangeType.BUGFIX: "Fixed bug",
            ChangeType.DOCUMENTATION: "Updated documentation",
            ChangeType.TESTING: "Updated tests",
            ChangeType.CONFIGURATION: "Updated configuration",
            ChangeType.ARCHITECTURE: "Made architectural changes"
        }
        
        action = type_descriptions.get(change_type, "Made changes")
        
        summary = f"{author} {action}: {title}. "
        summary += f"Modified {len(pr_data.get('files_changed', []))} files "
        summary += f"(+{additions}/-{deletions} lines)."
        
        if pr_data.get('is_ongoing'):
            summary += " [ONGOING - Draft PR]"
        
        return summary