from enum import Enum
from typing import Dict, List, Any
from dataclasses import dataclass


class AudienceType(Enum):
    FRONTEND = "frontend"
    BACKEND = "backend" 
    DEVOPS = "devops"
    SECURITY = "security"
    DESIGN = "design"
    EXECUTIVE = "executive"
    GENERAL = "general"


@dataclass
class AudienceProfile:
    name: str
    description: str
    keywords: List[str]
    system_prompt: str
    relevance_filters: List[str]
    summary_style: str


AUDIENCE_PROFILES = {
    AudienceType.FRONTEND: AudienceProfile(
        name="Frontend Developer",
        description="Focus on UI/UX, components, styling, and user-facing features",
        keywords=["ui", "ux", "component", "style", "css", "html", "react", "vue", "angular", 
                 "frontend", "client", "browser", "responsive", "accessibility", "performance"],
        system_prompt="""You are writing for frontend developers. Focus on:
- User interface and user experience changes
- Component updates and new UI elements
- Styling, CSS, and visual improvements
- Frontend performance optimizations
- Accessibility improvements
- Client-side functionality changes
- Browser compatibility and responsive design updates
Keep technical details relevant to frontend development.""",
        relevance_filters=["ui", "frontend", "client", "component", "style", "css", "html", "react", "vue", "angular"],
        summary_style="technical_frontend"
    ),
    
    AudienceType.BACKEND: AudienceProfile(
        name="Backend/API Developer", 
        description="Focus on server-side, APIs, databases, and backend services",
        keywords=["api", "backend", "server", "database", "service", "endpoint", "rest", "graphql",
                 "microservice", "sql", "migration", "auth", "middleware", "orm", "cache"],
        system_prompt="""You are writing for backend developers and API engineers. Focus on:
- API changes, new endpoints, and service updates
- Database schema changes and migrations
- Backend service improvements and optimizations
- Authentication and authorization changes
- Server-side performance improvements
- Microservices and architecture updates
- Data processing and business logic changes
Emphasize impacts on system architecture and API contracts.""",
        relevance_filters=["api", "backend", "server", "database", "service", "endpoint", "auth", "migration"],
        summary_style="technical_backend"
    ),
    
    AudienceType.DEVOPS: AudienceProfile(
        name="DevOps Engineer",
        description="Focus on infrastructure, deployment, monitoring, and operations",
        keywords=["deploy", "ci", "cd", "docker", "kubernetes", "infrastructure", "monitoring",
                 "logging", "metrics", "pipeline", "build", "test", "security", "ops"],
        system_prompt="""You are writing for DevOps engineers and platform teams. Focus on:
- Infrastructure and deployment changes
- CI/CD pipeline improvements
- Monitoring, logging, and observability updates
- Security and compliance improvements
- Performance and scalability changes
- Build system and tooling updates
- Operational efficiency improvements
Emphasize operational impact and system reliability.""",
        relevance_filters=["deploy", "ci", "cd", "docker", "kubernetes", "infrastructure", "monitoring", "pipeline"],
        summary_style="operational"
    ),
    
    AudienceType.SECURITY: AudienceProfile(
        name="Security Engineer",
        description="Focus on security fixes, vulnerabilities, and compliance",
        keywords=["security", "vulnerability", "auth", "authorization", "encryption", "compliance",
                 "audit", "penetration", "xss", "csrf", "sql injection", "access control"],
        system_prompt="""You are writing for security engineers and compliance teams. Focus on:
- Security vulnerability fixes and patches
- Authentication and authorization improvements
- Access control and permission changes
- Encryption and data protection updates
- Compliance and audit-related changes
- Security best practice implementations
- Threat mitigation and risk reduction
Emphasize security impact and risk reduction.""",
        relevance_filters=["security", "vulnerability", "auth", "authorization", "encryption", "compliance"],
        summary_style="security_focused"
    ),
    
    AudienceType.DESIGN: AudienceProfile(
        name="Designer/UX",
        description="Focus on visual design, user experience, and interface changes", 
        keywords=["design", "ux", "ui", "visual", "user", "interface", "accessibility",
                 "usability", "wireframe", "prototype", "color", "typography", "layout"],
        system_prompt="""You are writing for designers and UX professionals. Focus on:
- Visual design improvements and changes
- User experience enhancements
- Interface usability improvements
- Accessibility features for users
- Design system and component library updates
- User flow and interaction improvements
- Visual consistency and branding changes
Emphasize user impact and design decisions.""",
        relevance_filters=["design", "ux", "ui", "visual", "user", "interface", "accessibility"],
        summary_style="design_focused"
    ),
    
    AudienceType.EXECUTIVE: AudienceProfile(
        name="Executive/CEO",
        description="High-level business impact, metrics, and strategic updates",
        keywords=["milestone", "release", "feature", "performance", "user", "business", "impact",
                 "revenue", "growth", "strategy", "competition", "market", "customer"],
        system_prompt="""You are writing for executives and business leaders. Focus on:
- Business impact and strategic value
- Major feature releases and product milestones
- Performance improvements affecting users
- Security and compliance achievements
- Team productivity and development velocity
- Market competitiveness and innovation
- Customer-facing improvements and benefits
Use business language, avoid technical jargon, emphasize value and outcomes.""",
        relevance_filters=["feature", "performance", "user", "business", "milestone", "release"],
        summary_style="executive"
    ),
    
    AudienceType.GENERAL: AudienceProfile(
        name="General Developer",
        description="Balanced technical overview for all development roles",
        keywords=["development", "code", "feature", "bug", "improvement", "update", "change"],
        system_prompt="""You are writing for a general technical audience. Focus on:
- Overall development progress and improvements
- Important bug fixes and feature additions
- Code quality and performance improvements
- Development process and tooling updates
- Cross-functional changes affecting multiple teams
Maintain technical accuracy while being accessible to all developers.""",
        relevance_filters=["development", "code", "feature", "bug", "improvement"],
        summary_style="general_technical"
    )
}


def get_audience_profile(audience_type: AudienceType) -> AudienceProfile:
    return AUDIENCE_PROFILES[audience_type]


def calculate_relevance_score(pr_data: Dict[str, Any], audience_type: AudienceType) -> float:
    """Calculate how relevant a PR is to a specific audience (0.0 to 1.0)"""
    profile = get_audience_profile(audience_type)
    
    # Text to analyze for keywords
    text_fields = [
        pr_data.get('title', ''),
        pr_data.get('body', ''),
        ' '.join(pr_data.get('labels', []))
    ]
    
    combined_text = ' '.join(text_fields).lower()
    
    # Count keyword matches
    keyword_matches = 0
    for keyword in profile.keywords:
        if keyword.lower() in combined_text:
            keyword_matches += 1
    
    # Base score from keyword density
    keyword_score = min(keyword_matches / len(profile.keywords), 1.0)
    
    # Boost score for files changed that match audience
    file_boost = 0.0
    for file_info in pr_data.get('files_changed', []):
        filename = file_info.get('filename', '').lower()
        for filter_term in profile.relevance_filters:
            if filter_term in filename:
                file_boost += 0.1
    
    # Combine scores
    total_score = min(keyword_score + file_boost, 1.0)
    
    return total_score


def filter_prs_by_relevance(prs: List[Dict[str, Any]], audience_type: AudienceType, 
                           min_relevance: float = 0.1) -> List[Dict[str, Any]]:
    """Filter and sort PRs by relevance to audience"""
    scored_prs = []
    
    for pr in prs:
        relevance = calculate_relevance_score(pr, audience_type)
        if relevance >= min_relevance:
            pr_copy = pr.copy()
            pr_copy['relevance_score'] = relevance
            scored_prs.append(pr_copy)
    
    # Sort by relevance score (highest first)
    return sorted(scored_prs, key=lambda x: x['relevance_score'], reverse=True)