import os
from datetime import datetime, timedelta, timezone
from typing import List, Dict, Any, Optional
from github import Github
from github.PullRequest import PullRequest
from github.Repository import Repository
import logging
from .timespan_utils import TimespanType, get_timespan_dates

logger = logging.getLogger(__name__)


class GitHubClient:
    def __init__(self, token: Optional[str] = None):
        self.token = token or os.getenv('GITHUB_TOKEN')
        if not self.token:
            raise ValueError("GitHub token is required. Set GITHUB_TOKEN environment variable.")
        
        try:
            # Initialize GitHub client with minimal parameters to avoid compatibility issues
            self.client = Github(auth=self.token) if hasattr(Github, 'auth') else Github(self.token)
        except Exception as e:
            logger.error(f"Failed to initialize GitHub client: {e}")
            # Fallback to basic initialization
            try:
                self.client = Github(self.token)
            except Exception as fallback_error:
                logger.error(f"Fallback GitHub client initialization also failed: {fallback_error}")
                raise ValueError(f"Could not initialize GitHub client: {fallback_error}")
    
    def get_repository(self, repo_path: str) -> Repository:
        try:
            return self.client.get_repo(repo_path)
        except Exception as e:
            logger.error(f"Failed to get repository {repo_path}: {e}")
            raise
    
    def get_recent_pull_requests(self, repo_path: str, hours: int = 24, timespan: TimespanType = None, custom_days: int = None) -> List[Dict[str, Any]]:
        repo = self.get_repository(repo_path)
        
        # Use timespan if provided, otherwise fall back to hours
        if timespan:
            start_time, end_time, timespan_desc = get_timespan_dates(timespan, custom_days)
            logger.info(f"Fetching merged PRs from {timespan_desc} for {repo_path}")
        else:
            start_time = datetime.now(timezone.utc) - timedelta(hours=hours)
            end_time = datetime.now(timezone.utc)
            timespan_desc = f"last {hours} hours"
            logger.info(f"Fetching merged PRs from {timespan_desc} for {repo_path}")
        pull_requests = []
        processed_count = 0
        
        try:
            for pr in repo.get_pulls(state='closed', sort='updated', direction='desc'):
                processed_count += 1
                
                # Check if PR was merged within our timespan
                if pr.merged_at and pr.merged_at >= start_time and pr.merged_at <= end_time:
                    logger.info(f"Found merged PR #{pr.number}: {pr.title[:50]}{'...' if len(pr.title) > 50 else ''}")
                    pr_data = self._extract_pr_data(pr)
                    pull_requests.append(pr_data)
                elif pr.updated_at < start_time:
                    logger.info(f"Reached cutoff time after checking {processed_count} PRs")
                    break
                    
                # Log progress every 10 PRs
                if processed_count % 10 == 0:
                    logger.info(f"Processed {processed_count} PRs, found {len(pull_requests)} merged in timeframe")
                    
        except Exception as e:
            logger.error(f"Error fetching pull requests: {e}")
            raise
        
        logger.info(f"✅ Found {len(pull_requests)} merged PRs from {processed_count} total PRs checked")
        return pull_requests
    
    def get_ongoing_pull_requests(self, repo_path: str) -> List[Dict[str, Any]]:
        repo = self.get_repository(repo_path)
        logger.info(f"Fetching ongoing/draft PRs for {repo_path}")
        ongoing_prs = []
        checked_count = 0
        
        try:
            for pr in repo.get_pulls(state='open'):
                checked_count += 1
                if pr.draft or any(label.name.lower() in ['wip', 'work in progress'] for label in pr.labels):
                    logger.info(f"Found ongoing PR #{pr.number}: {pr.title[:50]}{'...' if len(pr.title) > 50 else ''}")
                    pr_data = self._extract_pr_data(pr)
                    pr_data['is_ongoing'] = True
                    ongoing_prs.append(pr_data)
                    
                # Limit to first 50 open PRs to avoid excessive processing
                if checked_count >= 50:
                    logger.info(f"Checked {checked_count} open PRs (limit reached)")
                    break
                    
        except Exception as e:
            logger.error(f"Error fetching ongoing pull requests: {e}")
            raise
        
        logger.info(f"✅ Found {len(ongoing_prs)} ongoing PRs from {checked_count} open PRs checked")
        return ongoing_prs
    
    def _extract_pr_data(self, pr: PullRequest) -> Dict[str, Any]:
        try:
            files_changed = []
            additions = 0
            deletions = 0
            
            for file in pr.get_files():
                files_changed.append({
                    'filename': file.filename,
                    'additions': file.additions,
                    'deletions': file.deletions,
                    'changes': file.changes,
                    'patch': file.patch if hasattr(file, 'patch') else None
                })
                additions += file.additions
                deletions += file.deletions
            
            commits = []
            for commit in pr.get_commits():
                commits.append({
                    'sha': commit.sha,
                    'message': commit.commit.message,
                    'author': commit.commit.author.name if commit.commit.author else 'Unknown',
                    'date': commit.commit.author.date.isoformat() if commit.commit.author else None
                })
            
            return {
                'number': pr.number,
                'title': pr.title,
                'body': pr.body or '',
                'author': pr.user.login if pr.user else 'Unknown',
                'merged_at': pr.merged_at.isoformat() if pr.merged_at else None,
                'created_at': pr.created_at.isoformat() if pr.created_at else None,
                'updated_at': pr.updated_at.isoformat() if pr.updated_at else None,
                'html_url': pr.html_url,
                'labels': [label.name for label in pr.labels],
                'draft': pr.draft,
                'files_changed': files_changed,
                'additions': additions,
                'deletions': deletions,
                'commits': commits,
                'is_ongoing': False
            }
        except Exception as e:
            logger.error(f"Error extracting PR data: {e}")
            return {
                'number': pr.number,
                'title': pr.title,
                'html_url': pr.html_url,
                'error': str(e)
            }