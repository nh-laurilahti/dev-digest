import os
import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import openai
import json
from .audience_profiles import AudienceType, get_audience_profile, filter_prs_by_relevance

logger = logging.getLogger(__name__)


@dataclass
class DigestEntry:
    title: str
    summary: str
    author: str
    pr_url: str
    labels: List[str]
    significance: float
    change_type: str
    is_ongoing: bool = False


class Summarizer:
    def __init__(self, api_key: Optional[str] = None, use_ai: bool = True):
        self.use_ai = use_ai
        if use_ai:
            self.api_key = api_key or os.getenv('OPENAI_API_KEY')
            if self.api_key:
                try:
                    # Initialize OpenAI client with minimal parameters
                    self.client = openai.OpenAI(
                        api_key=self.api_key,
                        timeout=30.0,
                        max_retries=2
                    )
                    logger.info("OpenAI client initialized successfully")
                except Exception as e:
                    logger.error(f"Failed to initialize OpenAI client: {e}")
                    logger.warning("Falling back to rule-based summarization.")
                    self.use_ai = False
            else:
                logger.warning("No OpenAI API key found. Falling back to rule-based summarization.")
                self.use_ai = False
    
    def summarize_changes(self, pr_data: Dict[str, Any], analysis: Any, audience: AudienceType = AudienceType.GENERAL, progress_callback=None) -> DigestEntry:
        pr_title = pr_data.get('title', 'Unknown PR')[:40] + ('...' if len(pr_data.get('title', '')) > 40 else '')
        
        if self.use_ai and hasattr(self, 'client'):
            try:
                logger.info(f"🤖 Generating AI summary for: {pr_title} (audience: {audience.value})")
                summary = self._ai_summarize(pr_data, analysis, audience, progress_callback)
                logger.info(f"✅ AI summary completed for: {pr_title}")
            except Exception as e:
                logger.error(f"❌ AI summarization failed for '{pr_title}': {e}")
                logger.info(f"🔧 Falling back to rule-based summary for: {pr_title}")
                summary = self._rule_based_summarize(pr_data, analysis)
        else:
            logger.info(f"📝 Generating rule-based summary for: {pr_title}")
            summary = self._rule_based_summarize(pr_data, analysis)
        
        return DigestEntry(
            title=pr_data.get('title', 'Untitled PR'),
            summary=summary,
            author=pr_data.get('author', 'Unknown'),
            pr_url=pr_data.get('html_url', '#'),
            labels=pr_data.get('labels', []),
            significance=analysis.significance,
            change_type=analysis.type.value,
            is_ongoing=pr_data.get('is_ongoing', False)
        )
    
    def _ai_summarize(self, pr_data: Dict[str, Any], analysis: Any, audience: AudienceType = AudienceType.GENERAL, progress_callback=None) -> str:
        try:
            # Get audience-specific prompt
            profile = get_audience_profile(audience)
            
            # Prepare context for AI
            context = self._prepare_ai_context(pr_data, analysis)
            
            # Add streaming if progress callback is provided
            use_streaming = progress_callback is not None
            
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {
                        "role": "system", 
                        "content": profile.system_prompt
                    },
                    {
                        "role": "user",
                        "content": f"Summarize this pull request in 2-3 sentences for a {profile.name}:\n\n{context}"
                    }
                ],
                max_tokens=150,
                temperature=0.7,
                stream=use_streaming
            )
            
            if use_streaming:
                # Handle streaming response
                collected_content = ""
                pr_title_short = pr_data.get('title', 'Unknown')[:30]
                
                for chunk in response:
                    if chunk.choices[0].delta.content is not None:
                        content = chunk.choices[0].delta.content
                        collected_content += content
                        # Send progress update with streaming content
                        if progress_callback:
                            progress_callback(f"🤖 Generating summary for '{pr_title_short}': {collected_content[:50]}...")
                
                return collected_content.strip()
            else:
                # Non-streaming response
                return response.choices[0].message.content.strip()
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            raise
    
    def _prepare_ai_context(self, pr_data: Dict[str, Any], analysis: Any) -> str:
        context = f"""
        Title: {pr_data.get('title', 'N/A')}
        Description: {pr_data.get('body', 'N/A')[:500]}
        Change Type: {analysis.type.value}
        Files Changed: {len(pr_data.get('files_changed', []))}
        Lines Added: {pr_data.get('additions', 0)}
        Lines Removed: {pr_data.get('deletions', 0)}
        Key Changes: {', '.join(analysis.details[:3])}
        """
        
        # Add commit messages
        commits = pr_data.get('commits', [])[:5]
        if commits:
            commit_messages = [c.get('message', '').split('\n')[0] for c in commits]
            context += f"\nCommit Messages: {'; '.join(commit_messages)}"
        
        return context
    
    def _rule_based_summarize(self, pr_data: Dict[str, Any], analysis: Any) -> str:
        summary_parts = []
        
        # Start with the main action
        summary_parts.append(analysis.summary)
        
        # Add key details based on change type
        if analysis.type.value == "dependency":
            dep_files = [f for f in pr_data.get('files_changed', []) 
                        if 'package' in f['filename'] or 'requirements' in f['filename']]
            if dep_files:
                summary_parts.append(f"Updated {len(dep_files)} dependency file(s).")
        
        elif analysis.type.value == "feature":
            components = analysis.affected_components[:3]
            if components:
                summary_parts.append(f"Affects: {', '.join(components)}.")
        
        elif analysis.type.value == "bugfix":
            if pr_data.get('body'):
                # Try to extract issue reference
                import re
                issues = re.findall(r'#(\d+)', pr_data.get('body', ''))
                if issues:
                    summary_parts.append(f"Fixes issue(s): {', '.join(['#' + i for i in issues[:2]])}.")
        
        # Add impact indicator
        if analysis.significance > 0.7:
            summary_parts.append("High impact change.")
        elif analysis.significance > 0.4:
            summary_parts.append("Moderate impact change.")
        
        return ' '.join(summary_parts[:3])  # Limit to 3 sentences
    
    def create_digest_summary(self, entries: List[DigestEntry]) -> str:
        completed = [e for e in entries if not e.is_ongoing]
        ongoing = [e for e in entries if e.is_ongoing]
        
        summary_parts = []
        
        if completed:
            high_impact = [e for e in completed if e.significance > 0.7]
            if high_impact:
                summary_parts.append(f"{len(high_impact)} high-impact changes merged")
            summary_parts.append(f"{len(completed)} total changes completed")
        
        if ongoing:
            summary_parts.append(f"{len(ongoing)} changes in progress")
        
        if not summary_parts:
            return "No significant changes in the last 24 hours"
        
        return f"Daily Digest: {', '.join(summary_parts)}"
    
    def create_executive_summary(self, entries: List[DigestEntry], repository: str, 
                                audience: AudienceType = AudienceType.GENERAL, 
                                timespan: str = "24 hours", progress_callback=None) -> str:
        """Generate a 300-word executive summary of changes"""
        
        if not entries:
            return f"No significant changes detected in {repository} over the last {timespan}."
        
        # Filter entries by audience relevance
        completed_entries = [e for e in entries if not e.is_ongoing]
        ongoing_entries = [e for e in entries if e.is_ongoing]
        
        # Get audience profile
        profile = get_audience_profile(audience)
        
        if self.use_ai and hasattr(self, 'client'):
            try:
                return self._generate_ai_executive_summary(
                    completed_entries, ongoing_entries, repository, audience, timespan, progress_callback
                )
            except Exception as e:
                logger.error(f"AI executive summary failed: {e}")
                return self._generate_rule_based_executive_summary(
                    completed_entries, ongoing_entries, repository, audience, timespan
                )
        else:
            return self._generate_rule_based_executive_summary(
                completed_entries, ongoing_entries, repository, audience, timespan
            )
    
    def _generate_ai_executive_summary(self, completed: List[DigestEntry], ongoing: List[DigestEntry],
                                     repository: str, audience: AudienceType, timespan: str, progress_callback=None) -> str:
        """Generate AI-powered executive summary"""
        profile = get_audience_profile(audience)
        
        # Prepare context with top changes
        completed_summaries = [f"- {e.title}: {e.summary}" for e in completed[:10]]
        ongoing_summaries = [f"- {e.title}: {e.summary}" for e in ongoing[:5]]
        
        context = f"""Repository: {repository}
Timespan: {timespan}

Completed Changes:
{chr(10).join(completed_summaries)}

Ongoing Work:
{chr(10).join(ongoing_summaries)}

Statistics:
- {len(completed)} completed changes
- {len(ongoing)} ongoing changes
- {len([e for e in completed if e.significance > 0.7])} high-impact changes"""
        
        system_prompt = f"""{profile.system_prompt}

Create a comprehensive 300-word executive summary that:
1. Opens with the overall development status and key themes
2. Highlights the most important changes and their impact
3. Notes any significant trends or patterns
4. Concludes with implications for the {profile.name} role
5. Uses appropriate technical depth for the {profile.name} audience"""
        
        try:
            # Add streaming if progress callback is provided
            use_streaming = progress_callback is not None
            
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"Create an executive summary from this data:\n\n{context}"}
                ],
                max_tokens=400,
                temperature=0.6,
                stream=use_streaming
            )
            
            if use_streaming:
                # Handle streaming response
                collected_content = ""
                
                for chunk in response:
                    if chunk.choices[0].delta.content is not None:
                        content = chunk.choices[0].delta.content
                        collected_content += content
                        # Send progress update with streaming content
                        if progress_callback:
                            progress_callback(f"📝 Generating executive summary: {len(collected_content)} characters written...")
                
                return collected_content.strip()
            else:
                # Non-streaming response
                return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"AI executive summary generation failed: {e}")
            raise
    
    def _generate_rule_based_executive_summary(self, completed: List[DigestEntry], ongoing: List[DigestEntry],
                                             repository: str, audience: AudienceType, timespan: str) -> str:
        """Generate rule-based executive summary"""
        profile = get_audience_profile(audience)
        
        # Calculate statistics
        high_impact = [e for e in completed if e.significance > 0.7]
        change_types = {}
        for entry in completed:
            change_types[entry.change_type] = change_types.get(entry.change_type, 0) + 1
        
        # Start summary
        summary_parts = [
            f"Development Summary for {repository} ({timespan}):",
            f"The team completed {len(completed)} changes with {len(ongoing)} still in progress."
        ]
        
        # Highlight most common change types
        if change_types:
            top_type = max(change_types, key=change_types.get)
            summary_parts.append(f"Primary focus was on {top_type} with {change_types[top_type]} updates.")
        
        # High impact changes
        if high_impact:
            summary_parts.append(f"{len(high_impact)} high-impact changes were delivered, including:")
            for entry in high_impact[:3]:
                summary_parts.append(f"• {entry.title}")
        
        # Audience-specific insights
        audience_relevant = [e for e in completed if audience.value in e.summary.lower() or 
                           any(keyword in e.summary.lower() for keyword in profile.keywords[:5])]
        
        if audience_relevant:
            summary_parts.append(f"For {profile.name} teams, key updates include:")
            for entry in audience_relevant[:2]:
                summary_parts.append(f"• {entry.summary}")
        
        # Ongoing work
        if ongoing:
            summary_parts.append(f"In progress: {len(ongoing)} active changes including {ongoing[0].title}.")
        
        summary_parts.append("Overall development velocity remains strong with consistent progress across multiple areas.")
        
        return " ".join(summary_parts)[:300] + ("..." if len(" ".join(summary_parts)) > 300 else "")