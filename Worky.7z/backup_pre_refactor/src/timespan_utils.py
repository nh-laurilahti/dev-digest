from enum import Enum
from datetime import datetime, timedelta, timezone
from typing import Tuple


class TimespanType(Enum):
    TODAY = "today"
    YESTERDAY = "yesterday"
    LAST_WEEK = "last_week" 
    LAST_MONTH = "last_month"
    CUSTOM = "custom"


def get_timespan_dates(timespan: TimespanType, custom_days: int = None) -> Tuple[datetime, datetime, str]:
    """
    Get start and end datetime objects for a given timespan
    Returns: (start_datetime, end_datetime, human_readable_description)
    """
    now = datetime.now(timezone.utc)
    
    if timespan == TimespanType.TODAY:
        # Last 24 hours
        start = now - timedelta(hours=24)
        return start, now, "last 24 hours"
    
    elif timespan == TimespanType.YESTERDAY:
        # 24-48 hours ago
        start = now - timedelta(hours=48)
        end = now - timedelta(hours=24)
        return start, end, "yesterday (24-48 hours ago)"
    
    elif timespan == TimespanType.LAST_WEEK:
        # Last 7 days
        start = now - timedelta(days=7)
        return start, now, "last 7 days"
    
    elif timespan == TimespanType.LAST_MONTH:
        # Last 30 days
        start = now - timedelta(days=30)
        return start, now, "last 30 days"
    
    elif timespan == TimespanType.CUSTOM and custom_days:
        # Custom number of days
        start = now - timedelta(days=custom_days)
        return start, now, f"last {custom_days} days"
    
    else:
        # Default to today
        start = now - timedelta(hours=24)
        return start, now, "last 24 hours"


def get_hours_from_timespan(timespan: TimespanType, custom_days: int = None) -> int:
    """Get hours equivalent for backward compatibility with existing API"""
    if timespan == TimespanType.TODAY:
        return 24
    elif timespan == TimespanType.YESTERDAY:
        return 48  # We'll filter this differently in the client
    elif timespan == TimespanType.LAST_WEEK:
        return 24 * 7
    elif timespan == TimespanType.LAST_MONTH:
        return 24 * 30
    elif timespan == TimespanType.CUSTOM and custom_days:
        return 24 * custom_days
    else:
        return 24


def parse_timespan_string(timespan_str: str) -> TimespanType:
    """Parse string to TimespanType enum"""
    timespan_map = {
        "today": TimespanType.TODAY,
        "yesterday": TimespanType.YESTERDAY,
        "last_week": TimespanType.LAST_WEEK,
        "last_month": TimespanType.LAST_MONTH,
        "custom": TimespanType.CUSTOM
    }
    
    return timespan_map.get(timespan_str.lower(), TimespanType.TODAY)