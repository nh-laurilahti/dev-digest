from datetime import datetime, timezone
from typing import List, Dict, Any
import os
from jinja2 import Template
import logging

logger = logging.getLogger(__name__)


class DigestGenerator:
    def __init__(self):
        self.template = self._load_template()
    
    def _load_template(self) -> Template:
        template_str = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Dev Digest - {{ date }}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        
        .date {
            font-size: 1.2rem;
            opacity: 0.95;
        }
        
        .summary {
            background: #f8f9fa;
            padding: 20px 30px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 1.1rem;
            color: #555;
        }
        
        .content {
            padding: 30px;
        }
        
        section {
            margin-bottom: 40px;
        }
        
        h2 {
            color: #667eea;
            margin-bottom: 20px;
            font-size: 1.8rem;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        
        .change-entry {
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .change-entry:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.2);
        }
        
        .change-entry.ongoing {
            border-left-color: #ffa500;
            background: #fff9e6;
        }
        
        .change-entry.high-impact {
            border-left-color: #ff4757;
            background: #ffe6e9;
        }
        
        .entry-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }
        
        .entry-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
            flex: 1;
        }
        
        .entry-title a {
            color: inherit;
            text-decoration: none;
            border-bottom: 2px solid transparent;
            transition: border-color 0.3s;
        }
        
        .entry-title a:hover {
            border-bottom-color: #667eea;
        }
        
        .significance-badge {
            background: #667eea;
            color: white;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
            margin-left: 10px;
        }
        
        .significance-badge.high {
            background: #ff4757;
        }
        
        .significance-badge.medium {
            background: #ffa500;
        }
        
        .significance-badge.low {
            background: #28a745;
        }
        
        .entry-meta {
            display: flex;
            gap: 15px;
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }
        
        .author {
            font-weight: 500;
        }
        
        .labels {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 10px;
        }
        
        .label {
            background: #e3e8ef;
            color: #667eea;
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .summary-text {
            color: #555;
            line-height: 1.6;
            margin-top: 10px;
        }
        
        .no-changes {
            text-align: center;
            padding: 40px;
            color: #999;
            font-style: italic;
        }
        
        footer {
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #666;
            font-size: 0.9rem;
            border-top: 1px solid #e0e0e0;
        }
        
        @media (max-width: 768px) {
            header h1 {
                font-size: 2rem;
            }
            
            .container {
                border-radius: 0;
            }
            
            body {
                padding: 0;
            }
            
            .content {
                padding: 20px;
            }
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .stat-card {
            background: white;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #667eea;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📊 Daily Dev Digest</h1>
            <div class="date">{{ date }}</div>
        </header>
        
        <div class="summary">
            {{ digest_summary }}
        </div>
        
        {% if stats %}
        <div class="content">
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-value">{{ stats.total_changes }}</div>
                    <div class="stat-label">Total Changes</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{{ stats.high_impact }}</div>
                    <div class="stat-label">High Impact</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{{ stats.ongoing }}</div>
                    <div class="stat-label">Ongoing</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{{ stats.contributors }}</div>
                    <div class="stat-label">Contributors</div>
                </div>
            </div>
        </div>
        {% endif %}
        
        <div class="content">
            {% if completed_changes %}
            <section>
                <h2>✅ Completed Changes</h2>
                {% for entry in completed_changes %}
                <div class="change-entry {% if entry.significance > 0.7 %}high-impact{% endif %}">
                    <div class="entry-header">
                        <div class="entry-title">
                            <a href="{{ entry.pr_url }}" target="_blank">{{ entry.title }}</a>
                        </div>
                        {% if entry.significance > 0.7 %}
                        <span class="significance-badge high">High Impact</span>
                        {% elif entry.significance > 0.4 %}
                        <span class="significance-badge medium">Medium Impact</span>
                        {% else %}
                        <span class="significance-badge low">Low Impact</span>
                        {% endif %}
                    </div>
                    <div class="entry-meta">
                        <span class="author">👤 {{ entry.author }}</span>
                        <span class="change-type">📁 {{ entry.change_type }}</span>
                    </div>
                    <div class="summary-text">{{ entry.summary }}</div>
                    {% if entry.labels %}
                    <div class="labels">
                        {% for label in entry.labels %}
                        <span class="label">{{ label }}</span>
                        {% endfor %}
                    </div>
                    {% endif %}
                </div>
                {% endfor %}
            </section>
            {% endif %}
            
            {% if ongoing_changes %}
            <section>
                <h2>🚧 Ongoing Changes</h2>
                {% for entry in ongoing_changes %}
                <div class="change-entry ongoing">
                    <div class="entry-header">
                        <div class="entry-title">
                            <a href="{{ entry.pr_url }}" target="_blank">{{ entry.title }}</a>
                        </div>
                        <span class="significance-badge">In Progress</span>
                    </div>
                    <div class="entry-meta">
                        <span class="author">👤 {{ entry.author }}</span>
                        <span class="change-type">📁 {{ entry.change_type }}</span>
                    </div>
                    <div class="summary-text">{{ entry.summary }}</div>
                    {% if entry.labels %}
                    <div class="labels">
                        {% for label in entry.labels %}
                        <span class="label">{{ label }}</span>
                        {% endfor %}
                    </div>
                    {% endif %}
                </div>
                {% endfor %}
            </section>
            {% endif %}
            
            {% if not completed_changes and not ongoing_changes %}
            <div class="no-changes">
                No significant changes detected in the last 24 hours.
            </div>
            {% endif %}
        </div>
        
        <footer>
            Generated at {{ generated_at }} | Repository: {{ repository }}
        </footer>
    </div>
</body>
</html>'''
        return Template(template_str)
    
    def generate_html(self, digest_data: Dict[str, Any]) -> str:
        try:
            # Calculate statistics
            completed = digest_data.get('completed_changes', [])
            ongoing = digest_data.get('ongoing_changes', [])
            
            contributors = set()
            for entry in completed + ongoing:
                contributors.add(entry.get('author', 'Unknown'))
            
            stats = {
                'total_changes': len(completed) + len(ongoing),
                'high_impact': len([e for e in completed if e.get('significance', 0) > 0.7]),
                'ongoing': len(ongoing),
                'contributors': len(contributors)
            }
            
            # Prepare template data
            template_data = {
                'date': digest_data.get('date', datetime.now().strftime('%B %d, %Y')),
                'digest_summary': digest_data.get('summary', 'Daily development summary'),
                'completed_changes': completed,
                'ongoing_changes': ongoing,
                'stats': stats,
                'generated_at': datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),
                'repository': digest_data.get('repository', 'Unknown Repository')
            }
            
            return self.template.render(**template_data)
        except Exception as e:
            logger.error(f"Error generating HTML: {e}")
            raise
    
    def save_digest(self, html_content: str, output_path: str = None) -> str:
        if not output_path:
            date_str = datetime.now(timezone.utc).strftime('%Y%m%d')
            output_path = f"digests/digest_{date_str}.html"
        
        os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else 'digests', exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Digest saved to {output_path}")
        return output_path